package com.meturing.TCP.Demo05;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class TestServer {
    public static void main(String[] args) {
        ServerSocket serverSocket = null;
        Socket accept = null;
        try {
            serverSocket = new ServerSocket(8888);
            int count = 0;
            while (true){
                accept =  serverSocket.accept();
                new ThreadServer(accept).start();
                count++;
                System.out.println("⌈服务器消息⌋  这是第"+count+"个登陆的用户，地址是："+accept.getInetAddress());
           }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (accept != null) {
                try {
                    accept.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
