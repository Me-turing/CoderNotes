package com.meturing.UDP.Demo03;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class TestReceive {
    public static void main(String[] args)  {
        DatagramSocket datagramSocket = null;
        try {
            System.out.println("接收端上线~！");
            datagramSocket = new DatagramSocket(9999);
            byte[] bytes = new byte[1024];
            DatagramPacket datagramPacket = new DatagramPacket(bytes, bytes.length);
            datagramSocket.receive(datagramPacket);

            byte[] data = datagramPacket.getData();
            String s = new String(data, "UTF-8");
            System.out.println(s);

            String str = "你也是";
            byte[] bytes1 = str.getBytes();
            DatagramPacket localhost = new DatagramPacket(bytes1, bytes1.length, InetAddress.getByName("localhost"), 8888);
            datagramSocket.send(localhost);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (datagramSocket == null) {
                    datagramSocket.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}
