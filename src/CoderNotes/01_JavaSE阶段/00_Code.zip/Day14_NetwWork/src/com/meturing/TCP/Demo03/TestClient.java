package com.meturing.TCP.Demo03;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class TestClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("127.0.0.1", 8888);//打开指定IP与接口的通信
        OutputStream outputStream = socket.getOutputStream();//获取输出流
        //获取对象输出流
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
        Scanner scanner = new Scanner(System.in);
        System.out.print("请输入用户名：");
        String userName = scanner.next();
        System.out.print("请输入密码：");
        String userPwd = scanner.next();
        objectOutputStream.writeObject(new UserInfo(userName,userPwd));//输出对象

        //获取服务器返回状态
        InputStream inputStream = socket.getInputStream();
        DataInputStream dataInputStream = new DataInputStream(inputStream);
        boolean flag = dataInputStream.readBoolean();
        if (flag){
            System.out.println("登录成功~！");
        }else {
            System.out.println("登录失败~！");
        }

        //关闭流
        dataInputStream.close();
        inputStream.close();
        objectOutputStream.close();
        outputStream.close();
        socket.close();
    }
}

