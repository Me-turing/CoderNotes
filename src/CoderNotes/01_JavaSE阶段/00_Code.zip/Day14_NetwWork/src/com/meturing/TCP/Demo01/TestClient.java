package com.meturing.TCP.Demo01;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

public class TestClient {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("127.0.0.1", 8888);//打开指定IP与接口的通信
        OutputStream outputStream = socket.getOutputStream();//获取输出流
        DataOutputStream dataOutputStream = new DataOutputStream(outputStream);//获取数据输出流
        dataOutputStream.writeUTF("你好！");//输出对象
        dataOutputStream.close();//关闭流
        outputStream.close();
        socket.close();
    }
}

