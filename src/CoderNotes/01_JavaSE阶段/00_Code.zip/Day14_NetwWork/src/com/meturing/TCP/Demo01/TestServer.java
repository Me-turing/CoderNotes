package com.meturing.TCP.Demo01;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TestServer {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(8888);//监听指定接口
        Socket accept = serverSocket.accept();//阻塞线程 直到获取到数据
        InputStream inputStream = accept.getInputStream();//获取输入流
        DataInputStream dataInputStream = new DataInputStream(inputStream);//获取数据输入流
        String s = dataInputStream.readUTF();//读取指定类型数据
        System.out.println(s);
        dataInputStream.close();//关闭流
        inputStream.close();
        accept.close();
        serverSocket.close();
    }
}
