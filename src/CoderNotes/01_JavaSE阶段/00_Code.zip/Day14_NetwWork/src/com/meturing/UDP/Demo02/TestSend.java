package com.meturing.UDP.Demo02;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

public class TestSend {
    public static void main(String[] args) throws IOException {
        System.out.println("发送端打开~~~");
        //指定客户端的接口
        DatagramSocket datagramSocket = new DatagramSocket(8888);
        String str = "您好~!";
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        //向指定接口发送数据
        /**
         * 内容，长度，地址，接口
         */
        DatagramPacket localhost = new DatagramPacket(bytes, bytes.length, InetAddress.getByName("localhost"),9999);
        //发送数据包
        datagramSocket.send(localhost);

        //接受反馈
        byte[] bytes1 = new byte[1024];
        DatagramPacket datagramPacket = new DatagramPacket(bytes1, bytes1.length);
        datagramSocket.receive(datagramPacket);
        byte[] data = datagramPacket.getData();
        String s = new String(data, "UTF-8");
        System.out.println(s);


        //关闭发送端接口
        datagramSocket.close();
    }
}
