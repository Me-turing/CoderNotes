package com.meturing.UDP.Demo04;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class TestReceive {
    public static void main(String[] args)  {
        DatagramSocket datagramSocket = null;
        Scanner scanner = null;
        try {
            System.out.println("接收端上线~！");
            datagramSocket = new DatagramSocket(9999);
            scanner = new Scanner(System.in);
            while (true) {
                byte[] bytes = new byte[1024];
                DatagramPacket datagramPacket = new DatagramPacket(bytes, bytes.length);
                datagramSocket.receive(datagramPacket);

                byte[] data = datagramPacket.getData();
                String s = new String(data, "UTF-8");
                System.out.println(s);
                if (s.equals("byebye"))break;

                System.out.println("请输入消息");
                String str = scanner.next();
                byte[] bytes1 = str.getBytes();
                DatagramPacket localhost = new DatagramPacket(bytes1, bytes1.length, InetAddress.getByName("localhost"), 8888);
                datagramSocket.send(localhost);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (datagramSocket == null) {
                    datagramSocket.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}
