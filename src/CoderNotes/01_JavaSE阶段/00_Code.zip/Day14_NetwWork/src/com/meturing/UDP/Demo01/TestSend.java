package com.meturing.UDP.Demo01;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;

public class TestSend {
    public static void main(String[] args) throws IOException {
        System.out.println("发送端打开~~~");
        //指定客户端的接口
        DatagramSocket datagramSocket = new DatagramSocket(8888);
        String str = "您好~!";
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        //向指定接口发送数据
        /**
         * 内容，长度，地址，接口
         */
        DatagramPacket localhost = new DatagramPacket(bytes, bytes.length, InetAddress.getByName("localhost"),9999);
        //发送数据包
        datagramSocket.send(localhost);
        //关闭发送端接口
        datagramSocket.close();
    }
}
