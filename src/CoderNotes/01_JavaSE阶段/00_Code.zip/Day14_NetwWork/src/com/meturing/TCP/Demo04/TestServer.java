package com.meturing.TCP.Demo04;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class TestServer {
    public static void main(String[] args) {
        ServerSocket serverSocket = null;//监听指定接口
        Socket accept = null;//阻塞线程 直到获取到数据
        InputStream inputStream = null;//获取输入流
        ObjectInputStream objectInputStream = null;
        OutputStream outputStream = null;
        DataOutputStream dataOutputStream = null;
        try {
            serverSocket = new ServerSocket(8888);
            accept = serverSocket.accept();
            inputStream = accept.getInputStream();

            //获取数据输入流
            objectInputStream = new ObjectInputStream(inputStream);
            UserInfo userInfo = (UserInfo)objectInputStream.readObject();
            System.out.println("服务器收到："+userInfo.toString());

            //判断是否正确
            boolean flag = false;
            if (userInfo.getName().equals("张三") && userInfo.getPwd().equals("123456")){
                flag = true;
                System.out.println("服务器验证成功！");
            }else {
                System.out.println("服务器验证失败！");
            }
            //返回状态
            outputStream = accept.getOutputStream();
            dataOutputStream = new DataOutputStream(outputStream);
            dataOutputStream.writeBoolean(flag);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            //关闭流
            if (dataOutputStream == null) {
                try {
                    dataOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (outputStream == null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (objectInputStream == null) {
                try {
                    objectInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (inputStream == null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (accept == null) {
                try {
                    accept.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (serverSocket == null) {
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
