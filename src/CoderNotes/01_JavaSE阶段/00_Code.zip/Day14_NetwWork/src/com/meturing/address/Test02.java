package com.meturing.address;

import java.net.InetAddress;
import java.net.InetSocketAddress;

public class Test02 {
    //这是一个main方法，是程序的入口：
    public static void main(String[] args) {
        InetSocketAddress isa = new InetSocketAddress("localhost",8080);
        System.out.println(isa);// localhost/127.0.0.1:8080
        System.out.println(isa.getHostName());//localhost
        System.out.println(isa.getPort());//8080
        InetAddress ia = isa.getAddress();//转为InetAddress
        System.out.println(ia.getHostName());//localhost
        System.out.println(ia.getHostAddress());//127.0.0.1
    }
}
