package com.meturing.TCP.Demo05;


import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class ThreadServer extends Thread{
    ServerSocket serverSocket = null;
    Socket accept = null;
    InputStream inputStream = null;
    ObjectInputStream objectInputStream = null;
    OutputStream outputStream = null;
    DataOutputStream dataOutputStream = null;

    public ThreadServer(Socket accept) {
        this.accept = accept;
    }

    @Override
    public void run() {
        try {
            if (accept==null)return;
            inputStream = accept.getInputStream();
            objectInputStream = new ObjectInputStream(inputStream);
            UserInfo userInfo = (UserInfo) (objectInputStream.readObject());
            boolean flage = false;
            if (userInfo.getName().equals("张三")&&userInfo.getPwd().equals("123456")){
                flage = true;
                System.out.println("⌈服务器消息⌋ 用户："+userInfo.getName()+"--登录成功~!");
            }else {
                System.out.println("⌈服务器消息⌋ 用户："+userInfo.getName()+"--登录失败~!");
            }
            outputStream = accept.getOutputStream();
            dataOutputStream = new DataOutputStream(outputStream);
            dataOutputStream.writeBoolean(flage);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            //关闭流
            if (dataOutputStream != null) {
                try {
                    dataOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (objectInputStream != null) {
                try {
                    objectInputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
