package com.meturing.map;

import java.util.*;

public class Test01 {
    public static void main(String[] args) {
         /*
            增加：put(K key, V value)
            删除：clear() remove(Object key)
            修改：
            查看：entrySet() get(Object key) keySet() size() values()
            判断：containsKey(Object key) containsValue(Object value)
                equals(Object o) isEmpty()
         */
        HashMap<String, Integer> map = new HashMap<>();
        System.out.println(map.put("lili", 10101010)); //null  返回如果存在的话，在Map中的value
        map.put("nana",12345234);
        map.put("feifei",34563465);
        System.out.println(map.put("lili", 34565677)); //对已存在的Key继续添加数据，会覆盖之前的值 10101010 =》 34565677
        map.put("mingming",12323);
        System.out.println(map); // {nana=12345234, lili=34565677, mingming=12323, feifei=34563465}

        // 移除指定的Key
//        map.remove("lili");
//        System.out.println(map);// {nana=12345234, mingming=12323, feifei=34563465}
        // 清空
//        map.clear();
//        System.out.println(map); // {}
        System.out.println(map.size()); //获取Map中使用的长度

        // 判断
        System.out.println(map.containsKey("lili"));//判断指定的Key是否存在 true
        System.out.println(map.containsValue(123123132));//判断指定的Value是否存在 false
        HashMap<String, Integer> map1 = new HashMap<>();
        map1.put("lili",10101010);
        System.out.println(map == map1); //比较的是地址是否一致  false
        System.out.println(map.equals(map1));//map重写了equse方法，比较的是内容是否相等 false
        System.out.println(map.isEmpty());// 判断Map中是否为空  false

        // Map的遍历方式 6种
        // 第一组：通过 map.keySet()获取包含Map的Key的Set集合,通过map.get(key)获取Value   遍历 =》 增强for或迭代器
        Set<String> set = map.keySet();
        for (String s : set) {
            System.out.print(map.get(s) +"\t");
        }
        System.out.println();
        Iterator<String> iterator = set.iterator();
        while (iterator.hasNext()) {
            System.out.print(map.get(iterator.next())+"\t");
        }
        System.out.println();

        // 第二组：通过 map.values()获得一个包含Value的Collection集合  遍历 =》 增强for或迭代器
        Collection<Integer> values = map.values();
        for (Integer value : values) {
            System.out.print(value+"\t");
        }
        System.out.println();
        Iterator<Integer> iterator1 = values.iterator();
        while (iterator1.hasNext()) {
            System.out.print(iterator1.next()+"\t");
        }
        System.out.println();

        //第三组：通过EntrySet 获取 k-v 遍历 =》 增强for或迭代器
        Set<Map.Entry<String, Integer>> entries = map.entrySet();
        for (Map.Entry<String, Integer> entry : entries) {
            System.out.print(entry.getKey() + "----" + entry.getValue() + "\t");
        }
        System.out.println();
        Iterator<Map.Entry<String, Integer>> iterator2 = entries.iterator();
        while (iterator2.hasNext()) {
            Map.Entry<String, Integer> next = iterator2.next();
            System.out.print(next.getKey() + "----" + next.getValue() + "\t");
        }
    }
}
