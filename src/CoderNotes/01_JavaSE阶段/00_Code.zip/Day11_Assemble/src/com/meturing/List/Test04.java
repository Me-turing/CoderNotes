package com.meturing.List;

import java.util.Iterator;
import java.util.LinkedList;

public class Test04 {
    public static void main(String[] args) {
        /*
        LinkedList常用方法：
        增加 addFirst(E e) addLast(E e)
             offer(E e) offerFirst(E e) offerLast(E e)
        删除 poll()
            pollFirst() pollLast()  ---》JDK1.6以后新出的方法，提高了代码的健壮性
            removeFirst() removeLast()
        修改
        查看 element()
             getFirst()  getLast()
             indexOf(Object o)   lastIndexOf(Object o)
             peek()
             peekFirst() peekLast()
        判断
         */
        LinkedList<String> list = new LinkedList<>();
        /*
         * add（不带索引默认添加到链表的最后）与offer一样都是添加操作，
         * 唯一的区别就是offer没有带索引参数的方法，并且如果队列满了add会抛出异常，而offer不会。
         * */
        //新增
        list.add("aaaaa");
        list.add("bbbbb");
        list.add("ccccc");
        list.add("ddddd");
        list.add("eeeee");
        list.add("bbbbb");
        list.add("fffff");
        //添加到头部
        list.addFirst("begin");
        //添加到末尾
        list.addLast("end");
        //添加元素在尾端
        list.offer("offer");
        //添加到头部
        list.offerFirst("offerFirst");
        //添加到末尾
        list.offerLast("offerLast");
        System.out.println(list); // [offerFirst, begin, aaaaa, bbbbb, ccccc, ddddd, eeeee, bbbbb, fffff, end, offer, offerLast]
        //删除
        System.out.println(list.poll());//删除头上的元素并且将元素输出 offerFirst
        System.out.println(list.pollFirst());//删除第一个的元素并且将元素输出 begin
        System.out.println(list.pollLast());//删除末尾的元素并且将元素输出 offerLast
        System.out.println(list); // [aaaaa, bbbbb, ccccc, ddddd, eeeee, bbbbb, fffff, end, offer]

        System.out.println(list.removeFirst()); //删除第一个的元素并且将元素输出 begin
        System.out.println(list.removeLast());//删除末尾的元素并且将元素输出 offer
        System.out.println(list); // [bbbbb, ccccc, ddddd, eeeee, bbbbb, fffff, end]

        String peek = list.peekLast();
        System.out.println(peek);


        //清空集合
/*        list.clear();
        System.out.println(list);// []*/
/*
        //集合的遍历：
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next()+"\t");
        }
        System.out.println();
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i)+"\t");
        }
        System.out.println();
        for (Object o : list) {
            System.out.print(o+"\t");
        }
        System.out.println();
        //下面这种方式好，节省内存
        for (Iterator<String> iterator1 = list.iterator();iterator1.hasNext();){
            System.out.println(iterator1.next());
        }*/
    }
}
