package com.meturing.Set;

import java.util.HashSet;

public class Test02 {
    public static void main(String[] args) {
        HashSet<String> hs = new HashSet<>();
        hs.add("hello");
        System.out.println(hs.add("apple"));//true
        hs.add("banana");
        hs.add("html");
        System.out.println(hs.add("apple"));//false 无法存放
        hs.add("css");
        System.out.println(hs.size());
        System.out.println(hs);
    }
}
