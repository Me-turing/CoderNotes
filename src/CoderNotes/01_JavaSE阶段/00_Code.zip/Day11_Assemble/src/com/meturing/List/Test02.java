package com.meturing.List;

import java.util.ArrayList;
import java.util.List;

public class Test02 {
    public static void main(String[] args) {
        List<Object> objects = new ArrayList<>();
        List<Person> person = new ArrayList<>();
        List<Student> students = new ArrayList<>();

        /*测试：泛型上限*/
        List<? extends Person> list = null;
        // list = objects;  报错，Object是Person的父类
        list = person;
        list = students;

        /*测试：泛型下限*/
        List<? super Person> list1 = null;
        list1 = objects;
        list1 = person;
        // list1 = students; 报错，Object是Person的子类
    }
}
class Person{}
class Student extends Person{}