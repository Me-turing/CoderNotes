package com.meturing.Queue;

import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;

public class TestSynchronousQueue {
    public static void main(String[] args) throws InterruptedException {
        testPoll();
    }

    /**
     * 非阻塞类型
     * @throws InterruptedException
     */
    public static  void testTake() throws InterruptedException {
        SynchronousQueue<Object> synchronousQueue1 = new SynchronousQueue<>();
        SynchronousQueue<Object> synchronousQueue2 = new SynchronousQueue<>();
        SynchronousQueue<Object> synchronousQueue3 = new SynchronousQueue<>();

        new Thread(()->{
            while (true){
                try {
                    System.out.println("线程："+Thread.currentThread().getName()+" 数据："+synchronousQueue1.take());
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },"Thread01").start();

        new Thread(()->{
            while (true){
                try {
                    System.out.println("线程："+Thread.currentThread().getName()+" 数据："+synchronousQueue3.take());
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },"Thread02").start();

        new Thread(()->{
            while (true){
                try {
                    System.out.println("线程："+Thread.currentThread().getName()+" 数据："+synchronousQueue3.take());
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },"Thread03").start();

        synchronousQueue1.put("a");
        synchronousQueue2.put("b");
        synchronousQueue3.put("c");
    }

    /**
     * 阻塞类型
     * @throws InterruptedException
     */
    public static void testPoll() throws InterruptedException {
        SynchronousQueue<Object> synchronousQueue1 = new SynchronousQueue<>();
        SynchronousQueue<Object> synchronousQueue2 = new SynchronousQueue<>();
        SynchronousQueue<Object> synchronousQueue3 = new SynchronousQueue<>();

        new Thread(()->{
            while (true){
                try {
                    Object poll = synchronousQueue1.poll(5, TimeUnit.SECONDS);
                    if (poll==null) break;
                    System.out.println("线程："+Thread.currentThread().getName()+" 数据："+poll);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },"Thread01").start();

        new Thread(()->{
            while (true){
                try {
                    Object poll = synchronousQueue2.poll(5, TimeUnit.SECONDS);
                    if (poll==null) break;
                    System.out.println("线程："+Thread.currentThread().getName()+" 数据："+poll);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },"Thread02").start();

        new Thread(()->{
            while (true){
                try {
                    Object poll = synchronousQueue3.poll(5, TimeUnit.SECONDS);
                    if (poll==null) break;
                    System.out.println("线程："+Thread.currentThread().getName()+" 数据："+poll);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },"Thread03").start();

        synchronousQueue1.put("a");
        synchronousQueue2.put("b");
        synchronousQueue3.put("c");
    }
}
