package com.meturing.Set;

import java.util.HashSet;

public class Test01 {
    public static void main(String[] args) {
        HashSet<Integer> hashSet = new HashSet<>();
        hashSet.add(15);
        hashSet.add(26);
        System.out.println(hashSet.add(26));//false 这个26没有放入到集合中
        System.out.println(hashSet.add(7));//true
        hashSet.add(18);
        System.out.println(hashSet.size());
        System.out.println(hashSet);//唯一，无序
    }
}
