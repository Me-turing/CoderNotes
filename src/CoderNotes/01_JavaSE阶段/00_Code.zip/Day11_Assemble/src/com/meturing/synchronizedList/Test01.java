package com.meturing.synchronizedList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test01 {
    public static void main(String[] args) {
        ArrayList<String> oldList = new ArrayList<>();
        //将普通集合转换成同步类集合
        List<String> list = Collections.synchronizedList(oldList);

        //创建一个线程池
        ExecutorService executorService = Executors.newFixedThreadPool(100);

        //并发使用线程向同一个集合中塞入数据
        for (int i = 0; i < 10000; i++) {
            executorService.execute(new Runnable() {
                @Override
                public void run() {
                    list.add("A");
                }
            });
        }
        //关闭线程
        executorService.shutdown();

        //检查线程是否执行完毕
        while (true){
            //线程都执行完以后返回true
            if (executorService.isTerminated()){
                System.out.println("所有的线程都执行完毕");
                System.out.println(list.size());
                if (list.size()==10000){
                    System.out.println("线程安全！");
                }else{
                    System.out.println("线程不安全！");
                }
                break;
            }
        }
    }
}
