package com.meturing.Set;

import java.util.TreeSet;

public class Test05 {
    public static void main(String[] args) {
        TreeSet<String> strings = new TreeSet<>();
        strings.add("1");
        strings.add("3");
        strings.add("0");
        strings.add("1");
        System.out.println(strings.size());
        System.out.println(strings);
    }
}
