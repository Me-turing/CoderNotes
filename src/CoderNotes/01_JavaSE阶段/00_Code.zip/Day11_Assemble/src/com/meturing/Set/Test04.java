package com.meturing.Set;

public class Test04 {
    public static void main(String[] args) {
//        int a = 10;
//        int b = 20;
//        System.out.println(a-b);

//        String a = "10";
//        String b = "20";
//        System.out.println(a.compareTo(b));

        double a = 1.0;
        double b = 2.0;
        System.out.println(((Double)a).compareTo(((Double)b)));
    }
}
