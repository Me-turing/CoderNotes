package com.meturing.Queue;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

public class TestDelayQueue {
    DelayQueue<User> delayQueue = new DelayQueue<User>();
    public static void main(String[] args) {
        TestDelayQueue testDelayQueue = new TestDelayQueue();
        testDelayQueue.login(new User("zs1","张三",System.currentTimeMillis()+5000));
        testDelayQueue.login(new User("ls1","李四",System.currentTimeMillis()+2000));
        testDelayQueue.login(new User("ww1","王五",System.currentTimeMillis()+10000));

        while (true){
            testDelayQueue.loginOut();
            if (testDelayQueue.getUserSUM()<=0) break;
        }


    }

    /**
     * 登录
     * @param user
     */
    public void login(User user){
        delayQueue.put(user);
        System.out.println("用户：["+user.getUserId()+"] "+user.getUserName()+" 已登录游戏");
    }

    /**
     * 登出
     */
    public void loginOut(){
        try {
            User take = delayQueue.take();
            System.out.println("用户：["+take.getUserId()+"] "+take.getUserName()+" 时间到，登出游戏~");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 获取人数
     * @return
     */
    public int getUserSUM(){
        return delayQueue.size();
    }
}

class User implements Delayed{

    String UserId;//用户ID
    String UserName;//用户名
    Long endTime;//到期时间

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String userId) {
        UserId = userId;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public User(String userId, String userName, Long endTime) {
        UserId = userId;
        UserName = userName;
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return "User{" +
                "UserId='" + UserId + '\'' +
                ", UserName='" + UserName + '\'' +
                "}";
    }

    @Override
    public long getDelay(TimeUnit unit) {
        //到期时间小于系统时间，退出队列
        return this.getEndTime()-System.currentTimeMillis();
    }

    @Override
    public int compareTo(Delayed o) {
        //按照到期时间按排序
        User u = (User) o;
        return ((Long)this.endTime).compareTo((Long) u.endTime);
    }
}