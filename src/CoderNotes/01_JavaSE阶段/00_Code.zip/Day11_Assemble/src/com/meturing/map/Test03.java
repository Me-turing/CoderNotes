package com.meturing.map;

import java.util.Comparator;
import java.util.TreeMap;

public class Test03 {
    public static void main(String[] args) {

        // 匿名内部类创建比较器
        TreeMap<Student, Integer> map2 = new TreeMap<>(new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });
        // Lambda表达式写法
        TreeMap<Student, Integer> map1 = new TreeMap<>((s1,s2)->s1.getName().compareTo(s2.getName()));
        map1.put(new Student("Alili",19,170.5),1001);
        map1.put(new Student("Clili",12,180.0),1003);
        map1.put(new Student("Blili",17,170.3),1004);
        map1.put(new Student("Dlili",17,160.5),1002);
        System.out.println(map1);
    }
}

//class Student implements Comparable<Student>{
class Student{
    String name;
    Integer age;
    double height;

    public Student(String name, Integer age, double height) {
        this.name = name;
        this.age = age;
        this.height = height;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", height=" + height +
                '}';
    }
}
