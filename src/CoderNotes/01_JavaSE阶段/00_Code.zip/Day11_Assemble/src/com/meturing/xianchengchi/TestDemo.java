package com.meturing.xianchengchi;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestDemo {
    public static void main(String[] args) throws InterruptedException {
        ExecutorService fixedThreadPool = Executors.newFixedThreadPool(2);
        for (int i = 0; i < 10; i++) {
            int finalI = i;
            fixedThreadPool.execute(()->{
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println(Thread.currentThread().getName() + ":" + finalI);
            });
        }
    }
}
