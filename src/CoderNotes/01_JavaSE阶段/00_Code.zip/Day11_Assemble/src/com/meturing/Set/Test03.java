package com.meturing.Set;

import java.util.HashSet;
import java.util.Objects;

public class Test03 {
    public static void main(String[] args) {
        HashSet<Student> students = new HashSet<>();
        students.add(new Student("张三",19));
        students.add(new Student("李四",11));
        students.add(new Student("王五",18));
        students.add(new Student("张三",19));
        System.out.println(students.size());
        System.out.println(students);//引用类型可以重复放入
    }
}
class Student{
    String name;
    int age;
    public Student(String name,int age){
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return age == student.age && Objects.equals(name, student.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age);
    }
}
