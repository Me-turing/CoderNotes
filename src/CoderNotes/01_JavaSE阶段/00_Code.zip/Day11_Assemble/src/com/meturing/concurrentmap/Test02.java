package com.meturing.concurrentmap;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test02 {
    public static void main(String args[]) {
        String str = "1e++01";
        String pattern = "[0-9]*[.]?[0-9]+e[+|-]?[0-9]+";

        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(str);
        System.out.println(m.matches());

        System.out.println(Pattern.matches("[0-9]*[.]?[0-9]+e[+|-]?[0-9]+", str));
    }
}
