package com.meturing.List;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class Test01 {
    public static void main(String[] args) {
        /*
            List接口中常用方法：
            增加：add(int index, E element)
            删除：remove(int index)  remove(Object o)
            修改：set(int index, E element)
            查看：get(int index)
            判断：
         */

        List list = new ArrayList();
        //新增
        list.add(13);
        list.add(17);
        list.add(6);
        list.add(-1);
        list.add(2);
        list.add("abc");
        System.out.println(list);
        // 指定位置新增（插入）
        list.add(3,66);
        System.out.println(list);
        // 修改
        list.set(3,77);
        System.out.println(list);
        // 移除指定的坐标元素
        list.remove(2);
        System.out.println(list);
        // 移除指定的元素
        list.remove("abc");
        System.out.println(list);
        // 获取指定下标的元素
        Object o = list.get(0);
        System.out.println(o);

        ArrayList arrayList = new ArrayList();
        arrayList.add(123);


        //循环遍历
        System.out.println();
        System.out.println("使用for循环：");
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i)+"\t");
        }
        System.out.println();
        System.out.println("使用增强for循环：");
        for (Object object : list) {
            System.out.print(object+"\t");
        }
        System.out.println();
        System.out.println("使用Lambda表达式：");
        list.stream().forEach(s-> System.out.print(s+"\t"));
        System.out.println();
        System.out.println("使用迭代器：");
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next()+"\t");
        }
    }
}
