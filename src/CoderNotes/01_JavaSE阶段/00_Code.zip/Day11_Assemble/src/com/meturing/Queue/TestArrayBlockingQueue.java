package com.meturing.Queue;

import sun.reflect.generics.tree.Tree;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

public class TestArrayBlockingQueue {
    public static void main(String[] args) throws InterruptedException {
        ArrayBlockingQueue queue = new ArrayBlockingQueue(3);
        //【1】添加null元素：不可以添加null元素，会报空指针异常：NullPointerException
        //queue.add(null);
        queue.add('a');
        queue.add('b');
        queue.add('c');

        //【2】由于当前队列处于满载情况，我们无法添加直接抛出异常 Queue full
        //System.out.println(queue.add('c'));


        //【3】 创建一个独立的线程，测试阻塞添加
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //【3】指定时间等阻塞添加，失败则返回false
                    System.out.println(queue.offer("e", 3, TimeUnit.MILLISECONDS));//flase
                    //【4】完全阻塞添加
                    queue.put('f');
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();
        Thread.sleep(100);//休眠1S

        //【5】获取队列头，不移除
        System.out.println(queue.peek());//a
        System.out.println(queue);//[a, b, c]

        //【6】获取队列头，且移除
        System.out.println(queue.poll());//a
        System.out.println(queue);//[b, c]
        Thread.sleep(100);//休眠1S
        System.out.println(queue);//[b, c, f]

        //【7】获取队列头，且移除(阻塞)
        System.out.println(queue.take());//b
        System.out.println(queue);//[c, f]

        //【8】清空元素
        queue.clear();
        System.out.println(queue);//[]

        System.out.println(queue.peek());//null
        System.out.println(queue.poll());//null

        //测试阻塞
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    //指定时间阻塞式获取
                    System.out.println(queue.poll(2,TimeUnit.MILLISECONDS));
                    //永久阻塞式获取
                    System.out.println("开始强制获取.....");
                    System.out.println(queue.take());
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }).start();

        Thread.sleep(2000);//休眠2s
        queue.add("a");
    }
}
