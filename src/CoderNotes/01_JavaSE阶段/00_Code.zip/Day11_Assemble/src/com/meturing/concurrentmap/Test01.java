//package com.meturing.concurrentmap;
//
//import java.util.Collections;
//import java.util.HashMap;
//import java.util.Hashtable;
//import java.util.Map;
//import java.util.concurrent.ConcurrentHashMap;
//
//public class Test01 {
//    public static void main(String[] args) {
//        //测试ConcurrentHashMap
//        ConcurrentHashMap<String,Integer> concurrentHashMap = new ConcurrentHashMap<>();
////        //创建10个线程
//        for (int i = 0; i < 10; i++) {
//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    long startTime = System.currentTimeMillis();
//                    for (int j = 0; j < 1000000; j++) {
//                        concurrentHashMap.put("a"+j,j);
//                    }
//                    long endTime = System.currentTimeMillis();
//                    System.out.println("耗时："+(endTime-startTime));
//                }
//            }).start();
//        }
//
//        //测试普通容器转换成同步容器
////        HashMap<String, Integer> stringIntegerHashMap = new HashMap<>();
////        Map<String, Integer> stringIntegerMap = Collections.synchronizedMap(stringIntegerHashMap);
////        for (int i = 0; i < 10; i++) {
////            new Thread(new Runnable() {
////                @Override
////                public void run() {
////                    long startTime = System.currentTimeMillis();
////                    for (int j = 0; j < 1000000; j++) {
////                        stringIntegerMap.put("A"+j,j);
////                    }
////                    long endTime = System.currentTimeMillis();
////                    System.out.println("耗时："+(endTime-startTime));
////                }
////            }).start();
////        }
//
//        //测试安全性集合
////        Hashtable<String, Integer> stringIntegerHashtable = new Hashtable<>();
////        for (int i = 0; i < 10; i++) {
////            new Thread(new Runnable() {
////                @Override
////                public void run() {
////                    long startTime = System.currentTimeMillis();
////                    for (int j = 0; j < 1000000; j++) {
////                        stringIntegerHashtable.put("A"+j,j);
////                    }
////                    long endTime = System.currentTimeMillis();
////                    System.out.println("耗时："+(endTime-startTime));
////                }
////            }).start();
////        }
//    }
//}
