package com.meturing.Queue;

import java.util.concurrent.PriorityBlockingQueue;

public class TestPriorityBlockingQueue {
    public static void main(String[] args) {
        PriorityBlockingQueue<Student> priorityBlockingQueue = new PriorityBlockingQueue<Student>();
        priorityBlockingQueue.put(new Student("张三", 19));
        priorityBlockingQueue.put(new Student("李四", 10));
        priorityBlockingQueue.put(new Student("王五", 29));
        priorityBlockingQueue.put(new Student("赵六", 1));
        System.out.println(priorityBlockingQueue);
    }
}
class Student implements Comparable<Student>{
    String name;
    int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    @Override
    public int compareTo(Student o) {
        return this.age - o.age;
    }
}
