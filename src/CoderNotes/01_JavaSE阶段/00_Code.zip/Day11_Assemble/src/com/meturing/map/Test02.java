package com.meturing.map;

import java.util.TreeMap;

public class Test02 {
    public static void main(String[] args) {
        TreeMap<String, Integer> map = new TreeMap<>();
        map.put("Blili",1234);
        map.put("Alili",444);
        map.put("Blili",124);
        map.put("Clili",134);
        map.put("Dlili",234);
        System.out.println(map.size());
        System.out.println(map);
    }
}
