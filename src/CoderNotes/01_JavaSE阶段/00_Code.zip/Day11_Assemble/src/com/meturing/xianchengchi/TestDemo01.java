package com.meturing.xianchengchi;

public class TestDemo01 {
    public static void main(String[] args) {
        TestDemo01 testDemo01 = new TestDemo01();
        testDemo01.threadDemo(10);
        testDemo01.threadDemo(20);
    }
    public  void threadDemo(int a){
        int b = a;
        new Thread(()->{
            System.out.println(b);
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(b);
        }).start();
        System.out.println(a+"xxxxx");
    }
}
