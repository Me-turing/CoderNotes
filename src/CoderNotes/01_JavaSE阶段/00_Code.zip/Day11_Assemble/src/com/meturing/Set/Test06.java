package com.meturing.Set;

import java.util.TreeSet;

public class Test06 {
    public static void main(String[] args) {
        TreeSet<Students> students = new TreeSet<>();
        students.add(new Students("张三1",16));
        students.add(new Students("张三4",18));
        students.add(new Students("张三3",15));
        students.add(new Students("张三2",10));
        System.out.println(students);
    }
}

class Students {
    String name;
    int age;

    public Students(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Students{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
