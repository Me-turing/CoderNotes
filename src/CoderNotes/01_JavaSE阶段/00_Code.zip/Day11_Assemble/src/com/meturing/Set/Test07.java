package com.meturing.Set;

import java.util.TreeSet;

public class Test07 {
    public static void main(String[] args) {
        TreeSet<Student1> students = new TreeSet<>();
        students.add(new Student1("张三1",16));
        students.add(new Student1("张三4",18));
        students.add(new Student1("张三3",15));
        students.add(new Student1("张三2",10));
        System.out.println(students);
    }
}

/**
 * 使用内部比较器
 */
class Student1 implements Comparable<Student1>{
    String name;
    int age;

    public Student1(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Students{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    @Override
    public int compareTo(Student1 o) {
        return this.age-o.age;
    }
}
