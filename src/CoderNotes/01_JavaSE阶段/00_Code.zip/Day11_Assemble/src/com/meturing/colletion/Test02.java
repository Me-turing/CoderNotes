package com.meturing.colletion;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Test02 {
    public static void main(String[] args) {
        Collection arrayList = new ArrayList();
        arrayList.add(12);
        arrayList.add(13);

        // 增强For循环
        for (Object o : arrayList) {
            System.out.println(o);
        }
        System.out.println("===============");

        //Lambda 表达式输出
//        arrayList.forEach(System.out::println);

        System.out.println("===============");
        /**
         *  迭代器循环遍历
         *  集合对象.iterator();  创建迭代器对象
         *  迭代器对象.hasNext()  是否存在下一个元素
         *  迭代器对象.next()     获取当前元素，并下移指针
         */
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}
