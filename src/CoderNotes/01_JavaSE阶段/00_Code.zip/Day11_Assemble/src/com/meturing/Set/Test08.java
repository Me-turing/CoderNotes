package com.meturing.Set;

import java.util.Comparator;
import java.util.TreeSet;

public class Test08 {
    public static void main(String[] args) {
        //创建比较器对象
        compareToStudent compareToStudent = new compareToStudent();
        // 通过构造函数将比较器传送到TreeSet中
        TreeSet<Student2> students = new TreeSet<>(compareToStudent);
        students.add(new Student2("张三1",16));
        students.add(new Student2("张三4",18));
        students.add(new Student2("张三3",15));
        students.add(new Student2("张三2",10));
        System.out.println(students);
    }
}

/**
 * 使用内部比较器
 */
class Student2{
    String name;
    int age;

    public Student2(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Students{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}

class compareToStudent  implements Comparator<Student2> {
    @Override
    public int compare(Student2 o1, Student2 o2) {
        return o1.age- o2.age;
    }
}
