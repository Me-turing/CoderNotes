package com.meturing.stack;

import java.util.Stack;

public class Test01 {
    public static void main(String[] args) {
        /*
        Stack是Vector的子类，Vector里面两个重要的属性：
        Object[] elementData;底层依然是一个数组
        int elementCount;数组中的容量
         */
        Stack<String> stackStr = new Stack<>();
        stackStr.add("A");//返回添加结果
        stackStr.add("D");
        stackStr.add("B");
        System.out.println(stackStr);//[A, D, B]

        System.out.println("是否为空？ "+stackStr.empty());//false

        System.out.println("查看栈顶的数据不移除："+stackStr.peek());//B
        System.out.println(stackStr);//[A, D, B]

        System.out.println("查看栈顶的数据并移除："+stackStr.pop());//B
        System.out.println(stackStr);//[A, D]

        stackStr.push("B");//和ADD方法执行的底层一样，只是返回了添加的数据
        System.out.println(stackStr);//[A, D, B]
    }
}
