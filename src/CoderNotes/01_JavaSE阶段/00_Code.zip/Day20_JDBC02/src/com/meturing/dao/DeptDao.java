package com.meturing.dao;

import com.meturing.pojo.Dept;

import java.util.List;

/**
 * DAO 接口
 */
public interface DeptDao {
    /**
     * 添加 Dept
     * @param dept
     * @return
     */
    int addDept(Dept dept);

    /**
     * 删除 Dept
     * @param dept
     * @return
     */
    int deleteDept(Dept dept);

    List<Dept> selectDepts(Dept dept);
}
