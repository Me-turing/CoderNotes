package com.meturing.main;

import com.meturing.dao.DeptDao;
import com.meturing.dao.impl.DeptDaoImpl;
import com.meturing.dao.impl.DeptDaoImpl2;
import com.meturing.pojo.Dept;

import java.util.Arrays;
import java.util.List;

public class TestDemo01 {
    public static void main(String[] args) {
/*        DeptDao deptDao = new DeptDaoImpl();

        Dept dept = new Dept(888, "张三", "aaa");
        int i = deptDao.addDept(dept);
        System.out.println("受影响的行数:"+i);

        Dept dept1 = new Dept(888, "张三", "aaa");
        int i1 = deptDao.deleteDept(dept1);
        System.out.println("受影响的行数:"+i1);*/


        DeptDao deptDao1 = new DeptDaoImpl2();
        Dept dept2 = new Dept(888, "张三", "aaa");
        int i2 = deptDao1.addDept(dept2);
        System.out.println("受影响的行数:"+i2);

        Dept dept3 = new Dept(888, "张三", "aaa");
        List<Dept> depts = deptDao1.selectDepts(dept3);
        System.out.println("查询结果:"+depts.toString());
    }
}
