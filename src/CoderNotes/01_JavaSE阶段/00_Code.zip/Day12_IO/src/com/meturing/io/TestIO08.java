package com.meturing.io;

import java.io.*;

/**
 * 使用字符转换流达到文件复制
 * 、
 * 注意：转换流在使用的时候可以指定编码格式，如果不指定则为当前的程序编码格式一致
 */
public class TestIO08 {
    public static void main(String[] args) throws IOException {
        //创建File对象
        File fileIn = new File("D:" + File.separatorChar + "Demo.txt");
        File fileOut = new File("D:" + File.separatorChar + "DemoCopy.txt");

        FileInputStream fileInputStream = new FileInputStream(fileIn);//字节流
        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);//FileInputStream-> InputStreamReader 字符流

        FileOutputStream fileOutputStream = new FileOutputStream(fileOut);//字节流
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);//FileOutputStream-> OutputStreamWriter 字符流

        char[] chars = new char[8];
        int read = inputStreamReader.read(chars);
        while (read!=-1){
            outputStreamWriter.write(chars,0,read);
            read = inputStreamReader.read(chars);
        }

        outputStreamWriter.close();
        inputStreamReader.close();
    }
}
