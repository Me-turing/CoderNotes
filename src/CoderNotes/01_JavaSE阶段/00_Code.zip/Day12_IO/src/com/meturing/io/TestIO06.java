package com.meturing.io;

import java.io.*;

/**
 * 字节缓冲流
 */
public class TestIO06 {
    public static void main(String[] args) throws IOException {
        //构建File
        File fileIn = new File("D:" + File.separatorChar + "Demo.png");
        File fileOut = new File("D:" + File.separatorChar + "DemoCopy.png");
        //创建字节流
        FileInputStream fileInputStream = new FileInputStream(fileIn);
        FileOutputStream fileOutputStream = new FileOutputStream(fileOut);
        //字节缓冲流
        BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);

        byte[] bytes = new byte[1024 * 8];
        int read = bufferedInputStream.read(bytes);
        while (read!=-1){
            bufferedOutputStream.write(bytes,0,read);
            read = bufferedInputStream.read(bytes);
        }

        //如果处理流包裹着节点流的话，那么其实只要关闭高级流（处理流），那么里面的字节流也会随之被关闭。
        bufferedOutputStream.close();
        bufferedInputStream.close();
    }
}
