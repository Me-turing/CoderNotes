package com.meturing.io;

import java.io.*;

/**
 * 字节缓冲流
 */
public class TestIO07 {
    public static void main(String[] args) throws IOException {
        //创建File对象
        File fileIn = new File("D:" + File.separatorChar + "Demo.txt");
        File fileOut = new File("D:" + File.separatorChar + "DemoCopy.txt");
        //构建字节流
        FileReader fileReader = new FileReader(fileIn);
        FileWriter fileWriter = new FileWriter(fileOut);
        //字节缓冲流
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

        String str = bufferedReader.readLine();
        while (str!=null){
            bufferedWriter.write(str);
            bufferedWriter.newLine();
            str = bufferedReader.readLine();
        }
    }
}
