package com.meturing.io;

import java.io.*;
import java.util.Scanner;

/**
 * 使用控制台向文件录入信息
 */
public class TestIO10 {
    public static void main(String[] args) throws IOException {
        File file = new File("D:" + File.separatorChar + "SystemIn.txt");
        FileWriter fileWriter = new FileWriter(file);//字符流
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);//增强流

        InputStream inputStream = System.in;//字节流
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream,"UTF-8");//字符流
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);//增强流

        String str = bufferedReader.readLine();
        while (!str.equals("exit")){
            bufferedWriter.write(str);
            bufferedWriter.newLine();
            str = bufferedReader.readLine();
        }

        bufferedReader.close();
        bufferedWriter.close();
    }
}
