package com.meturing.io;


import java.io.*;

public class TestIO01 {
    /**
     * 读取指定char长度的字符，通过String函数转换成str
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        File file = new File("D:" + File.separatorChar + "newFile.txt");
        FileReader fileReader = new FileReader(file);
        char[] chars = new char[5];//缓冲数组
        // 按字符读取 如果读取不到则返回-1
        int read = fileReader.read(chars);//一次性读取指定char长度,并返回当前读取的数量
        while(read!= -1){
            String str = new String(chars, 0, read);//直接使用String读取char数组
            System.out.print(str);
            read = fileReader.read(chars);
        }
        fileReader.close();//关闭流
    }

    /**
     * 读取指定char长度的字符
     * @throws IOException
     */
    public void Test02() throws IOException {
        File file = new File("D:" + File.separatorChar + "newFile.txt");
        FileReader fileReader = new FileReader(file);
        char[] chars = new char[5];//缓冲数组
        // 按字符读取 如果读取不到则返回-1
        int read = fileReader.read(chars);//一次性读取指定char长度,并返回当前读取的数量
        while(read!= -1){
            for (int i = 0; i < read; i++) {
                System.out.print(chars[i]);
            }
            read = fileReader.read(chars);
        }
        fileReader.close();//关闭流
    }

    /**
     * 一个字符一个字符读取
     * @throws IOException
     */
    public void Test01() throws IOException {
        File file = new File("D:" + File.separatorChar + "newFile.txt");
        FileReader fileReader = new FileReader(file);
        // 按字符读取 如果读取不到则返回-1
        int read = fileReader.read();//读取一个字符
        while(read!= -1){
            System.out.println(read);
            read = fileReader.read();
        }
        fileReader.close();//关闭流
    }
}
