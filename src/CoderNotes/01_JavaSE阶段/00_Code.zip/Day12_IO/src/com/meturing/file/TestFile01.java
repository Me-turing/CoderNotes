package com.meturing.file;

import java.io.File;
import java.io.IOException;

public class TestFile01 {
    public static void main(String[] args) throws IOException {
        /**
         * 文件相关的操作
         */
//        File file = new File("D:\\新建文件夹.txt");
        File file1 = new File("D:/新建文件.txt");
        File file2 = new File("D:"+File.separatorChar+"newTest.txt");//推荐这种写法

        System.out.println("是否可读："+file2.canRead());
        System.out.println("是否可写："+file2.canWrite());
        System.out.println("文件名字："+file2.getName());
        System.out.println("上级目录："+file2.getParent());
        System.out.println("是否是一个目录："+file2.isDirectory());
        System.out.println("是否是一个文件："+file2.isFile());
        System.out.println("是否隐藏："+file2.isHidden());
        System.out.println("文件大小："+file2.length());
            System.out.println("文件是否存在："+file2.exists());

        //如果文件存在则删除
//        if (file2.exists()){
//            file2.delete();
//        }else {
//            //不存在则创建
//            file2.createNewFile();
//        }

        /**
         * 地址相关的操作
         */
        //比较两个对象的地址
        System.out.println(file1==file2);
        //比较两个文件的路径（即是否是同一个文件）
        System.out.println(file1.equals(file2));

        System.out.println("绝对路径："+file2.getAbsolutePath());//D:\newTest.txt
        System.out.println("相对路径："+file2.getPath());//D:\newTest.txt
        System.out.println("toString:"+file2.toString());//D:\newTest.txt
        System.out.println("-----------------");
        File file = new File("demo.txt");
        if (file.exists()) file.createNewFile();
        ////绝对路径指的就是：真实的一个精准的，完整的路径
        System.out.println("绝对路径："+file.getAbsolutePath());//E:\AllPerject\IDEAProject\MCA_Demo\JavaSE_Demo\demo.txt
        //相对路径：有一个参照物，相对这个参照物的路径。
        //在main方法中，相对位置指的就是：E:\AllPerject\IDEAProject\MCA_Demo\JavaSE_Demo
        //在junit的测试方法中，相对路径指的就是模块位置
        System.out.println("相对路径："+file.getPath());//demo.txt
        //toString的效果永远是  相对路径
        System.out.println("toString:"+file.toString());//demo.txt


        File file3 = new File("a/b/c/demo.txt");
        if (file3.exists()) file3.createNewFile();
        System.out.println("绝对路径："+file3.getAbsolutePath());//E:\AllPerject\IDEAProject\MCA_Demo\JavaSE_Demo\a\b\c\demo.txt
        System.out.println("相对路径："+file3.getPath());//a\b\c\demo.txt

    }
}
