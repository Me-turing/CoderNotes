package com.meturing.io;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TestIO02 {
    public static void main(String[] args) throws IOException {
        File file = new File("D:" + File.separatorChar + "Demo.txt");
        FileWriter fileWriter = new FileWriter(file,true);//默认为false 不执行追加

        //输出96 -> 、
//        fileWriter.write(96);

//        char[] chars = new char[5];
//        chars[0] = 'a';
//        chars[1] = 'b';
//        chars[2] = 'c';
//        chars[3] = 'd';
//        chars[4] = 'e';
//        fileWriter.write(chars);

        String str = "你好Java";
        fileWriter.write(str.toCharArray());
        fileWriter.close();
    }
}
