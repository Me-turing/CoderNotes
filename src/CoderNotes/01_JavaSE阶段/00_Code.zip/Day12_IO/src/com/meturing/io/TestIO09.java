package com.meturing.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

/**
 * Scanner扫描器
 */
public class TestIO09 {
    public static void main(String[] args) throws IOException {
        //简单的额IO输入
//        InputStream in = System.in;
//        int read = in.read();
//        System.out.println(read);

        //使用Scanner扫描器
//        Scanner scanner = new Scanner(System.in);
//        int i = scanner.nextInt();
//        System.out.println(i);

        //使用扫描器输出流中的数据
        Scanner scanner = new Scanner(new FileInputStream(new File("D:" + File.separatorChar + "Demo.txt")));
        while (scanner.hasNext()){
            System.out.println(scanner.next());
        }
    }
}
