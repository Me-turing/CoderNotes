package com.meturing.io;


import java.io.*;

public class TestIO03 {
    public static <Stirng> void main(String[] args) throws IOException {
        //创建复制文件对象
        File fileIn = new File("D:" + File.separatorChar + "Demo.txt");
        //创建输出对象
        File fileOut = new File("D:" + File.separatorChar + "DemoCopy.txt");
        //创建文件输入流
        FileReader fileReader = new FileReader(fileIn);
        //创建文件输出流
        FileWriter fileWriter = new FileWriter(fileOut);

        //方式一  一个一个读和写
//        int read = fileReader.read();
//        while(read!=-1){
//            fileWriter.write(read);
//            read = fileReader.read();
//        }

        //方式二 使用数组缓冲
//        char[] chars = new char[5];
//        int read = fileReader.read(chars);
//        while (read!=-1){
//            fileWriter.write(chars,0,read);
//            read = fileReader.read(chars);
//        }

        //方式三 直接使用Str输出
        char[] chars = new char[5];
        int read = fileReader.read(chars);
        while (read!=-1){
            String str = new String(chars,0,read);
            fileWriter.write(str);
            read = fileReader.read(chars);
        }

        //关闭流：从下往上关闭
        fileWriter.close();
        fileReader.close();
    }
}
