package com.meturing.io;

import java.io.*;

/**
 * 使用字符流复制
 */
public class TestIO05 {
    public static void main(String[] args) throws IOException {
        File fileIn = new File("D:" + File.separatorChar + "Demo.png");
        File fileOut = new File("D:" + File.separatorChar + "DemoCopy.png");
        FileInputStream fileInputStream = new FileInputStream(fileIn);
        FileOutputStream fileOutputStream = new FileOutputStream(fileOut);

        byte[] bytes = new byte[1024*8];
        int read = fileInputStream.read(bytes);
        while (read!=-1){
            fileOutputStream.write(bytes,0,read);
            read = fileInputStream.read(bytes);
        }
        fileOutputStream.close();
        fileInputStream.close();
    }

    /**
     * 普通一个字节一个字节读取
     * @throws IOException
     */
    public void Demo01() throws IOException {
        File fileIn = new File("D:" + File.separatorChar + "Demo.png");
        File fileOut = new File("D:" + File.separatorChar + "DemoCopy.png");
        FileInputStream fileInputStream = new FileInputStream(fileIn);
        FileOutputStream fileOutputStream = new FileOutputStream(fileOut);

        int read = fileInputStream.read();
        while (read!=-1){
            fileOutputStream.write(read);
            read = fileInputStream.read();
        }
        fileOutputStream.close();
        fileInputStream.close();
    }
}
