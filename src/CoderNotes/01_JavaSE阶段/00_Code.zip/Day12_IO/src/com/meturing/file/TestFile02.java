package com.meturing.file;

import java.io.File;

/**
 * 对目录开始操作
 */
public class TestFile02 {
    public static void main(String[] args) {
        //将目录封装为File类的对象：
        File f = new File("D:\\IDEA_workspace");
        System.out.println("文件是否可读："+f.canRead());
        System.out.println("文件是否可写："+f.canWrite());
        System.out.println("文件的名字："+f.getName());
        System.out.println("上级目录："+f.getParent());
        System.out.println("是否是一个目录："+f.isDirectory());
        System.out.println("是否是一个文件："+f.isFile());
        System.out.println("是否隐藏："+f.isHidden());
        System.out.println("文件的大小："+f.length());
        System.out.println("是否存在："+f.exists());
        System.out.println("绝对路径："+f.getAbsolutePath());
        System.out.println("相对路径："+f.getPath());
        System.out.println("toString:"+f.toString());

        //目录特有的属性
        File a = new File("D:"+File.separatorChar+"a");
        a.mkdir();//创建单层目录
        File b = new File("D:"+File.separatorChar+"a"+File.separatorChar+"b"+File.separatorChar+"c");
        b.mkdirs();//创建多层目录

        b.delete();//删除  如果删除目录的话，只会删除一层目录，并且必须为空目录

        //获取指定目录内存在的所有目录或者文件的名字的数组
        String[] list = a.list();
        for (String s : list) {
            System.out.println(s);
        }

        //获取指定目录内存在的所有目录或者文件的File对象数组
        File[] files = a.listFiles();
        for (File file : files) {
            System.out.println("当前的名字："+file.getName()+"\t当前的绝对路径"+file.getAbsolutePath());
        }
    }
}
