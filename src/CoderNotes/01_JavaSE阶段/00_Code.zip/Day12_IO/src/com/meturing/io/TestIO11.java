package com.meturing.io;

import java.io.*;

/**
 * 对象流
 * 写出的类型跟读入的类型 必须 要匹配！
 */
public class TestIO11 {
    public static void main(String[] args) throws IOException {
        File file = new File("D:" + File.separatorChar + "DataDemo.txt");
        DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(file));
        dataOutputStream.writeUTF("张三");
        dataOutputStream.writeInt(19);
        dataOutputStream.writeBoolean(false);
        dataOutputStream.close();

        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
        System.out.println(dataInputStream.readUTF());
        System.out.println(dataInputStream.readInt());
        System.out.println(dataInputStream.readBoolean());
        dataInputStream.close();
    }
}
