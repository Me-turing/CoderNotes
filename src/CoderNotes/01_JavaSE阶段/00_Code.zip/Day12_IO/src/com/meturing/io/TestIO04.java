package com.meturing.io;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 使用Try catch 捕获异常
 */
public class TestIO04 {
    public static void main(String[] args) {
        //创建复制文件对象
        File fileIn = new File("D:" + File.separatorChar + "Demo.txt");
        //创建输出对象
        File fileOut = new File("D:" + File.separatorChar + "DemoCopy.txt");
        FileReader fileReader = null;
        FileWriter fileWriter = null;
        try {
            fileReader = new FileReader(fileIn);
            fileWriter = new FileWriter(fileOut);

            char[] chars = new char[5];
            int read = fileReader.read(chars);
            while (read!=-1){
                String str = new String(chars, 0, read);
                fileWriter.write(str);
                read = fileReader.read(chars);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                if (fileWriter!=null)fileWriter.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            try {
                if (fileReader != null)fileReader.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
