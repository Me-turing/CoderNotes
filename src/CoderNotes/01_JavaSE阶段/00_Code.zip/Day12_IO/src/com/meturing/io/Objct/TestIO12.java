package com.meturing.io.Objct;

import java.io.*;

public class TestIO12 {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        new TestIO12().test01();
        new TestIO12().test02();
    }
    //反序列化
    public void test02() throws IOException, ClassNotFoundException {
        ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(new File("D:" + File.separatorChar + "Objcet.txt")));
        Student student = (Student)objectInputStream.readObject();
        System.out.println(student);
    }
    //将对象序列化
    public void test01() throws IOException {
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(new File("D:" + File.separatorChar + "Objcet.txt")));
        objectOutputStream.writeObject(new Student("张三",19));
        objectOutputStream.close();
    }
}
