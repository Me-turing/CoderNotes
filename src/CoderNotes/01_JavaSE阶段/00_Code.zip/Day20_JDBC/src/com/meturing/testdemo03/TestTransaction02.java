package com.meturing.testdemo03;

import java.sql.*;
import java.util.LinkedList;

public class TestTransaction02 {
    private static String driver = "com.mysql.cj.jdbc.Driver";
    private static String url = "jdbc:mysql://192.168.1.188:3306/test?useSSL=false&autoReconnect=true&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
    private static String name ="root";
    private static String password = "root";

    public static void main(String[] args) {
        testBatch();
    }

    public static void testBatch(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        LinkedList<Savepoint> savepoints =new LinkedList<Savepoint>();
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, name, password);
            connection.setAutoCommit(false);//设置手动提交
            String sql = "insert into dept values (?,?,?)";
            preparedStatement = connection.prepareStatement(sql);
            for (int i = 0; i < 100; i++) {
                preparedStatement.setInt(1,i);
                preparedStatement.setString(2, "aa");
                preparedStatement.setString(3, "aa");
                preparedStatement.addBatch();
                if (i%50==0){//每50提交
                    preparedStatement.executeBatch();//提交
                    preparedStatement.clearBatch();//清空batch容器
                    //设置回滚点
                    Savepoint savepoint = connection.setSavepoint();
                    savepoints.add(savepoint);
                }
                // 数据在 51条插入的时候出现异常
                if(i ==51){
                    int x =1/0;
                }
            }
            //再次提交
            preparedStatement.executeBatch();//提交
            preparedStatement.clearBatch();//清空batch容器
        } catch (Exception e) {
            if (connection != null) {
                Savepoint last = savepoints.getLast();
                try {
                    connection.rollback(last);//回滚到还原点
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            if (connection != null) {
                savepoints.clear();//清空还原点列表
                try {
                    connection.commit();//提交事务
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (preparedStatement == null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection == null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
