package com.meturing.testdemo02;

import java.sql.*;
import java.util.Scanner;

public class TestPreparedSstatement {
    private static String driver = "com.mysql.cj.jdbc.Driver";
    private static String url = "jdbc:mysql://192.168.1.188:3306/test?useSSL=false&useServerPrepStmts=true&cachePrepStmts=true&autoReconnect=true&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
    private static String name ="root";
    private static String password = "root";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入用户名:");
        String name = scanner.next();
        System.out.println("请输入密码:");
        String password = scanner.next();
        Account account = getAccount(name, password);
        System.out.println(null!=account?"登录成功":"登录失败");
        scanner.close();
    }

    public static Account getAccount(String username,String pwd){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Account account= null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, name, password);
            String sql="select * from account where username = ? and password = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, pwd);
            System.out.println(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int aid = resultSet.getInt("aid");
                String usernamea = resultSet.getString("username");
                String pwda = resultSet.getString("password");
                int money = resultSet.getInt("money");
                account=new Account(aid,usernamea,pwda,money);
                System.out.println(account);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if (resultSet == null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement == null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection == null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return account;
    }
}
