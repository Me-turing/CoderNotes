package com.meturing.testdemo;

import java.io.Serializable;

/*
 * 实体类:
 * 和数据库表格名称和字段是一一对应的类
 * 该类的对象主要用处是存储从数据库中查询出来的数据
 * 除此之外,该类没有任何的其他功能
 * 要求
 *      1. 类名和表名保持一致  (见名知意)
 *      2. 属性个数和数据库的表的列数保持一致
 *      3. 属性的数据类型和列的数据类型保持一致
 *      4. 属性名和数据库表格的列名要保持一致
 *      5. 所有的属性必须都是私有的 (出于安全考虑)
 *      6. 实体类的属性推荐写成包装类
 *      7. 日期类型推荐写成java.util.Date
 *      8. 所有的属性都要有get和set方法
 *      9. 必须具备空参构造方法
 *      10. 实体类应当实现序列化接口 (mybatis缓存  分布式需要 )
 *      11. 实体类中其他构造方法可选
 * */
public class dept implements Serializable {
    private Integer deptNo;
    private String dName;
    private String loc;

    public dept() {
    }

    public dept(Integer deptNo, String dName, String loc) {
        this.deptNo = deptNo;
        this.dName = dName;
        this.loc = loc;
    }

    public Integer getDeptNo() {
        return deptNo;
    }

    public void setDeptNo(Integer deptNo) {
        this.deptNo = deptNo;
    }

    public String getdName() {
        return dName;
    }

    public void setdName(String dName) {
        this.dName = dName;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    @Override
    public String toString() {
        return "dept{" +
                "deptNo=" + deptNo +
                ", dName='" + dName + '\'' +
                ", loc='" + loc + '\'' +
                '}';
    }
}
