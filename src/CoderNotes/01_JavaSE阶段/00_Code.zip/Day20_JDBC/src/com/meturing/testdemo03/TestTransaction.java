package com.meturing.testdemo03;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TestTransaction {
    private static String driver = "com.mysql.cj.jdbc.Driver";
    private static String url = "jdbc:mysql://192.168.1.188:3306/test?useSSL=false&autoReconnect=true&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
    private static String name ="root";
    private static String password = "root";
    public static void main(String[] args) {
        testTransaction(1,-10);
    }

    public static void testTransaction(int aid,int money){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, name, password);
            connection.setAutoCommit(false);//设置事务手动提交
            String sql="update account set money =money- ? where aid = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, money);
            preparedStatement.setInt(2, aid);
            //设置错误
            // int a = 1/0;

            //每条DML都是默认提交事务的,多个preparedStatement.executeUpdate();都会提交一次事务
            preparedStatement.executeUpdate();
        } catch (Exception e) {
           //如果出现异常 回滚事务
            if (connection!=null){
                try {
                    connection.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            //最终提交事务
            if (connection!=null){
                try {
                    connection.commit();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (preparedStatement!=null){
                try {
                    preparedStatement.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            if (connection!=null){
                try {
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }

    }
}
