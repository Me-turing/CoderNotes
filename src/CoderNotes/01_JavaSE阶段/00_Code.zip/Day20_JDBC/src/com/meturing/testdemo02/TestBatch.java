package com.meturing.testdemo02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TestBatch {
    private static String driver = "com.mysql.cj.jdbc.Driver";
    private static String url = "jdbc:mysql://192.168.1.188:3306/test?useSSL=false&autoReconnect=true&rewriteBatchedStatements=true&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
    private static String name ="root";
    private static String password = "root";

    public static void main(String[] args) {
        testBatch();
    }

    public static void testBatch(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, name, password);
            String sql = "insert into dept values (?,?,?)";
            preparedStatement = connection.prepareStatement(sql);
            for (int i = 0; i < 100; i++) {
                preparedStatement.setInt(1,i);
                preparedStatement.setString(2, "aa");
                preparedStatement.setString(3, "aa");
                preparedStatement.addBatch();
                if (i%50==0){//每50提交
                    preparedStatement.executeBatch();//提交
                    preparedStatement.clearBatch();//清空batch容器
                }
            }
            //再次提交
            preparedStatement.executeBatch();//提交
            preparedStatement.clearBatch();//清空batch容器
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (preparedStatement == null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection == null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
