package com.meturing.testdemo;

import com.mysql.cj.jdbc.Driver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TestDemo01 {
    public static void main(String[] args) throws SQLException {
        //加载驱动
        Driver driver = new Driver();
        //注册驱动
        DriverManager.registerDriver(driver);
        //获得链接
        String url = "jdbc:mysql://192.168.1.188:3306/test?useSSL=false&autoReconnect=true&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
        String name ="root";
        String password = "root";
        Connection  connection = DriverManager.getConnection(url,name,password);
        //获得语句对象 Statment
        Statement statement = connection.createStatement();
        //执行SQL 获取返回值
        String sql = "insert into dept values(50,'教学部','北京');";
        int i = statement.executeUpdate(sql);
        System.out.println("受影响的行数:"+i);
        //释放资源
        statement.close();
        connection.close();
    }
}
