package com.meturing.testdemo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TestDemo03 {
    private static String driver = "com.mysql.cj.jdbc.Driver";
    private static String url = "jdbc:mysql://192.168.1.188:3306/test?useSSL=false&autoReconnect=true&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
    private static String name ="root";
    private static String password = "root";
    public static void main(String[] args) {
        List<dept> deptsList = getDeptsList();
        for (dept dept : deptsList) {
            System.out.println(dept);
        }
    }
    public static List<dept> getDeptsList() {
        Connection connection = null;
        Statement statement = null;
        List<dept> depts = null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, name, password);
            statement = connection.createStatement();
            depts = new ArrayList<>();
            String sql = "select * from dept";
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                int deptno = resultSet.getInt("DEPTNO");
                String dname = resultSet.getString("DNAME");
                String loc = resultSet.getString("LOC");
                dept dept = new dept(deptno, dname, loc);
                depts.add(dept);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (statement != null){
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null){
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return depts;
    }
}
