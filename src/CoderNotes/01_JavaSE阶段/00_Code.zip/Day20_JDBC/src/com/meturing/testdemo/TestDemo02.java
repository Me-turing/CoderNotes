package com.meturing.testdemo;

import java.sql.*;

public class TestDemo02 {
    private static String driver = "com.mysql.cj.jdbc.Driver";
    private static String url = "jdbc:mysql://192.168.1.188:3306/test?useSSL=false&autoReconnect=true&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
    private static String name ="root";
    private static String password = "root";
    public static void main(String[] args) {
//        testInster("123","助教部门","北京");
//        testDelete("123");
//        testUpdate("123","推广部","上海");
        testSelectAll();
    }


    /**
     * 添加
     * @param id id
     * @param department 部门
     * @param address 地址
     */
    public static void testInster(String id, String department,String address){
        Connection connection = null;
        Statement statement = null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, name, password);
            statement = connection.createStatement();
            String sql="insert into dept values('"+id+"','"+department+"','"+address+"');";
            int rows = statement.executeUpdate(sql);
            System.out.println("影响数据行数为:"+rows);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (statement!=null){
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection!=null){
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 删除
     * @param id
     */
    public static void testDelete(String id) {
        Connection connection = null;
        Statement statement = null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, name, password);
            statement = connection.createStatement();
            String sql = "delete from dept where deptno='"+id+"'";
            int i = statement.executeUpdate(sql);
            System.out.println("受影响的行数:"+i);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 更新
     * @param id id
     * @param department 部门
     * @param address 地址
     */
    public static void  testUpdate(String id, String department,String address){
        Connection connection = null;
        Statement statement = null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, name, password);
            statement = connection.createStatement();
            String sql = "update dept set dname='"+department+"',loc='"+address+"' where deptno='"+id+"';";
            int i = statement.executeUpdate(sql);
            System.out.println("受影响的行数:"+i);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * 查询全部
     */
    public static void  testSelectAll(){
        Connection connection = null;
        Statement statement = null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, name, password);
            statement = connection.createStatement();
            String sql = "Select * from dept";
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                int deptno = resultSet.getInt("DEPTNO");
                String dname = resultSet.getString("DNAME");
                String loc = resultSet.getString("LOC");
                System.out.println("[deptno:"+deptno+";dname"+dname+";loc"+loc+"]");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
