package com.turing.createthread.test14;

public class TestDemo14 {
    public static void main(String[] args) {
        Product product = new Product();
        ProducerThread producerThread = new ProducerThread(product);
        CustomerThread customerThread = new CustomerThread(product);
        producerThread.start();
        customerThread.start();
    }
}
