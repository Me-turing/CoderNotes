package com.turing.createthread;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * setDaemon
 */
public class TestDemo11 {
    public static void main(String[] args) throws InterruptedException {
        ThreadDemo11 threadDemo11 = new ThreadDemo11();
        threadDemo11.setDaemon(true);//设置伴随线程  注意：先设置，再启动
        threadDemo11.start();

        for (int i = 0; i < 20; i++) {
            Thread.sleep(100);
            System.out.println("主线程==="+i);
        }
    }
}
class ThreadDemo11 extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            try {
                sleep(200);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("子线程==="+i);
        }
    }
}
