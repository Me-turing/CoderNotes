package com.turing.createthread;

/**
 * 实现Runnable接口
 */
public class TestDemo06 {
    public static void main(String[] args) {
        TrainStation02 trainStation01 = new TrainStation02();
        Thread thread1 = new Thread(trainStation01,"窗口1");
        thread1.start();

        TrainStation02 trainStation02 = new TrainStation02();
        Thread thread2 = new Thread(trainStation02,"窗口2");
        thread2.start();

        TrainStation02 trainStation03 = new TrainStation02();
        Thread thread3 = new Thread(trainStation03,"窗口3");
        thread3.start();
    }
}

class TrainStation02 implements Runnable{
    private static int ticket = 10; //初始化10张票

    @Override
    public void run() {
        for (int i = 0; i < 50; i++) {
            if (ticket>0){
                System.out.println(Thread.currentThread().getName()+"---- 卖出去一张票，还剩"+(--ticket)+"张票");
            }
        }
    }
}
