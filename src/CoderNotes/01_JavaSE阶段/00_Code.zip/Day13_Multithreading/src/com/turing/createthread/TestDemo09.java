package com.turing.createthread;

/**
 * Join
 */
public class TestDemo09 {
    public static void main(String[] args) throws InterruptedException {
        for (int i = 0; i < 20; i++) {
            System.out.println("main======"+i);
            if (i==6){
                ThreadDemo09 threadDemo09 = new ThreadDemo09("线程：" + i);
                threadDemo09.start();//启动线程
                threadDemo09.join();//加入线程
            }
        }
    }
}

class ThreadDemo09 extends Thread{
    public ThreadDemo09(String name) {
        super(name);
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println(this.getName()+"---- 执行任务"+i);
        }
    }
}
