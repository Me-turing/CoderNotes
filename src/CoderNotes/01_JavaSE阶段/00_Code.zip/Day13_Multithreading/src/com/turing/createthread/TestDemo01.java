package com.turing.createthread;

/**
 * 简单的线程测试
 */
public class TestDemo01 {
    public static void main(String[] args) throws InterruptedException {
        for (int i = 0; i < 10; i++) {
            Thread.sleep(200);
            System.out.println("main---"+i);
        }
        ThreadObject threadObject = new ThreadObject();
        threadObject.start();
        for (int i = 10; i < 20; i++) {
            Thread.sleep(200);
            System.out.println("main---"+i);
        }
    }
}

/**
 * ① 继承Thread类  ② 重写run方法   ③ 执行start方法
 */
class ThreadObject extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(i);
        }
    }
}
