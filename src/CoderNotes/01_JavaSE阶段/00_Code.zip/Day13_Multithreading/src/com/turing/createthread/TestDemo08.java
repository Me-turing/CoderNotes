package com.turing.createthread;

/**
 * 测试优先级
 */
public class TestDemo08 {
    public static void main(String[] args) {
        TestThread01 testThread01 = new TestThread01();
        testThread01.setPriority(1);//设置优先级
        testThread01.start();
        TestThread02 testThread02 = new TestThread02();
        testThread01.setPriority(10);//设置优先级
        testThread02.start();
    }
}
class TestThread01 extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 30; i++) {
            try {
                sleep(200);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(this.getName()+"----"+i);
        }
    }
}
class TestThread02 extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 30; i++) {
            try {
                sleep(200);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(this.getName()+"----"+i);
        }
    }
}
