package com.turing.createthread;

/**
 * 继承Thread接口
 */
public class TestDemo03 {
    public static void main(String[] args) throws InterruptedException {
        Thread.currentThread().setName("主线程");//设置当前主线程的名字

        ThreadObject02 threadObject02 = new ThreadObject02("子线程");//设置当前子线程的名字
        threadObject02.start();

        for (int i = 0; i < 10; i++) {
            Thread.sleep(200);
            System.out.println(Thread.currentThread().getName()+"----"+i);
        }
    }
}
/**
 * ① 继承Thread类  ② 重写run方法   ③ 执行start方法
 */
class ThreadObject02 extends Thread{

    //重写构造方法 给线程设置名字
    public ThreadObject02(String name) {
        super(name);
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(this.getName()+"----"+i);
        }
    }
}
