package com.turing.createthread;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * stop
 */
public class TestDemo12 {
    public static void main(String[] args) throws InterruptedException {
        for (int i = 0; i < 100; i++) {
            System.out.println("main === "+i);
            if (i==6) Thread.currentThread().stop(); //停止线程 过期方法不建议使用
        }
    }
}
