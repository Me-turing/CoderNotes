package com.turing.createthread;

/**
 * 继承Thread接口
 */
public class TestDemo04 {
    public static void main(String[] args) {
        TrainStation thread01 = new TrainStation("窗口1");
        thread01.start();
        TrainStation thread02 = new TrainStation("窗口2");
        thread02.start();
        TrainStation thread03 = new TrainStation("窗口3");
        thread03.start();
    }
}
class TrainStation extends Thread{
    private static int ticket = 10; //初始化10张票
    //设置线程的名字
    public TrainStation(String name) {
        super(name);
    }

    //执行的方法
    @Override
    public void run() {
        //每个线程后面有50个人去抢票
        for (int i = 0; i < 50; i++) {
            if (ticket>0){
                System.out.println(this.getName()+"-- 卖出了一张票，还剩"+(--ticket));
            }
        }
    }
}

