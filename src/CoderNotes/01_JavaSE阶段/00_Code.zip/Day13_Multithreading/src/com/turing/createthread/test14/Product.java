package com.turing.createthread.test14;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 商品类
 */
public class Product {
    //品牌
    private String brand;
    //名字
    private String name;
    //状态 true 生产  false 消费
    private boolean locked = true;

    //使用Lock锁
    Lock lock = new ReentrantLock();
    //消费者等待池
    Condition produceCondition = lock.newCondition();
    Condition customerCondition = lock.newCondition();

    public Product() {
    }

    public Product(String brand, String name) {
        this.brand = brand;
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    /**
     * 生产
     */
    public  void setProduct(String brand,String name){
        lock.lock();
        try {
            if (!this.isLocked()){
                try {
                    //wait();
                    produceCondition.await();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }

            this.brand = brand;
            this.name = name;
            System.out.println("生产者：生产了"+this.brand+"==="+this.name);

            this.setLocked(false);
            //notify();
            customerCondition.signal();
        } finally {
            lock.unlock();
        }
    }

    /**
     * 消费
     */
    public synchronized void getProduct(){
        lock.lock();
        try {
            if (this.isLocked()){
                try {
                    //wait();
                    customerCondition.await();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }

            System.out.println("消费者：消费了"+this.brand+"==="+this.name);

            this.setLocked(true);
            //notify();
            produceCondition.signal();
        } finally {
            lock.unlock();
        }
    }
}
