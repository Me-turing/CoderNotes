package com.turing.createthread;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * sleep
 */
public class TestDemo10 {
    public static void main(String[] args) throws InterruptedException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
        while (true){
            Thread.sleep(1000);
            System.out.println(simpleDateFormat.format(new Date()));
        }
    }
}
