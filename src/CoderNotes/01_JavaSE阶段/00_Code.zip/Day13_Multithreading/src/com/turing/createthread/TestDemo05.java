package com.turing.createthread;

/**
 * 实现Runnable接口
 */
public class TestDemo05 {
    public static void main(String[] args) {
        runnableDemo runnableDemo = new runnableDemo();//创建对象
        Thread thread = new Thread(runnableDemo,"线程1");//使用对象创建线程对象，并为线程创建名字
        thread.start();
    }
}

class runnableDemo implements Runnable{
    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(Thread.currentThread().getName()+"----"+i);
        }
    }
}
