package com.turing.createthread;

import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * 实现Callable接口
 */
public class TestDemo07 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        CallAbleDemo callAbleDemo = new CallAbleDemo(); //创建线程任务对象
        FutureTask futureTask = new FutureTask(callAbleDemo);//创建FutureTask对象，传入线程任务对象
        Thread thread = new Thread(futureTask, "线程一");//创建Thread线程对象，传入FutureTask对象
        thread.start();//运行线程
        int random = (int)futureTask.get();//通过FutureTask对象.get() 获取返回值
        System.out.println(random);
    }
}
class CallAbleDemo implements Callable<Integer>{

    @Override
    public Integer call() throws Exception {
        return new Random().nextInt(10);//返回10以内的随机数
    }
}
