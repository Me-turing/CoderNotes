package com.turing.createthread;

/**
 * 继承Thread即可
 */
public class TestDemo02 {
    public static void main(String[] args) throws InterruptedException {
        Thread.currentThread().setName("主线程");//设置当前主线程的名字

        ThreadObject01 threadObject01 = new ThreadObject01();
        threadObject01.setName("子线程");//设置当前子线程的名字
        threadObject01.start();

        for (int i = 0; i < 10; i++) {
            Thread.sleep(200);
            System.out.println(Thread.currentThread().getName()+"----"+i);
        }
    }
}

/**
 * ① 继承Thread类  ② 重写run方法   ③ 执行start方法
 */
class ThreadObject01 extends Thread{
    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(this.getName()+"----"+i);
        }
    }
}
