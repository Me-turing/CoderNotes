package com.turing.createthread.test13;

/**
 * 商品类
 */
public class Product {
    //品牌
    private String brand;
    //名字
    private String name;
    //状态 true 生产  false 消费
    private boolean locked = true;

    public Product() {
    }

    public Product(String brand, String name) {
        this.brand = brand;
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    /**
     * 生产
     */
    public synchronized void setProduct(String brand,String name){
        if (!this.isLocked()){
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

        this.brand = brand;
        this.name = name;
        System.out.println("生产者：生产了"+this.brand+"==="+this.name);

        this.setLocked(false);
        notify();
    }

    /**
     * 消费
     */
    public synchronized void getProduct(){
        if (this.isLocked()){
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

        System.out.println("消费者：消费了"+this.brand+"==="+this.name);

        this.setLocked(true);
        notify();
    }
}
