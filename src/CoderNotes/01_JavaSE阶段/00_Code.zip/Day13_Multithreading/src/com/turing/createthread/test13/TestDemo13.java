package com.turing.createthread.test13;

public class TestDemo13 {
    public static void main(String[] args) {
        Product product = new Product();
        ProducerThread producerThread = new ProducerThread(product);
        CustomerThread customerThread = new CustomerThread(product);
        producerThread.start();
        customerThread.start();
    }
}
