package meturing.stream.demo02;

import java.util.stream.Stream;

public class Demo02_forEach {
    public static void main(String[] args) {
        Stream<String> stream = Stream.of("张三", "李四", "王五", "麻子");
        stream.forEach(System.out::println);
    }
}
