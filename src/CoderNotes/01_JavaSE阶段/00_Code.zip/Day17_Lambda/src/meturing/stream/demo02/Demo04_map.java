package meturing.stream.demo02;

import java.util.stream.Stream;

public class Demo04_map {
    public static void main(String[] args) {
        Stream<String> stream = Stream.of("1", "2", "3", "4");
         stream.map(s -> Integer.parseInt(s)).forEach(System.out::println);
    }
}
