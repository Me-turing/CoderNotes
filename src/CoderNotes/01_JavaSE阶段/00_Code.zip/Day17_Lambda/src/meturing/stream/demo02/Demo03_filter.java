package meturing.stream.demo02;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Demo03_filter {
    public static void main(String[] args) {
        Stream<String> stream = Stream.of("张三", "李四", "王五", "麻子","大花脸");
        List<String> filterList = stream.filter(s -> s.startsWith("张")).collect(Collectors.toList());
        filterList.stream().forEach(System.out::println);
    }
}
