package meturing.stream.demo01;

import java.util.ArrayList;
import java.util.List;

public class Demo01List {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("张无忌");
        list.add("周芷若");
        list.add("赵敏");
        list.add("张强");
        list.add("张三丰");

        ArrayList<String> listA = new ArrayList<>();
        for (String name : list) {
            if (name.startsWith("张")){
                listA.add(name);
            }
        }

        ArrayList<String> listB = new ArrayList<>();
        for (String name : listA) {
            if (name.length()>=3){
                listB.add(name);
            }
        }

        System.out.println(listB);
    }
}
