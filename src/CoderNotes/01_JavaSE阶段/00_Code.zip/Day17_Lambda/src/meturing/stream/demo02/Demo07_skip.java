package meturing.stream.demo02;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

public class Demo07_skip {
    public static void main(String[] args) {
        /**
         * 跳过指定的元素
         */
        String[] strArrays = {"林青霞,25","张三,22","李四,20","王五,12"};
        Stream.of(strArrays).skip(2).forEach(System.out::println);
    }

}
