package meturing.stream.demo02;

import java.util.ArrayList;
import java.util.List;

public class Demo05_count {
    public static void main(String[] args) {
        List<Integer> integers = new ArrayList<>();
        integers.add(1);
        integers.add(2);
        integers.add(3);

        int count = (int) integers.stream().count();
        System.out.println(count);
    }
}
