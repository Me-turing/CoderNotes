package meturing.stream.demo02;

import java.util.*;
import java.util.stream.Stream;

public class Demo01GetStream {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        Stream<String> listStream = list.stream();

        Set<String> set = new HashSet<>();
        Stream<String> setStream = set.stream();


        Map<String, Integer> map = new HashMap<>();
        Set<String> mpKeySet = map.keySet();
        Stream<String> mpKeySetStream = mpKeySet.stream();

        Collection<Integer> values = map.values();
        Stream<Integer> valuesStream = values.stream();

        Set<Map.Entry<String, Integer>> entries = map.entrySet();
        Stream<Map.Entry<String, Integer>> entryStream = entries.stream();


        Integer[] arr = {1,2,3,4,5};
        String[] arr2 = {"aa","bb","cc"};
        Stream<Integer> ArrayStream1 = Stream.of(arr);
        Stream<String> ArrayStream2 = Stream.of(arr2);

    }
}
