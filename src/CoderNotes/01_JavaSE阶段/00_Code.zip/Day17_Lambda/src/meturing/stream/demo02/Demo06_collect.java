package meturing.stream.demo02;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Demo06_collect {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("小张三");
        list.add("李四");
        list.add("王五");
        list.add("麻子");

        List<String> collect1 = list.stream().filter(s -> s.length() >= 3).collect(Collectors.toList());
        collect1.stream().forEach(System.out::println);

        Set<Integer> set = new HashSet<>();
        set.add(10);
        set.add(20);
        set.add(30);
        set.add(40);
        Set<Integer> collect2 = set.stream().filter(s -> s > 25).collect(Collectors.toSet());
        collect2.stream().forEach(System.out::println);

        String[] strArrays = {"林青霞,25","张三,22","李四,20","王五,12"};
        Stream<String> stream = Stream.of(strArrays).filter(s -> Integer.parseInt(s.split(",")[1]) > 20);

        Map<String, String> collect = stream.collect(Collectors.toMap(s -> s.split(",")[0], s -> s.split(",")[1]));
        collect.keySet().forEach(s -> System.out.println(s+","+collect.get(s)));
    }
}
