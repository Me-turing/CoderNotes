package meturing.stream.demo02;

import java.util.stream.Stream;

public class Demo08_concat {
    public static void main(String[] args) {
        /**
         * 合并流
         */
        String[] strArrays1 = {"林青霞,25","张三,22"};
        String[] strArrays2 = {"李四,20","王五,12"};
        Stream.concat(Stream.of(strArrays1),Stream.of(strArrays2)).forEach(System.out::println);
    }
}
