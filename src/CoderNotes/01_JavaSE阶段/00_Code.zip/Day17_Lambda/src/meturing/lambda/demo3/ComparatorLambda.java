package meturing.lambda.demo3;

import java.util.Arrays;
import java.util.Comparator;

public class ComparatorLambda {
    public static void main(String[] args) {
        String[] strs = {"dedeyidede","abc","de","fghi"};
        // 使用匿名内部类
        Comparator<String> comparator = new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.length()-o2.length();
            }
        };

        Arrays.sort(strs,comparator);
        Arrays.sort(strs,(o1,o2)-> o1.length()-o2.length());
        System.out.println(Arrays.toString(strs));
    }
}
