package meturing.lambda.demo5;

@FunctionalInterface
public interface Printable {
    void PrintSay(String msg);
}
