package meturing.lambda.demo9.son;

@FunctionalInterface
public interface Richable {
    void buy();
}
