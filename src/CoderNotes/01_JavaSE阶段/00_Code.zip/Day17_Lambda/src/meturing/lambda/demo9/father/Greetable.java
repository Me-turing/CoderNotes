package meturing.lambda.demo9.father;

@FunctionalInterface
public interface Greetable {
    void greet();
}
