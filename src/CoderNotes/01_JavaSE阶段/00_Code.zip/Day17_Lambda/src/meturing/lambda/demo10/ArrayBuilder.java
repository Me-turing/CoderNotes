package meturing.lambda.demo10;

@FunctionalInterface
public interface ArrayBuilder {
    int[] builderArray(int length);
}
