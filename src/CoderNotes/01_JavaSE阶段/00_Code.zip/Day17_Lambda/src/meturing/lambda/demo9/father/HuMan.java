package meturing.lambda.demo9.father;

public class HuMan {
    public void sayHello(){
        System.out.println("HuMan");
    }
}
