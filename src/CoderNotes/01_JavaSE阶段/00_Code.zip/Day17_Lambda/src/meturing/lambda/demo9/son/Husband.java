package meturing.lambda.demo9.son;

public class Husband {
    public void buyHouse(){
        System.out.println("buyHouse");
    }

    public void marry(Richable richable){
        richable.buy();
    }

    public void soHappy(){
//        marry(new Richable() {
//            @Override
//            public void buy() {
//                buyHouse();
//            }
//        });

//        marry(()->this.buyHouse());

        /**
         * this::方法名
         */
        marry(this::buyHouse);
    }
}
