package meturing.lambda;

@FunctionalInterface
public interface Printable {
    void print(String str);
}
