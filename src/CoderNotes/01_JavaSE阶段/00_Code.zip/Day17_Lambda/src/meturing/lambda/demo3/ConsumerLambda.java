package meturing.lambda.demo3;

import java.util.function.Consumer;

public class ConsumerLambda {
    public static void main(String[] args) {
        consumerString(
                s -> System.out.println(s)
        );

        consumerString(
                s -> System.out.println(s.toUpperCase()),
                s -> System.out.println(s.toLowerCase())
        );
    }

    static void consumerString(Consumer<String> function){
        //对给定参数执行此操作
        function.accept("Hello");
    }

    static void consumerString(Consumer<String> first,Consumer<String> sec){
        //一个组成的消费者，依次执行此操作，然后执行后续操作
        first.andThen(sec).accept("Hello");
    }
}
