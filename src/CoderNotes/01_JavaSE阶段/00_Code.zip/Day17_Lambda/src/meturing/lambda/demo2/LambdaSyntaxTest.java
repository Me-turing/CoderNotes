package meturing.lambda.demo2;

    /**
     * 测试Lambda表达式
     *
     * 格式1：(parameters) ->  {statements;}
     * 格式2：(parameters) ->  expression
     *
     * 代码演示：
     *  0.Lambda表达式的基本格式
     *  1.省略大括号
     *  2.省略参数类型和大括号
     *  3.省略小括号
     *  4.Lambda表达式作为参数传递给方法
     */
    public class LambdaSyntaxTest {
        public static void main(String[] args) {
            //原始写法
            IMathOperation iMathOperation1 = new IMathOperation() {
                @Override
                public int operation(int a, int b) {
                    return  a+b;
                }
            };

            // 0.Lambda表达式的基本格式
            IMathOperation iMathOperation = (int a,int b) ->{return a+b;};
            System.out.println(iMathOperation.operation(1, 0));
            // 1..省略Return和大括号
            iMathOperation = (int a,int b) -> a+b;
            System.out.println(iMathOperation.operation(1, 0));
            //2.省略参数类型和大括号
            iMathOperation = (a,b) -> a+b;
            System.out.println(iMathOperation.operation(1, 0));
            //3.省略小括号
            IGreeting iGreeting = msg -> System.out.println(msg);
            iGreeting.sayHello("123");
        }
    }
