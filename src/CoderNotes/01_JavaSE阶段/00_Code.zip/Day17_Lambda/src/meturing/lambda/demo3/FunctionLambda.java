package meturing.lambda.demo3;

import java.util.function.Function;

public class FunctionLambda {
    public static void main(String[] args) {
        // 返回50
        method( str -> Integer.parseInt(str)+10,s -> s+10);
        //返回20
        int sum = getAgeNum("1",str -> str+="0",str -> Integer.parseInt(str),str -> str+10);
        System.out.println(sum);
    }
    static void method(Function<String,Integer> one,Function<Integer,Integer> two){
        int num = one.andThen(two).apply("10");
        System.out.println(num+20);
    }
    static int getAgeNum(String str,
                         Function<String,String> one,
                         Function<String,Integer> two,
                         Function<Integer,Integer> three){
        return one.andThen(two).andThen(three).apply(str);
    }
}
