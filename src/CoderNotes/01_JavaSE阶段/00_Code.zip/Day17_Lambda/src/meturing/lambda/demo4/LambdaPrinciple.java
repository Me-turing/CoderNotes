package meturing.lambda.demo4;

import java.lang.invoke.LambdaMetafactory;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/**
 *  JVM参数：jdk.internal.lambda.dumpProxyClasses
 *      命令：java -Djdk.internal.lambda.dumpProxyClasses ClassName
 *      转储得到内部类：
 *      反编译：java -jar cfr-0.145.jar LambdaTest.Class --decodelambdas false
 *  本质：函数式接口的匿名子类的匿名对象
 *  Lambda表达式与函数式接口的抽象函数格式一一对应
 */
public class LambdaPrinciple {
    public static void main(String[] args) {
        List<String> strings = Arrays.asList("赵", "钱", "孙", "李");
        strings.forEach(s->{
            System.out.println(s);
        });
    }
}


