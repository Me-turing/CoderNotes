package meturing.lambda.demo7;

public class ConstructorMethodReference {
    public static void printName(String name,PersonBuilder personBuilder){
        Person person = personBuilder.builderPerson(name);
        System.out.println(person.getName());
    }

    public static void main(String[] args) {
        //原始写法
        printName("张三", new PersonBuilder() {
            @Override
            public Person builderPerson(String name) {
               return  new Person(name);
            }
        });

        //Lambda写法
        printName("张三",s -> new Person(s));

        //使用方法引用
        /**
         * 构造方法引用
         *      类名 :: new
         *
         *  根据抽象函数的函数签名来自动匹配最合适的构造方法
         */
        printName("张三",Person::new);
    }
}
