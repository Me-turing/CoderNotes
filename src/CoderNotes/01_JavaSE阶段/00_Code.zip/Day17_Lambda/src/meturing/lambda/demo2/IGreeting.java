package meturing.lambda.demo2;

@FunctionalInterface
public interface IGreeting {
    void sayHello(String message);
}
