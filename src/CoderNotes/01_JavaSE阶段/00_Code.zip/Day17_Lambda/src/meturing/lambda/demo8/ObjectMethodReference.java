package meturing.lambda.demo8;

public class ObjectMethodReference {
    public static void printString(Printable printable){
        printable.print("Hello");
    }
    public static void main(String[] args) {
        printString(new Printable() {
            @Override
            public void print(String s) {
                MethodRerObject methodRerObject = new MethodRerObject();
                methodRerObject.printUpperCaseString(s);
            }
        });

        printString(s->{
            MethodRerObject methodRerObject = new MethodRerObject();
            methodRerObject.printUpperCaseString(s);
        });

        /*
            引用对象中的普通方法
                我们需要先建立对象，再使用引用类型
                对象名::方法名

             注意：如果接口返回值是Void类型 实现类返回值可以为任意类型。如果接口是具体的返回值类型，实现类的返回值必须一致
         */
        MethodRerObject methodRerObject = new MethodRerObject();
        printString(methodRerObject::printUpperCaseString);
    }
}
