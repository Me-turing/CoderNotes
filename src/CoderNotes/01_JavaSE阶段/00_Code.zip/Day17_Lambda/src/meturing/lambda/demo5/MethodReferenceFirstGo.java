package meturing.lambda.demo5;

import java.io.PrintStream;

public class MethodReferenceFirstGo {
    public static void main(String[] args) {
        printString(s ->{
            System.out.println(s);
        });

        /**
         * Lambda是为了简化函数式接口的调用
         * 方法引用可以简化Lambda表达式的代码
         *
         * 为什么需要方法引用：
         *  当Lambda表达式所要完成的业务逻辑已经存在--已经有某一个函数实现了
         *  我们可以直接引用对应的方法
         *
         *  普通方法引用：引用的是一个对象
         */
        PrintStream out = System.out;
        printString(out::println);
    }

    public static void printString(Printable printable){
        printable.PrintSay("Hello");
    }
}
