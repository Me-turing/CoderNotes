package meturing.lambda.demo8;

public class MethodRerObject {
    public void printUpperCaseString(String str){
        System.out.println(str.toUpperCase());
    }
}
