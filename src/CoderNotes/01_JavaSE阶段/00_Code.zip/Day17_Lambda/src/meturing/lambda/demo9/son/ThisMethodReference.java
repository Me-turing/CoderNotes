package meturing.lambda.demo9.son;

public class ThisMethodReference {
    public static void main(String[] args) {
        new Husband().soHappy();
    }
}
