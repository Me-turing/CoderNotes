package meturing.lambda.demo6;

public class StaticMethodReference {
    public static int method(int number,Calcable calcable){
        return calcable.calsAbs(number);
    }
    public static void main(String[] args) {
        //常规的写法
        int method = method(-10, new Calcable() {
            @Override
            public int calsAbs(int number) {
                return Math.abs(number);
            }
        });
        System.out.println(method);

        //使用Lambda表达式的写法
        int method1 = method(-10,(n)->{
            return Math.abs(n);
        });
        System.out.println(method1);

        //我们发现，对于接口的实现方法是一个已经存在的静态方法，是Math类中的静态方法，所以我们可以考虑使用方法引用
        //需要参数和返回值类型都兼容，我们就可以使用方法引用
        int method2 = method(-10, Math::abs);
        System.out.println(method2);
    }
}
