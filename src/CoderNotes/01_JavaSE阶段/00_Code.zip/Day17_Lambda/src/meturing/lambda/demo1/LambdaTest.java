package meturing.lambda.demo1;

public class LambdaTest {
    public static void main(String[] args) {
        //向上转型  子类引用指向父类实例
        Factory factory = new SubClass();
        User user1 = (User)factory.getObject();
        System.out.println(user1);

        //匿名内部类
        factory = new Factory() {
            @Override
            public Object getObject() {
                return new User("张三",18);
            }
        };
        User user2 = (User)factory.getObject();
        System.out.println(user2);

        //lambda表达式
//        factory = () ->{
//            return new User("李四",22);
//        };

        factory = () -> new User("李四",22);
        User user3 = (User) factory.getObject();
        System.out.println(user3);

        //lambda表达式作为参数进行传递
        User user4 = getUserFormFactory(
                ()->{return new User("王五",30);}, "User"
        );
        System.out.println(user4);

        //lambda表达式作为返回值传递
        factory = getFactory();
        User user5 = (User) factory.getObject();
        System.out.println(user5);
    }
    public static User getUserFormFactory(Factory factory,String ClassName){
        if (factory==null){
            return null;
        }
        Object object = factory.getObject();
        //getSimpleName() API 表示获取类的名字，只包含名字  getName() 获取的是类的包名
        if (object != null && object.getClass().getSimpleName().equals(ClassName)){
            return (User) object;
        }
        return null;
    }

    public static Factory getFactory(){
        return ()->{
            return new User("赵六",52);
        };
    }
}
