package meturing.lambda.demo8;

@FunctionalInterface
public interface Printable {
    void print(String s);
}
