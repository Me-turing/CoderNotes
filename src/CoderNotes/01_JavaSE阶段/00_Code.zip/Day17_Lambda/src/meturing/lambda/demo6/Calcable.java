package meturing.lambda.demo6;

@FunctionalInterface
public interface Calcable {
    int calsAbs(int number);
}
