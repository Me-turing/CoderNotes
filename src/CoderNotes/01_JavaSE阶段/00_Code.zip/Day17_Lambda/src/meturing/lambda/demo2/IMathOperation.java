package meturing.lambda.demo2;

@FunctionalInterface
public interface IMathOperation {
    int operation(int a,int b);
}
