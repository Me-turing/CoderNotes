package meturing.lambda.demo7;

@FunctionalInterface
public interface PersonBuilder {
    Person builderPerson(String name);
}
