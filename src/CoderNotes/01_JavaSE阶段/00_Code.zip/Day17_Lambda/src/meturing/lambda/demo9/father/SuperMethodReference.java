package meturing.lambda.demo9.father;

public class SuperMethodReference {
    public static void main(String[] args) {
        Man man = new Man();
        man.show();
    }
}
