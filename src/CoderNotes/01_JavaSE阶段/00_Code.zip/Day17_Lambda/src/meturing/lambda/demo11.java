package meturing.lambda;

public class demo11 {
    private static void printString(Printable lambda) {
        lambda.print("Hello");
    }

    public static void main(String[] args) {
        //原有的写法
        printString(s -> {
            MethodRefObject methodRefObject = new MethodRefObject();
            methodRefObject.printUpperCase(s);
        });

        //引用写法
        MethodRefObject methodRefObject = new MethodRefObject();
        printString(methodRefObject::printUpperCase);
    }

}
