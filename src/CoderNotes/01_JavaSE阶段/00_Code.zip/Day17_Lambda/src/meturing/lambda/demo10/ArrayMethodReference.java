package meturing.lambda.demo10;

public class ArrayMethodReference {
    public static int[] createArray(int length,ArrayBuilder arrayBuilder){
        return arrayBuilder.builderArray(length);
    }
    public static void main(String[] args) {
        int[] array = createArray(10, new ArrayBuilder() {
            @Override
            public int[] builderArray(int length) {
                return new int[length];
            }
        });
        System.out.println(array.length);

        array = createArray(11,s->new int[s]);
        System.out.println(array.length);


        array = createArray(12,int[]::new);
        System.out.println(array.length);

    }
}
