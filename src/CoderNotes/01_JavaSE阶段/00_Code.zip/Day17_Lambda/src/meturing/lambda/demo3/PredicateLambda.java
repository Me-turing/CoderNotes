package meturing.lambda.demo3;

import java.util.function.Predicate;

public class PredicateLambda {
    public static void main(String[] args) {
        andMethod(s -> s.contains("W"),s -> s.contains("H"));
        orMethod(s -> s.contains("W"),s -> s.contains("H"));
        negateMethod(s -> s.equals("Hellow"));
    }
    //与操作
    static void andMethod(Predicate<String> one,Predicate<String> two){
        boolean isValid = one.and(two).test("Hellow");
        System.out.println("字符串符合要求吗："+isValid);//字符串符合要求吗：false
    }
    //或操作
    static void orMethod(Predicate<String> one,Predicate<String> two){
        boolean isValid = one.or(two).test("Hellow");
        System.out.println("字符串符合要求吗："+isValid);//字符串符合要求吗：true
    }
    //非
    static void negateMethod(Predicate<String> predicate){
        boolean isValid = predicate.negate().test("Hellow");
        System.out.println("字符串很长吗："+isValid);//字符串很长吗：false
    }
}
