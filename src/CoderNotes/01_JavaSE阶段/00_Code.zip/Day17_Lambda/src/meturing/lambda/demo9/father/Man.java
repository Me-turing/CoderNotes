package meturing.lambda.demo9.father;

public class Man extends HuMan {
    @Override
    public void sayHello() {
        System.out.println("Man");
    }
    public void method(Greetable greetable){greetable.greet();}

    public void show(){
//        method(()->{
//            HuMan huMan = new HuMan();
//            huMan.sayHello();
//        });

//        method(()->{
//            super.sayHello();
//        });

        /**
         * super::父类的成员方法名
         */
        method(super::sayHello);
    }
}
