package meturing.lambda.demo1;

@FunctionalInterface
public interface Factory {
    Object getObject();
}
