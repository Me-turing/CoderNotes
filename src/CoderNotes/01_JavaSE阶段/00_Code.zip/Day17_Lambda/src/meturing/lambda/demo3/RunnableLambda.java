package meturing.lambda.demo3;

public class RunnableLambda {
    public static void main(String[] args) {
        //Runnable接口的默认使用方式
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = Thread.currentThread().getName();
                System.out.println(name+"线程已启动");
            }
        }).start();

        //Lambda表达式
        new Thread(()->{
            String name = Thread.currentThread().getName();
            System.out.println(name+"线程已启动");
        }).start();
    }
}
