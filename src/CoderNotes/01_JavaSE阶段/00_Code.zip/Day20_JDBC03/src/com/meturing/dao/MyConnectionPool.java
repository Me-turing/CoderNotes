package com.meturing.dao;

import com.meturing.util.PropertiesUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.LinkedList;

public class MyConnectionPool {
    private static String driver;
    private static String url;
    private static String name;
    private static String password;
    private static int initSize;
    private static int maxSize;
    private static LinkedList<Connection> pool;

    //优先加载驱动
    static {
        //初始化参数
        PropertiesUtil propertiesUtil=new PropertiesUtil("/jdbc.properties");
        driver=propertiesUtil.getProperties("driver");
        url=propertiesUtil.getProperties("url");
        name=propertiesUtil.getProperties("name");
        password=propertiesUtil.getProperties("password");
        initSize=Integer.parseInt(propertiesUtil.getProperties("initSize"));
        maxSize=Integer.parseInt(propertiesUtil.getProperties("maxSize"));
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        //初始化Pool
        pool = new LinkedList<Connection>();
        // 初始化连接池
        for (int i = 0; i < initSize; i++) {
            Connection connection = initConnection();
            if (connection!=null){
                pool.add(connection);
                System.out.println("初始化连接"+connection.hashCode()+"放入连接池");
            }
        }
    }

    /**
     * 私有的初始化链接方法
     * @return
     */
    private static Connection initConnection(){
        try {
            return DriverManager.getConnection(url, name, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 公共的获取链接方法
     * @return
     */
    public static Connection getConnection(){
        Connection connection =null;
        if (pool.size()>0){
            connection = pool.removeFirst();//从池中拿出第一个
            System.out.println("取出连接:"+connection.hashCode());
        }else {
            connection = initConnection();
            System.out.println("创建连接:"+connection.hashCode());
        }
        return connection;
    }

    /**
     * 公共的向连接池中归还链接
     * @param connection
     */
    public static void returnConnection(Connection connection){
        if (connection!=null){
            try {
                if (!connection.isClosed()) {//判断链接是否关闭
                    if (pool.size()<maxSize) {//判断Pool的大小是否超过上限
                        connection.setAutoCommit(true);//调整链接为自动提交
                        System.out.println("设置连接:"+connection.hashCode()+"自动提交为true");
                        pool.addLast(connection);
                        System.out.println("连接池未满,归还连接:"+connection.hashCode());
                    }else {
                        //当前连接池超过设定最大上限,直接关闭链接 无需归还
                        try {
                            connection.close();
                            System.out.println("连接池满了,关闭连接:"+connection.hashCode());
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }else {
                    System.out.println("链接已经关闭,无需归还!");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else {
            System.out.println("传入的连接为null,不可归还");
        }
    }
}
