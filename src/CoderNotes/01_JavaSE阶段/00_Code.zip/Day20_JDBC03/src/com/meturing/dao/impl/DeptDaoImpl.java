package com.meturing.dao.impl;

import com.meturing.dao.BaseDao;
import com.meturing.dao.DeptDao;
import com.meturing.pojo.Dept;

import java.util.List;

public class DeptDaoImpl extends BaseDao implements DeptDao {

    @Override
    public int addDept(Dept dept) {
        String sql = "insert into dept values(?,?,?)";
        return baseUpdate(sql,dept.getDeptno(),dept.getDname(),dept.getLoc());
    }

    @Override
    public int deleteDept(Dept dept) {
        String sql = "delete from dept where deptno=? ";
        return baseUpdate(sql,dept.getDeptno());
    }

    @Override
    public List<Dept> selectDepts(Dept dept) {
        String sql = "select *  from dept where deptno=? ";
        return baseQuery(dept.getClass(),sql,dept.getDeptno());
    }
}
