package com.meturing.日期类;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test05 {
    public static void main(String[] args) {
        //日期转换：
        //SimpleDateFormat(子类) extends DateFormat（父类是一个抽象类）
        //格式化的标准已经定义好了：
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:MM:SS");
        try {
            // String -> Date
            Date parse = dateFormat.parse("2022-07-21 12:00:00");
            System.out.println(parse);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        // Date -> String
        String format = dateFormat.format(new Date());
        System.out.println(format);

        Date date = new Date();
        System.out.println(date.toString());
        System.out.println(date.toGMTString());
        System.out.println(date.toLocaleString());
    }
}
