package com.meturing.StringBuilder类;

public class Test01 {
    public static void main(String[] args) {
        //创建StringBuilder的对象：
        StringBuilder sb3 = new StringBuilder();
        //表面上调用StringBuilder的空构造器，实际底层是对value数组进行初始化，长度为16
        StringBuilder sb2 = new StringBuilder(3);
        //表面上调用StringBuilder的有参构造器，传入一个int类型的数，实际底层就是对value数组进行初始化，长度为你传入的数字
        StringBuilder sb = new StringBuilder("abc");
        System.out.println(sb.append("def").append("aaaaaaaa").append("bbb").append("ooooooo").toString());;//链式调用方式：return this


        StringBuilder sb1 = new StringBuilder(5);
        System.out.println(sb1.append("abc")==sb1.append("def"));//true
    }
}
