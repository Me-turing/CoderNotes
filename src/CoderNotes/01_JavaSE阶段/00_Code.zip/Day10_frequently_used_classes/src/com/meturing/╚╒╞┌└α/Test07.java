package com.meturing.日期类;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class Test07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入您想查看的日期，格式：1999-11-18");
        String next = scanner.next();

        Date date = java.sql.Date.valueOf(next);
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);

        System.out.println("日\t一\t二\t三\t四\t五\t六");
        //获取当前这个月最大天数
        int maxDay = calendar.getActualMaximum(Calendar.DATE);
        //获取输入的天
        int nowDay = calendar.get(Calendar.DATE);
        //获取这个月第一天是周几？
        calendar.set(Calendar.DATE,1);
        int begin =  calendar.get(Calendar.DAY_OF_WEEK);
        //存入一个计数器
        int count = 0;
        for (int i = 0; i < begin-1; i++) {
            System.out.print("\t");
        }
        count+=begin;
        //补齐第一行
        for (int i = 1; i <= maxDay; i++){
            if (nowDay==i){
                System.out.print("*");
            }
            System.out.print(i+"\t");
            count++;
            if (count%7==0){
                System.out.println();
            }
        }
        System.out.println();
    }
}
