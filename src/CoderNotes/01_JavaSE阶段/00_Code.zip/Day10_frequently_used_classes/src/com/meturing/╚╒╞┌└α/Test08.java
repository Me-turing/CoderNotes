package com.meturing.日期类;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class Test08 {
    public static void main(String[] args) {
        //实例化
        //2022-07-21
        LocalDate localDate = LocalDate.now();
        System.out.println(localDate);
        //14:56:28.695081900
        LocalTime localTime = LocalTime.now();
        System.out.println(localTime);
        //2022-07-21T14:56:28.695081900
        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println(localDateTime);

        //设置指定的日期
        LocalDate of = LocalDate.of(2022, 7, 21);
        System.out.println(of);
        LocalTime of1 = LocalTime.of(12, 35, 56);
        System.out.println(of1);
        LocalDateTime of2 = LocalDateTime.of(2022, 7, 21, 14, 58, 58);
        System.out.println(of2);

        //LocalDate,LocalTime用的不如LocalDateTime多
        System.out.println(localDateTime.getYear());//2022
        System.out.println(localDateTime.getMonth());//JULY
        System.out.println(localDateTime.getMonthValue());//7
        System.out.println(localDateTime.getDayOfMonth());//21
        System.out.println(localDateTime.getDayOfWeek());//THURSDAY
        System.out.println(localDateTime.getDayOfYear());//202
        System.out.println(localDateTime.getHour());//15
        System.out.println(localDateTime.getMinute());//4
        System.out.println(localDateTime.getSecond());//39

        //不可变性  日期之间相互独立，不会相互影响
        //设置指定的日期，不是set 是with
        LocalDateTime localDateTime1 = localDateTime.withMonth(12);
        //2022-12-21T15:04:39.706128800
        System.out.println(localDateTime1);
        //2022-07-21T15:04:39.706128800
        System.out.println(localDateTime);

        //提供加减操作
        LocalDateTime localDateTime2 = localDateTime.plusHours(1);
        //2022-07-21T16:04:39.706128800
        System.out.println(localDateTime2);
        //2022-07-21T15:04:39.706128800
        System.out.println(localDateTime);

        LocalDateTime localDateTime3 = localDateTime.minusDays(5);
        //2022-07-16T15:04:39.706128800
        System.out.println(localDateTime3);
        //2022-07-21T15:04:39.706128800
        System.out.println(localDateTime);
    }
}
