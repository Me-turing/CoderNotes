package com.meturing.StringBuilder类;

public class Test02 {
    public static void main(String[] args) {
        StringBuilder sb=new StringBuilder("nihaojavawodeshijie");
        //增加
        sb.append("这是梦想");
        System.out.println(sb);//nihaojavawodeshijie这是梦想
        //删除
        sb.delete(3,6);////删除位置在[3,6)上的字符
        System.out.println(sb);//nihavawodeshijie这是梦想
        sb.deleteCharAt(16);
        System.out.println(sb);//nihavawodeshijie是梦想

        //修改--> 插入
        StringBuilder sb1=new StringBuilder("$23445980947");
        sb1.insert(3,",");////在下标为3的位置上插入 ,
        System.out.println(sb1);//$23,445980947

        //修改--> 替换
        sb1.replace(3,5,"我好累");//在下标[3,5)位置上替换插入字符串
        System.out.println(sb1);//$23我好累45980947
        sb1.setCharAt(3,'你');//在下标3位置上替换插入字符串
        System.out.println(sb1);//$23你好累45980947

        //查询
        StringBuilder sb3=new StringBuilder("asdfa");
        for (int i = 0; i < sb3.length(); i++) {
            System.out.print(sb3.charAt(i)+"\t");
        }

        System.out.println();
        //截取
        String str=sb3.substring(2,4);//截取[2,4)返回的是一个新的String，对StringBuilder没有影响
        System.out.println(str);
        System.out.println(sb3);
    }
}
