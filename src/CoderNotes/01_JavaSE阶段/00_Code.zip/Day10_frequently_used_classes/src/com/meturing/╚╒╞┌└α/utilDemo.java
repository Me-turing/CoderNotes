package com.meturing.日期类;

import java.util.Date;

public class utilDemo {
    //这是一个main方法，是程序的入口：
    public static void main(String[] args) {
        //java.util.Date:
        Date d = new Date();
        // Wed Jul 20 20:32:16 CST 2022
        System.out.println(d);
        // Wed Jul 20 20:32:16 CST 2022
        System.out.println(d.toString());
        // 20 Jul 2022 12:32:16 GMT
        System.out.println(d.toGMTString());//过期方法，过时方法，废弃方法。
        // 2022年7月20日 下午8:32:16
        System.out.println(d.toLocaleString());
        // 122
        System.out.println(d.getYear());//122+1900=2022
        // 6
        System.out.println(d.getMonth());//6 :返回的值在 0 和 11 之间，值 0 表示 1 月。
        //返回自 1970 年 1 月 1 日 00:00:00 GMT 以来此 Date 对象表示的毫秒数。
        // 1658320336844
        System.out.println(d.getTime());
        System.out.println(System.currentTimeMillis());

        /*
        （1）疑问：以后获取时间差用：getTime()还是currentTimeMillis()
        答案：currentTimeMillis()--》因为这个方法是静态的，可以类名.方法名直接调用
        （2）public static native long currentTimeMillis();
        本地方法
        为什么没有方法体？因为这个方法的具体实现不是通过java写的。
        （3）这个方法的作用：
        一般会去衡量一些算法所用的时间
         */
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 100000; i++) {
            System.out.println(i);
        }
        long endTime = System.currentTimeMillis();
        System.out.println(endTime-startTime);
    }
}
