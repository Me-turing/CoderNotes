package com.meturing.日期类;


import java.sql.Date;

public class Test04 {
    public static void main(String[] args) {
        Date date = Date.valueOf("2022-07-21");
        java.util.Date d = date;
        System.out.println(d.toString());
    }
}
