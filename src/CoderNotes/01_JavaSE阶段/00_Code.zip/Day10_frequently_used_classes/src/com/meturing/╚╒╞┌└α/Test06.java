package com.meturing.日期类;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Test06 {
    public static void main(String[] args) {
        Calendar gregorianCalendar = new GregorianCalendar();
        Calendar instance = Calendar.getInstance();
        System.out.println(gregorianCalendar);

        //获取当前年
        System.out.println(gregorianCalendar.get(Calendar.YEAR));
        //获取当前月  0-11
        System.out.println(gregorianCalendar.get(Calendar.MONTH));
        //获取当前日  21
        System.out.println(gregorianCalendar.get(Calendar.DATE));
        //获取当前是周几？ 分地区，默认按照周日是第一天
        // MONDAY 1， TUESDAY 2， WEDNESDAY 3, THURSDAY 4， FRIDAY 5， SATURDAY 6 ， SUNDAY  7
        //SUNDAY  1， MONDAY 2， TUESDAY 3， WEDNESDAY 4, THURSDAY 5， FRIDAY 6， SATURDAY 7 ，
        System.out.println(gregorianCalendar.get(Calendar.DAY_OF_WEEK));
        //获取当月日期的最大天数
        System.out.println(gregorianCalendar.getActualMaximum(Calendar.DATE));
        ////获取当月日期的最小天数
        System.out.println(gregorianCalendar.getActualMinimum(Calendar.DATE));


        //Set改变Calendar的内容
        gregorianCalendar.set(Calendar.YEAR,1997);
        gregorianCalendar.set(Calendar.MONTH,11);
        gregorianCalendar.set(Calendar.DATE,8);
        System.out.println(gregorianCalendar);

        //String ->  Calendar
        Date d = java.sql.Date.valueOf("2022-07-21");
        gregorianCalendar.setTime(d);
        System.out.println(gregorianCalendar);
    }
}
