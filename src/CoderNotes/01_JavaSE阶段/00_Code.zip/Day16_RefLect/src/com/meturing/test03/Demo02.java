package com.meturing.test03;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;

/**
 * 获取属性和对属性赋值
 * 字节码对象.getFields() -> 获取属性列表(仅限Public修饰)
 * 字节码对象.getDeclaredFields() -> 获取属性列表(全部)
 * 字节码对象.getField(str) -> 获取指定的属性(仅限Public修饰)
 * 字节码对象.getDeclaredField(str) -> 获取指定的属性(全部)
 * 属性对象.getModifiers() -> 获取属性的修饰符
 * 属性对象.getType() -> 获取属性的类型
 * 属性对象.getName() -> 获取属性名字
 * 属性对象.set(对象,值) -> 设置属性的值,但是要传入对象
 */
public class Demo02 {
    public static void main(String[] args) throws NoSuchFieldException, InstantiationException, IllegalAccessException {
        //获取字节码对象
        Class studentClass = Student.class;
        //获取所有的属性(Public)
        Field[] fields = studentClass.getFields();
        Arrays.stream(fields).forEach(c->{
            System.out.println(c);
        });
        System.out.println("----------------------------");
        //获取全部的属性(不限制修饰符)
        Field[] declaredFields = studentClass.getDeclaredFields();
        Arrays.stream(declaredFields).forEach(c->{
            System.out.println(c);
        });
        System.out.println("----------------------------");
        //获取指定的属性(Public)
        Field score = studentClass.getField("score");
        System.out.println(score);
        System.out.println("----------------------------");
        //获取指定的属性(全部)
        Field sno = studentClass.getDeclaredField("sno");
        System.out.println(sno);
        System.out.println("----------------------------");

        //获取属性的结构
        //获取属性的修饰符
        int modifiers = sno.getModifiers();
        System.out.println(Modifier.toString(modifiers));
        //获取属性的类型
        Class type = sno.getType();
        System.out.println(type.getName());
        //获取属性的名字
        String name = sno.getName();
        System.out.println(name);

        //给属性设置值:必须要有对象
        Field score1 = studentClass.getField("score");
        Object o = studentClass.newInstance();
        score1.set(o, 100);
        System.out.println(o);
    }
}
