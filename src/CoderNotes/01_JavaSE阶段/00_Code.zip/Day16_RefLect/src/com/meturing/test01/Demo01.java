package com.meturing.test01;

public class Demo01 {
    /**
     * 一般的使用方法
     * @param args
     */
    public static void main(String[] args) {
        String str = "微信";
        if ("微信".equals(str)) {
            weChat();
        }
        if ("支付宝".equals(str)) {
            aliPay();
        }
    }
    public static void weChat(){
        new WeChat().pay();
    }
    public static void aliPay(){
        new WeChat().pay();
    }
}
