package com.meturing.test01;

public class AliPay implements Mtwm{
    @Override
    public void pay() {
        System.out.println("正在使用支付宝支付~~~！！");
    }
}
