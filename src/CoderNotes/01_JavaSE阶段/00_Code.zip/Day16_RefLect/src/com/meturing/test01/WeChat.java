package com.meturing.test01;

public class WeChat implements Mtwm{
    @Override
    public void pay() {
        System.out.println("正在使用美团支付~~!");
    }
}
