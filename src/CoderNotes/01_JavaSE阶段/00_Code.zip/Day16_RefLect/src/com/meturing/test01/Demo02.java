package com.meturing.test01;

public class Demo02 {
    /**
     * 利用多态的优化
     * @param args
     */
    public static void main(String[] args) {
        String str = "微信";
        if ("微信".equals(str)) {
            paly(new WeChat());
        }
        if ("支付宝".equals(str)) {
            paly(new AliPay());
        }
    }
    public static void paly(Mtwm mtwm){
        mtwm.pay();
    }
}
