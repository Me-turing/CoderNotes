package com.meturing.test03;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Parameter;
import java.util.Arrays;

/**
 * 获取方法和调用方法
 * 字节对象.getMethods() -> 获取全部的方法(仅限Public修饰,包含父类)
 * 字节对象.getDeclaredMethods() -> 获取全部的方法(全部修饰符,仅限当前类)
 * 字节对象.getMethod(str) -> 获取指定的方法,参数为方法名(仅限Public修饰,包含父类)
 * 字节对象.getMethod(str,str,...,str) -> 获取指定的方法,参数为方法名,方法参数类型(仅限Public修饰,包含父类)
 * 字节对象.getDeclaredMethod(str) -> 获取指定的方法,参数为方法名(全部修饰符,仅限当前类)
 * 字节对象.getDeclaredMethod(str,str,...,str) -> 获取指定的方法,参数为方法名,方法参数类型(全部修饰符,仅限当前类)
 *
 * 方法对象.getModifiers() -> 获取方法修饰符
 * 方法对象.getReturnType() -> 获取方法返回类型
 * 方法对象.getName() -> 获取方法名
 * 方法对象.getParameters() -> 获取方法参数列表
 * 方法对象.getParameterTypes() -> 获取方法参数类型列表
 * 方法对象.getExceptionTypes() -> 获取方法异常类型
 * 方法对象.getAnnotations() -> 获取方法注解
 *
 * 方法对象.invoke(object) -> 执行无参方法
 * 方法对象.invoke(object,str,...,str) -> 执行带参方法
 */
public class Demo03 {
    public static void main(String[] args) throws NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
        Class<Student> studentClass = Student.class;

        //获取运行时类的方法还有所有父类中的方法(仅限Public修饰,包含父类)
        Method[] methods = studentClass.getMethods();
        Arrays.stream(methods).forEach(c -> {
            System.out.println(c);
        });
        System.out.println("-----------------------");
        //获取运行时类中的所有方法(全部,只有当前类)
        Method[] declaredMethods = studentClass.getDeclaredMethods();
        Arrays.stream(declaredMethods).forEach(c -> {
            System.out.println(c);
        });
        System.out.println("-----------------------");
        //获取指定的方法
        Method showInfo1 = studentClass.getMethod("showInfo");
        System.out.println(showInfo1);
        Method showInfo2 = studentClass.getMethod("showInfo",int.class,int.class);
        System.out.println(showInfo2);
        Method work = studentClass.getDeclaredMethod("work", int.class);
        System.out.println(work);
        System.out.println("------------------------------");

        //获取方法的结构
         /*
        @注解
        修饰符 返回值类型  方法名(参数列表) throws XXXXX{}
         */
        //获取名字
        System.out.println(Modifier.toString(work.getModifiers()));//获取修饰符
        System.out.println(work.getReturnType());//获取返回类型
        System.out.println(work.getName());//获取方法名
        Parameter[] parameters = showInfo2.getParameters();//获取参数列表
        Arrays.stream(parameters).forEach(c -> System.out.println(c));
        Class<?>[] parameterTypes = work.getParameterTypes();//获取参数类型
        Arrays.stream(parameterTypes).forEach(c -> System.out.println(c));

        Method myMethod = studentClass.getMethod("myMethod");
        Class<?>[] exceptionTypes = myMethod.getExceptionTypes();//获取异常
        Arrays.stream(exceptionTypes).forEach(c -> System.out.println(c));
        Annotation[] annotations = myMethod.getAnnotations();//获得注解
        Arrays.stream(annotations).forEach(c -> System.out.println(c));


        //调用方法
        System.out.println("-------------------------");
        Student student = studentClass.newInstance();
        myMethod.invoke(student);
        System.out.println(showInfo2.invoke(student, 1,1));


    }
}
