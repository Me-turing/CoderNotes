package com.meturing.test03;

import java.lang.annotation.Annotation;
import java.util.Arrays;

/**
 * 获取类的接口，所在包，注解
 * 字节码对象.getInterfaces() -> 获取接口
 * 字节码对象.getSuperclass() -> 获取父类的字节码对象
 * 字节码对象.getPackage() -> 当前类所在的包
 * 字节码对象.getPackage().getName() -> 当前类所在的包名
 * 字节码对象.getAnnotations() -> 当前类的注解
 */
public class Demo04 {
    public static void main(String[] args) {
        Class<Student> studentClass = Student.class;

        //获取当前类的接口
        Class<?>[] interfaces = studentClass.getInterfaces();
        Arrays.stream(interfaces).forEach(c -> {
            System.out.println(c);
        });

        //获取父类的接口
        Class<? super Student> superclass = studentClass.getSuperclass();
        Class<?>[] interfaces1 = superclass.getInterfaces();
        Arrays.stream(interfaces1).forEach(c -> System.out.println(c));

        //获取所在的包
        Package aPackage = studentClass.getPackage();
        System.out.println(aPackage);
        System.out.println(aPackage.getName());

        //获取类上的注解
        Annotation[] annotations = studentClass.getAnnotations();
        Arrays.stream(annotations).forEach(c -> System.out.println(c));
    }
}
