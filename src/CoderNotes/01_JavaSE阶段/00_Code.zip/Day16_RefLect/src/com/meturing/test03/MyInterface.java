package com.meturing.test03;

public interface MyInterface {
    //随便定义一个抽象方法：
    void myMethod();
}
