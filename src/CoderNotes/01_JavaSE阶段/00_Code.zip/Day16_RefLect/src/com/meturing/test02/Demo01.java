package com.meturing.test02;

/**
 * 测试获取字节对象的四种方式
 */
public class Demo01 {
    public static void main(String[] args) throws ClassNotFoundException {
        //通过对象获取
        Person person = new Person();
        Class personClass1 = person.getClass();
        System.out.println(personClass1);

        //通过类的内置.Class属性
        Class personClass2 = Person.class;
        System.out.println(personClass2);

        //通过字节码包名获取[推荐]
        Class personClass3 = Class.forName("com.meturing.test02.Person");
        System.out.println(personClass3);

        //通过类加载器获取
        ClassLoader classLoader = Demo01.class.getClassLoader();
        Class personClass4 = classLoader.loadClass("com.meturing.test02.Person");
        System.out.println(personClass4);
    }
}
