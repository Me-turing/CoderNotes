package com.meturing.test02;

import java.awt.*;

/*
    Class类的具体的实例：
        （1）类：外部类，内部类
        （2）接口
        （3）注解
        （4）数组
        （5）基本数据类型
        （6）void
 */
public class Demo02 {
    public static void main(String[] args) {
        Class personClass1 = Person.class;
        Class componentClass = Component.class;
        Class overrideClass = Override.class;

        String[] strArray1 = new String[1];
        Class aClass1 = strArray1.getClass();
        String[] strArray2 = new String[1];
        Class aClass2 = strArray2.getClass();
        System.out.println(aClass1==aClass2);//结果：true .同一个维度，同一个元素类型,得到的字节码就是同一个

        Class integerClass = int.class;
        Class voidClass = void.class;
    }
}
