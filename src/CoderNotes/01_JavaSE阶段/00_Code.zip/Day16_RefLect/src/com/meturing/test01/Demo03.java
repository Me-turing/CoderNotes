package com.meturing.test01;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Demo03 {
    /**
     * 利用反射通过字节码获取方法
     * @param args
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     */
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        String str = "com.meturing.test01.AliPay";
        Class aClass = Class.forName(str);//cls-->Class类具体的对象--》AliPay字节码信息
        Object o = aClass.newInstance();//通过字节码获取对象实例化
        Method paly = aClass.getMethod("pay");//获取方法
        paly.invoke(o);//执行方法
    }
}
