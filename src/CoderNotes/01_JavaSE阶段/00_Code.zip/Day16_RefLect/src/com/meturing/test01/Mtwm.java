package com.meturing.test01;

public interface Mtwm {
     void pay();
}
