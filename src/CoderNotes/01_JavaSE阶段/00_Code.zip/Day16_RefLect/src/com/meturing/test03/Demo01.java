package com.meturing.test03;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

/**
 * 获取构造器和创建对象
 * 字节码对象.getConstructors() -> 获取构造器列表(仅限Public修饰)
 * 字节码对象.getDeclaredConstructors() -> 获取构造器列表(全部)
 * 字节码对象.getConstructor() -> 获取指定的无参构造器(仅限Public修饰)
 * 字节码对象.getConstructor(Class,Class,.....) -> 获取带参的构造器,参数传入构造器的参数类型.class(仅限Public修饰)
 * 字节码对象.getDeclaredConstructor(Class,.....) -> 获取编译后的指定构造器,参数传入构造器的参数类型.class(全部)
 */
public class Demo01 {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Class studentClass = Student.class;//获取到字节码对象

        //通过字节码信息可以获取构造器：
        //getConstructors只能获取当前运行时类的被public修饰的构造器
        Constructor[] constructors = studentClass.getConstructors();
        Arrays.stream(constructors).forEach(c->{
            System.out.println(c);
        });
        System.out.println("-------------------");
        //getDeclaredConstructors:获取运行时类的全部修饰符的构造器
        Constructor[] declaredConstructors = studentClass.getDeclaredConstructors();
        Arrays.stream(declaredConstructors).forEach(c->{
            System.out.println(c);
        });
        System.out.println("-------------------");
        //获取指定的构造器：
        //得到空构造器(仅限Public修饰)
        Constructor constructor = studentClass.getConstructor();
        System.out.println(constructor);
        //得到两个参数的构造器(仅限Public修饰)
        Constructor constructor1 = studentClass.getConstructor(int.class,int.class);
        System.out.println(constructor1);
        //得到一个参数的构造器(全部)
        Constructor declaredConstructor = studentClass.getDeclaredConstructor(int.class);
        System.out.println(declaredConstructor);

        //有了构造器以后我就可以创建对象：
        Object o = constructor.newInstance();
        System.out.println(o);
        Object o1 = constructor1.newInstance(10,10);
        System.out.println(o1);
    }
}
