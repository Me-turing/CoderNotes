import com.meturing.com.Calculator;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class Test01 {
    @Before
    public void testBefore(){
        System.out.println("测试方法执行前先执行，通常用来申请资源");
    }

    @After
    public void testAfter(){
        System.out.println("测试方法执行后执行，通常用来释放资源");
    }
    @Test
    public void testAdd(){
        Calculator calculator = new Calculator();
        int add = calculator.add(10, 20);
        Assert.assertEquals(40,add);//加入断言，判断接受是否符合预期的40
        System.out.println(add);
    }

    @Test
    public void testSub(){
        Calculator calculator = new Calculator();
        int sub = calculator.sub(20, 10);
        Assert.assertEquals(0,sub);//加入断言，判断接受是否符合预期的40
        System.out.println(sub);
    }
}
