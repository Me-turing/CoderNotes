package com.meturing.com;

/**
 *
 */
public class Calculator {
    /**
     * 测试
     * @param a
     * @param b
     * @return
     */
    @MyAnnotation()
    public int add(int a ,int b){
        return  a + b;
    }

    @MyAnnotation({"a","b"}) // 同等于@MyAnnotation(value = {"a","b"}) 单个参数的时候可以省略
    public int sub(int a ,int b){
        return  a - b;
    }
}
