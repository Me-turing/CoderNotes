package com.meturing.enumTest;

public class TestDemo01 {
    public static void main(String[] args) {
        Season summer = Season.SUMMER;
        summer.Show();
        Season autumn = Season.AUTUMN;
        autumn.Show();
    }
}
