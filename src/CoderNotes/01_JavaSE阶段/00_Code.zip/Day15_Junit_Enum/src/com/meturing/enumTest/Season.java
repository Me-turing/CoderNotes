package com.meturing.enumTest;

public enum Season implements TestInterface{
    SPRING{
        @Override
        public void Show() {
            System.out.println("春天");
        }
    },
    SUMMER{
        @Override
        public void Show() {
            System.out.println("夏天");
        }
    },
    AUTUMN{
        @Override
        public void Show() {
            System.out.println("秋天");
        }
    },
    WINTER{
        @Override
        public void Show() {
            System.out.println("冬天");
        }
    };

//    @Override
//    public void Show() {
//        System.out.println("Season.show()");
//    }
}
