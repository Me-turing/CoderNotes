package com.meturing.enumTest;

public interface TestInterface {
    void Show();
}
