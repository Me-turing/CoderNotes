package com.meturing.com;

public @interface MyAnnotation {
    String[] value() default  {"123","456"};
}
