package com.meturing.stream.demo01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class demo01 {
    public static void main(String[] args) {
        //素材
        List<String> nameList = Arrays.asList("张三", "张三丰", "李四", "王五");
        //获取所有姓张的名字并且长度为3
        ArrayList<String> arrayList = new ArrayList();
        for (String name : nameList) {
            if (name.startsWith("张")&&name.length()==3) {
                arrayList.add(name);
            }
        }
        for (String s : arrayList) {
            System.out.println(s);
        }



        //使用Lambda表达式优化
        List<String> arrayList1 = nameList.stream()
                    .filter(s -> s.startsWith("张"))//过滤张开头的
                    .filter(s -> s.length()==3)//过滤长度等于3
                    .collect(Collectors.toList());//转换成新的List数组
        arrayList1.stream().forEach(System.out::println);
    }
}
