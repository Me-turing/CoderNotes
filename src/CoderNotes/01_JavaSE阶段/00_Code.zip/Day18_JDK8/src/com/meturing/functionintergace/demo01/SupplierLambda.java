package com.meturing.functionintergace.demo01;

import java.util.Arrays;
import java.util.function.Supplier;

public class SupplierLambda {
    public static void main(String[] args) {
        fin1(()->{
            int[] arr = {1,2,3,4,5,6,7,8,9,10};
            return  Arrays.stream(arr).reduce(0, Integer::sum);
        });
    }
    public static void  fin1(Supplier<Integer> supplier){
        Integer max = supplier.get();
        System.out.println(max);
    }
}
