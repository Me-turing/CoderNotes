package com.meturing.stream.demo01;

import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Stream;

public class demo04 {
    public static void main(String[] args) {
/*        Stream.of("张三", "李四")
                .forEach(System.out::println);
        long count = Stream.of("张三", "李四").count();
        System.out.println(count);

        Stream.of("张三", "李四")
                .filter(s->s.startsWith("张")) //李四
                .forEach(System.out::println);

        Stream.of("张三", "李四")
                .limit(1)//李四
                .forEach(System.out::println);

        Stream.of("张三", "李四")
                .skip(5)//李四
                .forEach(System.out::println);
        System.out.println("==========");
        Integer integer1 = Stream.of("1", "2", "3", "4", "5")
                .map(msg -> Integer.parseInt(msg))
                .reduce(Integer::sum).get();
        System.out.println(integer1);

        Integer integer = Stream.of("1", "2", "3", "4", "5")
                .map(Integer::parseInt)
                .reduce(Integer::sum).get();
        System.out.println(integer);*/

//        Stream.of("11", "121", "31", "14", "5")
//                .map(Integer::parseInt)
//                .sorted()//根据数据的自然排序
//                .forEach(System.out::println);
//
//        Stream.of("11", "121", "31", "14", "5")
//                .map(Integer::parseInt)
//                .sorted((o1, o2) -> o2-o1)//根据数据的自然倒序
//                .forEach(System.out::println);

/*        Stream.of("1", "12", "31", "12", "5")
                .distinct()
                .forEach(System.out::println);//1 12 31 5

        //自定义类型需要重新 equals 和 hashCode 方法才可以生效
        Stream.of(new Student("张三",19),
                new Student("李四",19),
                new Student("张三",19))
                .distinct()
                .forEach(System.out::println);*/
/*        boolean b1 = Stream.of("1", "12", "31", "12", "5")
                .map(Integer::parseInt)
                .allMatch(s -> s > 0);
        System.out.println(b1);//true

        boolean b2 = Stream.of("1", "12", "31", "12", "5")
                .map(Integer::parseInt)
                .anyMatch(s -> s > 0);
        System.out.println(b2);//true

        boolean b3 = Stream.of("1", "12", "31", "12", "5")
                .map(Integer::parseInt)
                .noneMatch(s -> s > 0);
        System.out.println(b3);//false*/
   /*     Stream<String> stringStream1 = Stream.of("1", "12", "31", "12", "5");
        Optional<String> first = stringStream1.findFirst();
        System.out.println(first.get());

        Stream<String> stringStream2 = Stream.of("1", "12", "31", "12", "5");
        Optional<String> any = stringStream2.findAny();
        System.out.println(any.get());*/

/*
        Stream<Integer> integerStream1 = Stream.of("1", "12", "31", "12", "5").map(Integer::parseInt);
        Integer integerMax = integerStream1.max((o1, o2) -> o1 - o2).get();
        System.out.println(integerMax);//31

        Stream<Integer> integerStream2 = Stream.of("1", "12", "31", "12", "5").map(Integer::parseInt);
        Integer integerMin = integerStream2.min((o1, o2) -> o1 - o2).get();
        System.out.println(integerMin);//1
*/
        //求和
        Integer integer2 = Stream.of("1", "2", "3", "4", "5")
                .map(msg -> Integer.parseInt(msg))
                .reduce(0,(x,y) -> x + y);
        System.out.println(integer2);

        // 获取最大值
        Integer integer3 = Stream.of("1", "2", "3", "4", "5")
                .map(msg -> Integer.parseInt(msg))
                .reduce(0,(x,y) -> {
                    return x>y?x:y;
                });
        System.out.println(integer3);


        //求和
        Integer integer1 = Stream.of("1", "2", "3", "4", "5")
                .map(msg -> Integer.parseInt(msg))
                .reduce(Integer::sum).get();
        System.out.println(integer1);

    }
}
