package com.meturing.functionintergace.demo01;

import java.util.Arrays;

public class Test01 {
    public static void main(String[] args) {
        fun1((arr)->{
//            int sum = 0;
//            for (int i : arr) {
//                sum+=i;
//            }
//            return sum;
            int reduce = Arrays.stream(arr).reduce(0, Integer::sum);
            return reduce;
        });
    }
    public static void  fun1(Operator Operator){
        int[] arrys = {1,2,3,4};
        int sum = Operator.sum(arrys);
        System.out.println("执行结果为:"+sum);
    }
}

/**
 * 函数式接口
 */
@FunctionalInterface
interface Operator{
    int sum(int[] arry);
}