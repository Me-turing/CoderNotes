package com.meturing.stream.demo01;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class demo08 {
    public static void main(String[] args) {
        //原始写法:由Stream进行操作时自动装箱拆箱
        Stream<String> stream1 = Stream.of("1", "2");
        Stream<String> stream2 = Stream.of("3", "4");

        Stream<String> concat = Stream.concat(stream1, stream2);
        concat.forEach(System.out::println);//1 2 3 4
    }
}