package com.meturing.referencemethod.demo01;

import java.util.Date;
import java.util.function.Supplier;

public class demo02 {
    public static void main(String[] args) {
        Date date = new Date();
        Supplier<Long> supplier = ()-> date.getTime();
        System.out.println(supplier.get());

        //使用方法引用改写
        Supplier<Long> supplier1 =  date::getTime;
        System.out.println(supplier1.get());
    }
}
