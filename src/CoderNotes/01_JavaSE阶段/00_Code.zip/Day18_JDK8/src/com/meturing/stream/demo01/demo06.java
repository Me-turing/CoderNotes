package com.meturing.stream.demo01;

import java.util.stream.Stream;

public class demo06 {
    public static void main(String[] args) {
        Stream<Student> studentStream = Stream.of(new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22));
//        Integer reduce = studentStream.map(p -> p.getAge()).reduce(0, (x, y) -> x + y);
        //简化代码
        Integer reduce = studentStream.map(Student::getAge).reduce(0, Integer::sum);
        System.out.println(reduce);

        //统计a出现的次数
        Stream<String> stream1 = Stream.of("a", "v", "a", "2");
        Integer reduce1 = stream1.map(msg -> "a".equals(msg) ? 1 : 0)
                .reduce(0, Integer::sum);
        System.out.println(reduce1);
    }
}
