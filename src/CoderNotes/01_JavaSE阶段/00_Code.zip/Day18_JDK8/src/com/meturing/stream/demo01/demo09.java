package com.meturing.stream.demo01;

import javax.naming.Name;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * 定义两个队伍进行操作:
 * 1. 第一个队伍只保留姓名长度为3的成员
 * 2. 第一个队伍筛选之后只要前3人
 * 3. 第二个队伍只要姓张的成员
 * 4. 第二个队伍筛选之后不要前两个人
 * 5. 将两个队伍合并成为一个队伍
 * 6. 根据姓名创建Student对象
 * 7. 打印整个Student信息
 */
public class demo09 {
    public static void main(String[] args) {
        List<String> list1 = new ArrayList<String>();
        list1.add("张三");
        list1.add("张三封");
        list1.add("李四");
        list1.add("王二妹");
        list1.add("赵麻子");
        list1.add("李旺旺");
        Stream<String> list1Stream = list1.stream()
                .filter(name -> name.length() == 3)//第一个队伍只保留姓名长度为3的成员
                .limit(3);//第一个队伍筛选之后只要前3人

        List<String> list2 =  new ArrayList<String>();
        list2.add("张二");
        list2.add("张二妹");
        list2.add("张大脸");
        list2.add("赵旺");
        list2.add("孙火旺");
        list2.add("张无忌");
        Stream<String> list2Stream = list2.stream()
                .filter(name -> name.startsWith("张"))//第二个队伍只要姓张的成员
                .skip(2);//第二个队伍筛选之后不要前两个人

        Stream<String> concat = Stream.concat(list1Stream, list2Stream);//将两个队伍合并成为一个队伍
        Stream<Student> studentStream = concat.map(s -> new Student(s));//根据姓名创建Student对象
        studentStream.forEach(System.out::println);//打印整个Student信息
    }
}