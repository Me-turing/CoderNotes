package com.meturing.enhancedinterface.demo01;

public class Test01 {
    public static void main(String[] args) {
        A a1 = new B();
        a1.test();//使用接口的默认方法
        A a2 = new C();
        a2.test();//使用实现类重写的方法
    }
}

interface A {
    void say();
    //新增的抽象方法 需要在后续的实现类中都进行重写
    void show();

    /**
     * 接口中定义的默认方法
     * @return
     */
    public default String  test(){
        System.out.println("方法中的默认方法");
        return "Hello";
    }
}
class B implements A{
    @Override
    public void say() {

    }
    @Override
    public void show() {

    }
}
class C implements A{
    @Override
    public void say() {

    }
    @Override
    public void show() {

    }

    /**
     * 重写默认方法
     * @return
     */
    @Override
    public String test() {
        System.out.println("B");
        return "BBBB";
    }
}