package com.meturing.anno;

import com.meturing.enhancedinterface.demo01.Test01;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

@MyAnnotation("Test1")
@MyAnnotation("Test2")
@MyAnnotation("Test3")
public class AnnoTest01 {

    @MyAnnotation("fun1")
    @MyAnnotation("fun2")
    public void test01(){

    }

    /**
     * 解析重复注解
     * @param args
     */
    public static void main(String[] args) throws NoSuchMethodException {
        //获取类上的注解
        MyAnnotation[] annotationsByType = AnnoTest01.class.getAnnotationsByType(MyAnnotation.class);
        for (MyAnnotation myAnnotation : annotationsByType) {
            System.out.println(myAnnotation.value());
        }
        //获取方法上的注解
        MyAnnotation[] test01s = AnnoTest01.class.getDeclaredMethod("test01").getAnnotationsByType(MyAnnotation.class);
        for (MyAnnotation test01 : test01s) {
            System.out.println(test01.value());
        }
    }
}
