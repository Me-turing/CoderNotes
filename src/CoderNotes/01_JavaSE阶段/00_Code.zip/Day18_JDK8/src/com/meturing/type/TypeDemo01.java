package com.meturing.type;

public class TypeDemo01 <@TypeParam  T>{
    public <@TypeParam K extends Object> K test01(){
        return null;
    }
}
