package com.meturing.referencemethod.demo01;

import java.util.function.Consumer;


public class demo01 {
    public static void main(String[] args) {
//        getMax(arr->{
//            int sum = 0;
//            for (int i : arr) {
//                sum+=i;
//            }
//            System.out.println(sum);
//        });

//        getMax(arr->demo01.getTotal(arr));
        getMax(demo01::getTotal); //相当于执行了getTotal
    }

    /**
     * 获取数组的合
     * @param arr
     */
    public static void getTotal(int[] arr) {
        int sum = 0;
        for (int i : arr) {
            sum+=i;
        }
        System.out.println(sum);
    }

    public static void getMax(Consumer<int[]> consumer) {
        int[] arr = {1,2,3,4,5};
        consumer.accept(arr);
    }
}
