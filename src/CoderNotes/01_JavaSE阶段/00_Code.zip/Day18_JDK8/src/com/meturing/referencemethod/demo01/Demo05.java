
package com.meturing.referencemethod.demo01;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class Demo05 {
    public static void main(String[] args) {
        Supplier<String> supplier = ()-> {return new String();};
        System.out.println(supplier.hashCode());

        //使用引用方法创建
        Supplier<String> supplier1 = String::new;
        System.out.println(supplier1.hashCode());

        Function<String,String> function = String::new;
        System.out.println(function.apply("aaa"));
    }
}
