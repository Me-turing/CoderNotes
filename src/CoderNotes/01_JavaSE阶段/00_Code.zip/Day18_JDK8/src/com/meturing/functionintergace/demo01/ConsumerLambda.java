package com.meturing.functionintergace.demo01;

import java.util.Locale;
import java.util.function.Consumer;

public class ConsumerLambda {
    public static void main(String[] args) {
        testConsumer1(msg->{
            System.out.println(msg+"->转换成小写:"+msg.toLowerCase());
        });

        testConsumer2(msg1->{
            System.out.println(msg1+"->转换成小写:"+msg1.toLowerCase());
        },msg2->{
            System.out.println(msg2+"->转换成大写:"+msg2.toUpperCase());
        });
    }

    /**
     * 对给定参数执行此操作
     * @param consumer
     */
    public static void testConsumer1(Consumer<String> consumer) {
        consumer.accept("Hello");
    }

    /**
     * andThen 表示先后执行顺序
     * consumer1.andThen(consumer2).accept(str);
     * 先执行consumer1.accept(str); 在执行 consumer2.accept(str);
     * @param consumer1
     * @param consumer2
     */
    public static void testConsumer2(Consumer<String> consumer1,Consumer<String> consumer2) {
        String str ="Hello";
//        consumer1.accept(str);
//        consumer2.accept(str);
        consumer1.andThen(consumer2).accept(str);
    }
}
