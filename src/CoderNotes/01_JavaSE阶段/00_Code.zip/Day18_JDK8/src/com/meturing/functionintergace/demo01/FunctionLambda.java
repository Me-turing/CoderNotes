package com.meturing.functionintergace.demo01;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FunctionLambda {
    public static void main(String[] args) {
        testFunction1(msg->{
            return Integer.parseInt(msg);
        });

        testFunction2(msg1->{
            return Integer.parseInt(msg1);
        },msg2->{
            return msg2 * 10;
        });

        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("111");
        arrayList.add("222");
        arrayList.add("333");
        Stream<String> stream = arrayList.stream();
//        Map<String, String> collect = stream.collect(Collectors.toMap(t->t, t->t));
        Map<String, String> collect = stream.collect(Collectors.toMap(Function.identity(), Function.identity()));
    }

    /**
     *
     * @param function
     */
    public static void testFunction1(Function<String,Integer> function){
        Integer apply = function.apply("666");
        System.out.println(apply);
    }

    /**
     *
     * @param
     */
    public static void testFunction2(Function<String,Integer> function1,Function<Integer,Integer> function2){
//        Integer apply1 = function1.apply("666");
//        Integer apply = function2.apply(apply1);
//        Integer apply = function1.andThen(function2).apply("666"); //先执行function1 再执行 function2
        Integer apply = function2.compose(function1).apply("666");// function2在function1之前执行
        System.out.println(apply);
    }
}
