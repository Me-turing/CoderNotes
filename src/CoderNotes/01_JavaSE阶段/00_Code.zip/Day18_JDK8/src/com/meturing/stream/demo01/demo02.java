package com.meturing.stream.demo01;


import javafx.print.Collation;

import java.util.*;
import java.util.stream.Stream;

public class demo02 {
    public static void main(String[] args) {
        ArrayList<String> strings = new ArrayList<>();
        Stream<String> stream = strings.stream();

        HashSet<String> strings1 = new HashSet<>();
        Stream<String> stream1 = strings1.stream();

        Vector<String> strings2 = new Vector<>();
        Stream<String> stream2 = strings2.stream();

        HashMap<String, String> stringStringHashMap = new HashMap<>();
        Set<String> strings3 = stringStringHashMap.keySet();//获取全部的Key集合
        Stream<String> stream3 = strings3.stream();
        Collection<String> values = stringStringHashMap.values();//获取全部的Values集合
        Stream<String> stream4 = values.stream();
        Set<Map.Entry<String, String>> entries = stringStringHashMap.entrySet();//获取entrySet集合
        Stream<Map.Entry<String, String>> stream5 = entries.stream();
    }
}
