package com.meturing.stream.demo01;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class demo07 {
    public static void main(String[] args) {
        //原始写法:由Stream进行操作时自动装箱拆箱
        Integer arr[] = {1,2,34,5};
        Stream.of(arr)
                .filter(s->s>0)
                .forEach(System.out::println);

        //优化代码:将包装类提前拆箱
        IntStream intStream = Stream.of(arr).mapToInt(Integer::intValue);
        intStream.filter(i->i>0).forEach(System.out::println);
    }
}
