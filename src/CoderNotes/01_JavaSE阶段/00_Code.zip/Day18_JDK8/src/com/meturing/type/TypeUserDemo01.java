package com.meturing.type;

public class TypeUserDemo01 {
    public @NotNull Integer agentId = 10;

    public void test02(@NotNull String name,@NotNull String sex){

    }
}
