package com.meturing.stream.demo01;


import java.util.*;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class demo03 {
    public static void main(String[] args) {
        Stream<String> stream1 = Stream.of("张三", "李四");
        stream1.forEach(System.out::println);

        String[] names2 = {"张三","李四"};
        Stream<String> stream2 = Stream.of(names2);
        stream2.forEach(System.out::println);

        // 注意:基本数据类型的数组是不行的
        int[] names3 = {1,2,3,4};
//        Stream<int[]> stream3 = Stream.of(names3);
        IntStream stream3 = Arrays.stream(names3);
        stream3.forEach(System.out::println);
    }
}
