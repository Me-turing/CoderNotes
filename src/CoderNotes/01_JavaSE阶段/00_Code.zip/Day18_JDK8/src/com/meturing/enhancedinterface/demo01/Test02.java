package com.meturing.enhancedinterface.demo01;

public class Test02 {
    public static void main(String[] args) {
        AA aa = new BB();
//        aa.sayHello();
       AA.sayHello(); //静态方法只能通过接口名直接使用,且子类无法重写
    }
}
interface AA {
    void test();
    public static String sayHello(){
        System.out.println("sayHello");
        return "Hello";
    }
}

class BB implements AA {
    @Override
    public void test() {

    }
}