package com.meturing.referencemethod.demo01;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

public class Demo04 {
    public static void main(String[] args) {
        Function<String,Integer> function = (s)-> s.length();
        System.out.println(function.apply("hello"));//5
        //使用引用方法改写
        Function<String,Integer> function1 = String::length;
        System.out.println(function1.apply("hello"));//5

        BiFunction<String,Integer,String> function2 = String::substring;
        String absjnsj = function2.apply("absjnsj", 3);//jnsj
        System.out.println(absjnsj);
    }
}
