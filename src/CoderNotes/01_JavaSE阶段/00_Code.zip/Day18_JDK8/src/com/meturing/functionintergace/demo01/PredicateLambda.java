package com.meturing.functionintergace.demo01;

import java.util.function.Predicate;

public class PredicateLambda {
    public static void main(String[] args) {
        test1(msg->{
            return msg.contains("H");
        },"Hello");

        test2(msg1->{
            return msg1.contains("H");
        },msg2->{
            return msg2.contains("W");
        },"Hello");
    }
    public static void test1(Predicate<String> predicate,String msg){
        System.out.println(predicate.test(msg));
    }
    public static void test2(Predicate<String> predicate1,Predicate<String> predicate2,String msg){
        //predicate1 和 predicate2 都满足
        boolean test1 = predicate1.and(predicate2).test(msg);//false
        //predicate1 或 predicate2 满足
        boolean test2 = predicate1.or(predicate2).test(msg);//true
        //predicate1 不满足
        boolean test3 = predicate1.negate().test(msg);//false
        System.out.println(test1);
        System.out.println(test2);
        System.out.println(test3);
    }
}
