
package com.meturing.referencemethod.demo01;

import java.util.function.Function;
import java.util.function.Supplier;

public class Demo06 {
    public static void main(String[] args) {
        Function<Integer,String[]> function1 = (len)->{return new String[len];};
        System.out.println(function1.apply(3).length);
        //使用引用方法创建
        Function<Integer,String[]> function2 = String[]::new;
        System.out.println(function2.apply(3).length);
    }
}
