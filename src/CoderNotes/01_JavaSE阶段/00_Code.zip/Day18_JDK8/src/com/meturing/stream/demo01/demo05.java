package com.meturing.stream.demo01;

import java.util.ArrayList;

public class demo05 {
    public static void main(String[] args) {
        StudentVo StudentVo1 = new StudentVo("张三", 15);
        StudentVo StudentVo2 = new StudentVo("李四", 16);
        ArrayList<StudentVo> studentVos = new ArrayList<>();
        studentVos.add(StudentVo1);
        studentVos.add(StudentVo2);

        studentVos.stream()
                .map(demo05::transFormation)
                .forEach(System.out::println);
    }

    public static Student transFormation(StudentVo StudentVo){
        return new Student(StudentVo.getName(),StudentVo.getAge());
    }
}
