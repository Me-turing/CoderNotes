package com.meturing.referencemethod.demo01;

import java.util.function.Supplier;

public class Demo03 {
    public static void main(String[] args) {
        Supplier<Long> supplier = ()->{
            return System.currentTimeMillis();
        };
        System.out.println(supplier.get());

        //使用引用方法改写
        Supplier<Long> supplier1 = System::currentTimeMillis;
        System.out.println(supplier1.get());
    }
}
