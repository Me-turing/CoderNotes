package com.meturing.testdemo;

import org.junit.Test;

import java.time.*;
import java.util.Set;

public class test13 {
    /**
     * 时区操作
     */
    @Test
    public void test1(){
        //获取所有的时区ID
        //ZoneId.getAvailableZoneIds().forEach(System.out::println);

        //获取当前时间 中国使用的是东八区的时区,比标准时间早八个小时
        LocalDateTime now = LocalDateTime.now();
        System.out.println(now);//2022-12-25T19:33:09.036

        //获取标准时间
        ZonedDateTime now1 = ZonedDateTime.now(Clock.systemUTC());
        System.out.println(now1);// 2022-12-25T11:33:09.036Z

        //获取特定时区的时间
        //以当前计算机时区获取时间
        ZonedDateTime now2 = ZonedDateTime.now();
        System.out.println(now2);//2022-12-25T19:33:09.036+08:00[Asia/Shanghai]
        //设定指定时区的时间
        ZonedDateTime now3 = ZonedDateTime.now(ZoneId.of("America/Marigot"));
        System.out.println(now3);//2022-12-25T07:33:09.036-04:00[America/Marigot]
    }
}
