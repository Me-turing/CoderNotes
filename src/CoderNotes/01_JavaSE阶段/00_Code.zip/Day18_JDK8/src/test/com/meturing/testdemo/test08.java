package com.meturing.testdemo;

import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Date;

public class test08 {
    /**
     * 新版JDK8 日期时间操作
     */
    @Test
    public void test01() throws ParseException {
        //创建指定的日期时间
        LocalDate date1 = LocalDate.of(2022, 11, 18);
        System.out.println(date1);//2022-11-18

        //获取当前的日期
        LocalDate date2 = LocalDate.now();
        System.out.println(date2);//2022-12-18

        //根据我们的LocalDate对象获取对应的日期信息
        System.out.println("年:"+date2.getYear());//年:2022
        System.out.println("月:"+date2.getMonth());//月:DECEMBER
        System.out.println("月:"+date2.getMonth().getValue());//月:12
        System.out.println("日:"+date2.getDayOfMonth());//日:18
        System.out.println("星期:"+date2.getDayOfWeek());//星期:SUNDAY
        System.out.println("星期:"+date2.getDayOfWeek().getValue());//星期:7
    }

    /**
     * 新版时间操作
     */
    @Test
    public void test02(){
        //获取指定的时间
        LocalTime time1 = LocalTime.of(5, 26, 33, 23145);
        System.out.println(time1);//05:26:33.000023145

        //获取当前的时间
        LocalTime time2 = LocalTime.now();
        System.out.println(time2);//23:43:44.644

        //获取时间信息
        System.out.println("小时:"+time2.getHour());//小时:23
        System.out.println("分钟:"+time2.getMinute());//分钟:45
        System.out.println("秒:"+time2.getSecond());//秒:52
        System.out.println("纳秒:"+time2.getNano());//纳秒:145000000
    }

    /**
     * 新版日期时间操作
     */
    @Test
    public void test03(){
        //获取指定的时间
        LocalDateTime dateTime = LocalDateTime.of(2020,
                                                    06,
                                                    01,
                                                    12,
                                                    12,
                                                    33,
                                                    1511);
        System.out.println(dateTime);//2020-06-01T12:12:33.000001511

        //获取当前的时间
        LocalDateTime nowDateTime = LocalDateTime.now();
        System.out.println(nowDateTime);//2022-12-18T23:49:14.329

        //获取时间信息
        System.out.println("年:"+nowDateTime.getYear());//年:2022
        System.out.println("月:"+nowDateTime.getMonth());//月:DECEMBER
        System.out.println("月:"+nowDateTime.getMonth().getValue());//月:12
        System.out.println("日:"+nowDateTime.getDayOfMonth());//日:18
        System.out.println("星期:"+nowDateTime.getDayOfWeek());//星期:SUNDAY
        System.out.println("星期:"+nowDateTime.getDayOfWeek().getValue());//星期:7
        System.out.println("小时:"+nowDateTime.getHour());//小时:23
        System.out.println("分钟:"+nowDateTime.getMinute());//分钟:45
        System.out.println("秒:"+nowDateTime.getSecond());//秒:52
        System.out.println("纳秒:"+nowDateTime.getNano());//纳秒:145000000
    }
}
