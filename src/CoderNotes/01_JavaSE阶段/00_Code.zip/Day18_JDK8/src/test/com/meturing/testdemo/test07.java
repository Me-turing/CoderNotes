package com.meturing.testdemo;

import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class test07 {
    /**
     * 旧版日期时间的设计问题
     */
    @Test
    public void test01() throws ParseException {
        //设计不合理 有两个Date在不同的包
        //创建时间的时候与预期不符
        Date date = new Date(2022, 12, 18);
        System.out.println(date);//Thu Jan 18 00:00:00 CST 3923

        //时间格式化
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        System.out.println(simpleDateFormat.format(date));//3923-01-18

        System.out.println(simpleDateFormat.parse("2022-12-18"));//Sun Dec 18 00:00:00 CST 2022


        //线程安全性问题:在多线程的情况下 格式化和解析操作会出现报错和不准确的情况
        for (int i = 0; i < 50; i++) {
            new Thread(()->{
                try {
                    System.out.println(simpleDateFormat.parse("2022-12-18"));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }
}
