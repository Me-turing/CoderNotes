package com.meturing.testdemo;

import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class test09 {
    /**
     * 日期时间的修改
     */
    @Test
    public void test01(){
        LocalDateTime now = LocalDateTime.now();
        System.out.println("修改前:"+now);
        //修改时间  对已存在的LocalDate对象,创建了它的模板,并不会修改原有的信息,而是帮我们重新创建了对象
        LocalDateTime localDateTime = now.withYear(1998);
        System.out.println("修改后:"+now);
        System.out.println("修改后:"+localDateTime);

        System.out.println(now.withMonth(10));//月份
        System.out.println(now.withHour(10));//小时

        //在当前日期的基础上加上或者减去指定的时间
        System.out.println(now.plusDays(2));//两天后
        System.out.println(now.plusYears(10));//十年后
        System.out.println(now.minusWeeks(1));//一周前
        System.out.println(now.minusYears(10));//十年前
    }

    @Test
    public void test02(){
        LocalDate now = LocalDate.now();
        LocalDate date = LocalDate.of(1997, 11, 8);
        System.out.println(now.isAfter(date));//true  now是否在date之后
        System.out.println(now.isBefore(date));//false  now是否在date之前
        System.out.println(now.isEqual(date));//false  now与date一致
    }
}
