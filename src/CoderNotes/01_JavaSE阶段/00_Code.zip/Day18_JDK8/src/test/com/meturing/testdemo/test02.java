package com.meturing.testdemo;

import org.junit.Test;

import java.util.ArrayList;
import java.util.stream.Stream;

public class test02 {
    /**
     * 串行流
     */
    @Test
    public void test01(){
        Stream.of(1,2,3,4,5).filter(s->{
            System.out.println(Thread.currentThread()+"/"+s);
            return s>2;
        }).count();
    }

    /**
     * 获取并行流的两种方法
     */
    @Test
    public void test02(){
        ArrayList<Integer> list = new ArrayList<>();
        //通过List直接获取并行的流
        Stream<Integer> integerStream = list.parallelStream();

        //将已有的Stream流转换成并行流
        Stream<Integer> parallel = Stream.of(1, 2, 3, 4, 5).parallel();
    }
    /**
     * 并行流的操作
     */
    @Test
    public void test03(){
        //将已有的Stream流转换成并行流
        Stream<Integer> parallel = Stream.of(1, 2, 3, 4, 5).parallel();
        parallel.filter(s->{
            System.out.println(Thread.currentThread()+"/"+s);
            return s>2;
        }).count();
    }
}
