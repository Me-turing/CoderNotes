package com.meturing.testdemo;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.OptionalLong;
import java.util.stream.LongStream;

public class test03 {
    private static long times = 500000000;

    private long start;
    private long end;

    @Before
    public void before() {
        start = System.currentTimeMillis();
    }

    @After
    public void end() {
        end = System.currentTimeMillis();
        System.out.println("消耗时间:" + (end - start));
    }

    /**
     * 普通for循环
     * 消耗时间:125
     */
    @Test
    public void test01() {
        System.out.println("普通for循环:");
        long res = 0;
        for (long i = 0; i <= times; i++) {
            res += i;
        }
    }

    /**
     * 串行流
     * 消耗时间:217
     */
    @Test
    public void test02() {
        //rangeClosed 生成初始化的流
        System.out.println("串行流:");
        LongStream.rangeClosed(0, times).reduce(Long::sum);
    }

    /**
     * 并行流
     * 消耗时间:88
     */
    @Test
    public void test03() {
        System.out.println("并行流");
        LongStream.rangeClosed(0, times).parallel().reduce(Long::sum);
    }
}