package com.meturing.testdemo;




import com.meturing.stream.demo01.Student;
import org.junit.Test;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class test01 {
    /**
     * Stream结果收集到集合中
     */
    @Test
    public void test(){
        //转换成List
        List<String> collect1 = Stream.of("aa", "bb", "cc","aa")
                .collect(Collectors.toList());
        System.out.println(collect1);//[aa, bb, cc, aa]

        //转换成set
        Set<String> collect2 = Stream.of("aa", "bb", "cc","aa")
                .collect(Collectors.toSet());
        System.out.println(collect2);//[aa, bb, cc]

        //如果需要获取的类型为具体的实现,比如Arraylist hashset
        ArrayList<String> arr1=Stream.of("aa", "bb", "cc","aa")
                .collect(Collectors.toCollection(ArrayList::new));
        System.out.println(arr1);//[aa, bb, cc, aa]

        HashSet<String> arr2 = Stream.of("aa", "bb", "cc", "aa")
                .collect(Collectors.toCollection(HashSet::new));
        System.out.println(arr2);//[aa, bb, cc]
    }

    /**
     * Stream结果收集到集合中
     */
    @Test
    public void test02(){
        Object[] objects = Stream.of("aa", "bb", "cc", "aa").toArray();//返回的元素是object
        System.out.println(Arrays.toString(objects));//[aa, bb, cc, aa]

        String[] strings = Stream.of("aa", "bb", "cc", "aa").toArray(String[]::new);//指定返回的类型
        System.out.println(Arrays.toString(strings));//[aa, bb, cc, aa]
    }

    /**
     * Stream流数据聚合计算
     */
    @Test
    public void test03(){
        //获取年龄最大值
   /*     //之前的写法
        Integer integer = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22)
        ).map(Student::getAge).max((p1, p2) -> p1 - p2).get();
        System.out.println(integer);*/
        //使用collect
        //最大值
        Student student = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22)
        ).collect(Collectors.maxBy((p1, p2) -> p1.getAge() - p2.getAge())).get();
        System.out.println("年龄最大的是:"+student);//年龄最大的是:Student{name='王五', age=22}
        //最小值
        Student student1 = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22)
        ).collect(Collectors.minBy((p1, p2) -> p1.getAge() - p2.getAge())).get();
        System.out.println("年龄最小的是:"+student1);//年龄最小的是:Student{name='李四', age=11}
        //求和
        Integer collect = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22)
        ).collect(Collectors.summingInt(Student::getAge));
        System.out.println("年龄和:"+collect);//年龄和:52
        //平均值
        Double collect1 = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22)
        ).collect(Collectors.averagingDouble(Student::getAge));
        System.out.println("年龄平均值:"+collect1);//年龄平均值:17.333333333333332

        //数量
        Long collect2 = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22)
        ).collect(Collectors.counting());
        System.out.println("数量:"+collect2);//数量:3

    }

    /**
     * 分组计算
     */
    @Test
    public void test04(){
        //根据姓名分组
        Map<String, List<Student>> collect = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22),
                new Student("张三", 29)
        ).collect(Collectors.groupingBy(Student::getName));
//        {
//            李四=[Student{name='李四', age=11}],
//            张三=[Student{name='张三', age=19},
//                 Student{name='张三', age=29}],
//            王五=[Student{name='王五', age=22}]
//        }
        System.out.println(collect);

        //根据年龄分组
        Map<String, List<Student>> collect1 = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22),
                new Student("张三", 29)
        ).collect(Collectors.groupingBy(p -> {
            return p.getAge() >= 18 ? "成年" : "未成年";
        }));
//        {
//            未成年=[Student{name='李四', age=11}],
//            成年=[Student{name='张三', age=19},
//                Student{name='王五', age=22},
//                Student{name='张三', age=29}]
//        }
        System.out.println(collect1);
    }

    /**
     * 多级分组计算
     */
    @Test
    public void test05(){
        //根据姓名分组
        Map<String, Map<String, List<Student>>> collect = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22),
                new Student("张三", 29)
        ).collect(
                Collectors.groupingBy(
                        Student::getName,
                        Collectors.groupingBy(
                                p -> p.getAge() >= 18 ? "成年" : "未成年"
                        )
                )
        );
        System.out.println(collect);
//        {
//            李四={
//                    未成年=[Student{name='李四', age=11}]
//            },
//            张三={
//                    成年=[Student{name='张三', age=19}, Student{name='张三', age=29}]
//            },
//            王五={成年=[Student{name='王五', age=22}]}
//        }
    }

    /**
     * 分区操作
     */
    @Test
    public void test06(){
        Map<Boolean, List<Student>> collect = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22),
                new Student("张三", 29)
        ).collect(Collectors.partitioningBy(p -> p.getAge() > 18));
        System.out.println(collect);
//        {
//            false=[
//                    Student{name='李四', age=11}
//            ],
//            true=[
//                    Student{name='张三', age=19},
//                    Student{name='王五', age=22},
//                    Student{name='张三', age=29}
//            ]
//        }
    }

    /**
     * 拼接操作
     */
    @Test
    public void test07(){
        String collect = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22),
                new Student("张三", 29)
        ).map(Student::getName).collect(Collectors.joining());
        System.out.println(collect);//张三李四王五张三

        String collect1 = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22),
                new Student("张三", 29)
        ).map(Student::getName).collect(Collectors.joining(","));
        System.out.println(collect1);//张三,李四,王五,张三

        String collect2 = Stream.of(
                new Student("张三", 19),
                new Student("李四", 11),
                new Student("王五", 22),
                new Student("张三", 29)
        ).map(Student::getName).collect(Collectors.joining(",","[","]"));
        System.out.println(collect2);//[张三,李四,王五,张三]
    }
}
