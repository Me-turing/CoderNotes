package com.meturing.testdemo;

import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class test10 {
    /**
     * 日期格式化
     */
    @Test
    public void test01(){
        LocalDateTime now = LocalDateTime.now();
        //指定格式 使用系统默认的格式  2022-12-25T18:27:57.119
        DateTimeFormatter isoLocalDateTime = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        //将日期时间转换为字符串
        String format = now.format(isoLocalDateTime);
        System.out.println(format);

        //指定转换 ofPattern指定想要的日期格式  2022/12/25 18:27:57
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        String format1 = now.format(dateTimeFormatter);
        System.out.println(format1);

        //将字符串解析为指定时间类型  2022-12-25T18:27:57
        LocalDateTime parse = LocalDateTime.parse("2022/12/25 18:27:57", dateTimeFormatter);
        System.out.println(parse);
    }
}
