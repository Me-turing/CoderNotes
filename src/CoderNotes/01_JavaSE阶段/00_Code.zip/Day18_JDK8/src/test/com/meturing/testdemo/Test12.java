package com.meturing.testdemo;

import org.junit.Test;

import java.time.*;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;

public class Test12 {
    /**
     * 计算日期差
     */
    @Test
    public void test01() {
        //计算日期差
        LocalTime now = LocalTime.now();//18:52:37.225
        LocalTime time = LocalTime.of(22, 48, 59);
        //Duration计算时间差
        Duration between = Duration.between(now,time);
        System.out.println(between.toDays());//相差的天数  0
        System.out.println(between.toHours());//相差的小时  3
        System.out.println(between.toMinutes());//相差的分钟  236
        System.out.println(between.toMillis());//相差的秒  14181775
    }

    /**
     * 计算日期差
     */
    @Test
    public void test02() {
        //计算日期差
        LocalDate now = LocalDate.now();//2022-12-25
        LocalDate date = LocalDate.of(1997, 11, 8);
        Period period = Period.between(date, now);
        System.out.println(period.getYears());//相差年份 25
        System.out.println(period.getMonths());//相差月份 1
        System.out.println(period.getDays());//相差天数 17
    }

    /**
     * 时间校正器
     */
    @Test
    public void test03() {
        LocalDateTime now = LocalDateTime.now();
        System.out.println(now);//2022-12-25T19:17:38.134

        //将当前的日期调整到下个月的一号
        TemporalAdjuster temporalAdjuster = (temporal) -> {
            LocalDateTime localDateTime = (LocalDateTime) temporal;
            LocalDateTime nextMonth = localDateTime.plusMonths(1).withDayOfMonth(1);
            System.out.println("localDateTime:"+nextMonth);//localDateTime:2023-01-01T19:17:38.134
            return nextMonth;
        };

        LocalDateTime with = now.with(temporalAdjuster);
        System.out.println(with);//2023-01-01T19:17:38.134

        //我们还可以通过TemporalAdjusters 来实现
        LocalDateTime with1 = now.with(TemporalAdjusters.firstDayOfNextMonth());
        System.out.println(with1);//2023-01-01T19:21:20.301
    }
}
