package com.meturing.testdemo;

import org.junit.Test;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class test04 {
    /**
     * 并行流的数据安全问题
     */
    @Test
    public void test01(){
        ArrayList<Integer> arrays = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            arrays.add(i);
        }
        System.out.println(arrays.size());

        //将arrays结果通过异步添加到新数组
        ArrayList<Integer> arrayList = new ArrayList<>();
        Object o = new Object();
        arrays.parallelStream().forEach(s->{
            //同步代码块
            synchronized(o){
                arrayList.add(s);
            }
        });
        System.out.println(arrayList.size());
    }

    /**
     * 并行流的数据安全问题
     */
    @Test
    public void test02(){
        //将arrays结果通过异步添加到新数组
        ArrayList<Integer> arrayList = new ArrayList<>();
        Object o = new Object();
        IntStream.rangeClosed(1,1000)
                .parallel()
                .forEach(s->{
                        //同步代码块
                        synchronized(o){
                            arrayList.add(s);
                        }
                 });
        System.out.println(arrayList.size());
    }

    /**
     * 使用线程安全的容器
     */
    @Test
    public void test03(){
        Vector vector = new Vector();
        IntStream.rangeClosed(1,1000)
                .parallel()
                .forEach(vector::add);
        System.out.println(vector.size());
    }

    /**
     * 将线程不安全容器转换成线程安全容器
     */
    @Test
    public void test04(){
        //将arrays结果通过异步添加到新数组
        ArrayList<Integer> arrayList = new ArrayList<>();
        //将线程不安全容器转换成线程安全容器
        List<Integer> integers = Collections.synchronizedList(arrayList);
        IntStream.rangeClosed(1,1000)
                .parallel()
                .forEach(integers::add);
        System.out.println(arrayList.size());
    }

    /**
     * 我们还可以使用Stream流中的toArray方法或collect方法来操作
     * 满足线程安全的要求
     */
    @Test
    public void test05(){
        //将arrays结果通过异步添加到新数组
        List<Integer> arrayList = new ArrayList<>();
        arrayList = IntStream.rangeClosed(1, 1000)
                .parallel()
                .boxed()//boxed() 装箱操作,将intStream转换成 Integer类型
                .collect(Collectors.toList());
        System.out.println(arrayList.size());
    }
}
