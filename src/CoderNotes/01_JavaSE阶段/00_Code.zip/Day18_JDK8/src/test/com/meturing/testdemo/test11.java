package com.meturing.testdemo;

import org.junit.Test;

import java.time.Instant;

public class test11 {
    /**
     * 时间戳
     */
    @Test
    public void test01() throws InterruptedException {
        Instant now = Instant.now();
        System.out.println(now);//2022-12-25T10:36:09.565Z
        System.out.println(now.getNano());//获取从1970年1月1日 0时0分0秒 到现在的纳秒
        Thread.sleep(5);
        Instant now1 = Instant.now();
        System.out.println("耗时:"+(now1.getNano()-now.getNano()));
    }
}
