	function fun1(){
		alert("总能见到你")
	}
	function fun2(){
		alert("总能见到你")
	}