(function(root){
	//构造函数返回原型对象的初始方法
	var jQuery = function(){
		return new jQuery.prototype.init();
	}
	
	//原型对象
	jQuery.fn = jQuery.prototype = {
		init:function(){
			
		},
		css:function(){
			
		}
	}
	
	//共享原型
	jQuery.fn.init.prototype = jQuery.fn;
	
	//extend
	jQuery.fn.extend = jQuery.extend = function(){
		//获取用户输入的第一个参数,如果没有传默认为空对象
		var target = arguments[0]||{};
		//获取用户传过来的参数数量
		var length = arguments.length;
		
		var deep = false;//是否深拷贝
		var i = 1;//参数下标
		//option:第一个对象参数 name:拓展的参数 copy:正在复制的对象,src:需要拷贝到的数据,copyIsArray:拷贝数据是否是数组,clone:需要克隆到的数据
		var option,name,copy,src,copyIsArray,clone;
		
		//判断第一个参数的类型
		//如果第一个参数存,则需要进行参数偏移
		if(typeof target === "boolean"){
			deep = target; //第一个参数存储到deep
			target = arguments[1];//target修正为下标为2的
			i = 2;//拓展下标修改为第三个参数
		}
		//如果不是Object类型则修改为空的Object
		if(typeof target !== "object"){
			target = {};
		}
		//如果只有一个对象,则将当前对象赋值
		if(length===i){
			target = this;
			i--;
		}
		
		//浅拷贝
		//从第2个参数循环遍历参数到target对象中
		for(;i<length;i++){
			if((option = arguments[i]) != null){
				for(name in option){
					copy = option[name];//获取需要拷贝的数据
					src = target[name];//获取需要拷贝到的目标数据
					//判断是否进行深拷贝,以及参数必须是Object或者Array
					if(deep && (jQuery.isPlainObject(copy)||(copyIsArray = jQuery.isArray(copy)))){
						//深拷贝
						if(copyIsArray){//是否是数组类型
							copyIsArray = false;//重置标志
							clone = src && jQuery.isArray(src) ? src : [];//判断需要复制到的目标参数是否是数组类型,不是则修正为数组
						}else{
							clone = src && jQuery.isPlainObject(src) ? src : {};//判断需要复制到的目标参数是否是对象类型,不是则修正为对象
						}
						target[name] = jQuery.extend(deep,clone,copy);//进行拷贝
					}else{
						//浅拷贝
						if(copy != undefined){
							target[name] = copy;
						}
					}
				}
			}
		}
		return target;
	}
	
	jQuery.extend({
		 //类型检测
		 isPlainObject:function(obj){
			  return toString.call(obj) === "[object Object]";
		 },
		 isArray:function(obj){
			 return toString.call(obj) === "[object Array]";
		 }
	})
	root.$ = root.jQuery = jQuery;
})(this);