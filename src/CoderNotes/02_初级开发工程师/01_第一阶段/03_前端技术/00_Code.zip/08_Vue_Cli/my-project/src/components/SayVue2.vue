<template>
    <div>
        <h1>父组件的值:name :{{studentName}}/age :{{studentAge}}</h1>
    </div>
</template>
<script>
    export default{
         // 罗列父组件传进的属性值
        props:{
            studentName:{
               type:String,
               default:'李四',
               required: true
            },
            studentAge:{
                type:Number,
                required: true,
                validator: function(value){
                    return value>100;
                }
            },
            studenObj:{
                type: Object,
                default: ()=>{
                    return{
                        name:'王五',
                        age:10
                    }
                }
            }
            
        },
        data(){
            return{

            }
        }
    }
</script>
<style>

</style>