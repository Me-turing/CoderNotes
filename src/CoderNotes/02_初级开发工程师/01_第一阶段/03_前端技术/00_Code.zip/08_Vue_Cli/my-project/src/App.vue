<template>
  <div id="app">
    <HelloVue></HelloVue>
  </div>
</template>

<script>
// 引入组件
import HelloVue from './components/HelloVue.vue'

export default {
  //注册组件
  components: {
    HelloVue
  }
}
</script>

<style>

</style>
