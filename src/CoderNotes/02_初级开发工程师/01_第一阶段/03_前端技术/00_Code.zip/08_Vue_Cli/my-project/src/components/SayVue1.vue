<template>
    <div>
        <h1>父组件的值:number-a :{{numberA}}/number-b :{{numberB}}/number-c :{{numberC}}</h1>
    </div>
</template>
<script>
    export default{
         // 罗列父组件传进的属性值
        props:['numberA','numberB','numberC'],
        data(){
            return{

            }
        }
    }
</script>
<style>

</style>