<template>
    <div>
        <h1>父组件的值:{{fatherNumber}}</h1>
    </div>
</template>
<script>
    export default{
         // 罗列父组件传进的属性值
        props:['fatherNumber'],
        data(){
            return{

            }
        }
    }
</script>
<style>

</style>