<template>
    <div>
        <h1>父组件传递过来的值:{{fatherNumber}}</h1>
        <button @click="addNumber">+1</button>
    </div>
</template>
<script>
    export default {
        props:{
            fatherNumber:Number
        },
        data() {
            return {
                
            };
        },
        methods:{
            addNumber(){
                this.$emit("addNumber")
            }
        }
    }
</script>
<style>

</style>