<template>
    <div>
        <h1>{{number}}</h1>
        <button @click="add">+1</button>
        <sayVue :father-number='number'></sayVue>
        <sayVue1 :number-a='number' :number-b='number' :number-c='number'></SayVue1>
        <sayVue2 :student-name='zhangsan.name' :student-age='zhangsan.age'></sayVue2>
        <sayVue3 :father-number='number' @addNumber="add"></sayVue3>
    </div>
</template>
<script>
//引入组件
import sayVue from '../components/SayVue.vue'
import sayVue1 from '../components/SayVue1.vue'
import sayVue2 from '../components/SayVue2.vue'
import sayVue3 from '../components/SayVue3.vue'

    export default{
         //注册组件
        components: {
            sayVue,
            sayVue1,
            sayVue2,
            sayVue3
        },
        data(){
            return{
                number:100,
                zhangsan:{
                    name:'张三',
                    age:110
                }
            }
        },
        methods:{
            add(){
                this.number++;
            }
        }
    }
</script>
<style>

</style>