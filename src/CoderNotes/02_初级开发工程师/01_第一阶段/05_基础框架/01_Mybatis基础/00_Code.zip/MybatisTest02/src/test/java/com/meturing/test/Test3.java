package com.meturing.test;

import com.meturing.mapper.EmpMapper2;
import com.meturing.pojo.Emp;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

public class Test3 {

    private static SqlSession sqlSession = null;

    /**
     * 初始化
     *  Before注解会使方法在执行测试单元前执行
     * @author sqTan
     * @date 2023/04/09
     */
    @Before
    public void init() {
        //创建一个SqlSessionFactoryBuilder对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        InputStream resourceAsStream = null;
        try {
            //通过Resources类获取指定配置文件的InputStream流
            resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //通过SqlSessionFactoryBuilder对象使用配置文件的InputStream流构建一个SqlSessionFactory对象
        SqlSessionFactory build = sqlSessionFactoryBuilder.build(resourceAsStream);
        //使用SqlSessionFactory对象打开数据库链接
        sqlSession = build.openSession(true);
    }


    @Test
    public void findByCondition1(){
        EmpMapper2 mapper = sqlSession.getMapper(EmpMapper2.class);
        Emp emp = new Emp();
        emp.setEmpno(7499);
        List<Emp> empList = mapper.findByCondition1(emp);
        empList.stream().forEach(System.out::println);
    }

    @Test
    public void findByCondition2(){
        EmpMapper2 mapper = sqlSession.getMapper(EmpMapper2.class);
        Emp emp = new Emp();
        emp.setEmpno(7499);
        List<Emp> empList = mapper.findByCondition2(emp);
        empList.stream().forEach(System.out::println);
    }

    @Test
    public void findByCondition3(){
        EmpMapper2 mapper = sqlSession.getMapper(EmpMapper2.class);
        Emp emp = new Emp();
        emp.setEmpno(7499);
        emp.setEname("SMITH");
        List<Emp> empList = mapper.findByCondition3(emp);
        empList.stream().forEach(System.out::println);
    }

    @Test
    public void updateEmpByCondtion(){
        EmpMapper2 mapper = sqlSession.getMapper(EmpMapper2.class);
        Emp emp = new Emp();
        emp.setEmpno(8899);
        emp.setEname("LISI");
        emp.setMgr(1500);
        emp.setSal(1500.0);
        mapper.updateEmpByCondtion(emp);
    }

    @Test
    public void updateEmpByCondtion1(){
        EmpMapper2 mapper = sqlSession.getMapper(EmpMapper2.class);
        Emp emp = new Emp();
        emp.setEmpno(8899);
        emp.setEname("LISI");
        emp.setMgr(1500);
        emp.setSal(1500.0);
        mapper.updateEmpByCondtion1(emp);
    }

    @Test
    public void findObjectByName(){
        EmpMapper2 mapper = sqlSession.getMapper(EmpMapper2.class);
        List<Emp> empList = mapper.findObjectByName("a");
        empList.stream().forEach(System.out::println);
    }

    @Test
    public void findObject(){
        EmpMapper2 mapper = sqlSession.getMapper(EmpMapper2.class);
        List<Emp> empList = mapper.findObject();
        empList.stream().forEach(System.out::println);
    }

    @Test
    public void findObjectsByEmpNo1(){
        EmpMapper2 mapper = sqlSession.getMapper(EmpMapper2.class);
        int[] arr = new int[]{7369,7499,7521};
        List<Emp> empList = mapper.findObjectsByEmpNo1(arr);
        empList.stream().forEach(System.out::println);
    }

    @Test
    public void findObjectsByEmpNo2(){
        EmpMapper2 mapper = sqlSession.getMapper(EmpMapper2.class);
        List<Integer> integers = Arrays.asList(7369, 7499, 7521);
        List<Emp> empList = mapper.findObjectsByEmpNo2(integers);
        empList.stream().forEach(System.out::println);
    }

    /**
     * 释放
     * After注解会使方法在执行测试单元后执行
     * @author sqTan
     * @date 2023/04/09
     */
    @After
    public void release(){
        //关闭链接
        sqlSession.close();
    }
}
