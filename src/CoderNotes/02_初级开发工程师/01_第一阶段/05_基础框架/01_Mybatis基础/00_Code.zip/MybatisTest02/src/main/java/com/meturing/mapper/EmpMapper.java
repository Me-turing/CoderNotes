package com.meturing.mapper;
import com.meturing.pojo.Emp;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @author meturing
 * @description emp映射器
 * @date 2023/04/13
 */
public interface EmpMapper {

    /**
     * 找到所有
     *
     * @return {@link List }<{@link Emp }>
     * @author sqTan
     * @date 2023/04/13
     */
    List<Emp> findAll();

    /**
     * 通过Empno查找
     *
     * @param empno empno
     * @return {@link Emp }
     * @author sqTan
     * @date 2023/04/13
     */
    Emp findByEmpno(int empno);

    /**
     * 根据deptno和sal查找
     *
     * @param deptno deptno
     * @param sal   萨尔
     * @return {@link List }<{@link Emp }>
     * @author sqTan
     * @date 2023/04/13
     */
    List<Emp> findByDeptnoAndSal(@Param("deptno") int deptno, @Param("sal") double sal);


    /**
     * 根据deptno和sal查找
     *
     * @param map 地图
     * @return {@link List }<{@link Emp }>
     * @author sqTan
     * @date 2023/04/13
     */
    List<Emp> findMapByDeptnoAndSal(Map<String, Object> map);


    /**
     * 根据deptno和sal查找
     *
     * @param emp 电磁脉冲
     * @return {@link List }<{@link Emp }>
     * @author sqTan
     * @date 2023/04/13
     */
    List<Emp> findObjectByDeptnoAndSal1 (Emp emp);

    /**
     * 根据deptno和sal查找
     *
     * @param emp 电磁脉冲
     * @return {@link List }<{@link Emp }>
     * @author sqTan
     * @date 2023/04/13
     */
    List<Emp> findObjectByDeptnoAndSal2 (@Param("emp1") Emp emp1,@Param("emp2") Emp emp2);

    /**
     * 根据名字模糊查询
     *
     * @param ename ename
     * @return {@link Emp }
     * @author sqTan
     * @date 2023/04/14
     */
    List<Emp> findObjectByName(String ename);
}
