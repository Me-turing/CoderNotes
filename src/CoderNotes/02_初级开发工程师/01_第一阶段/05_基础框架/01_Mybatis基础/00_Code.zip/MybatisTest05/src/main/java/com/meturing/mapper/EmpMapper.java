package com.meturing.mapper;

import com.meturing.pojo.Emp;

import java.util.List;

public interface EmpMapper {
    List<Emp> findEmp(Integer deptno);
}