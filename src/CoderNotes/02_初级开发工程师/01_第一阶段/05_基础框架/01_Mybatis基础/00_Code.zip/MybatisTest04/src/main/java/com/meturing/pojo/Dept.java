package com.meturing.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data //所有参数构造Get/Set方法
@AllArgsConstructor //导入全参构造函数
@NoArgsConstructor //导入无参构造函数
public class Dept implements Serializable {
    private Integer deptno;
    private String dname;
    private String loc;

    private List<Emp> empList;
}
