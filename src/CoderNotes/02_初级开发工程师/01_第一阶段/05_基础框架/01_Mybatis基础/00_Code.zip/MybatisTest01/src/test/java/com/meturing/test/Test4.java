package com.meturing.test;

import com.meturing.pojo.Emp;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

public class Test4 {

    private static SqlSession sqlSession = null;

    /**
     * 初始化
     *  Before注解会使方法在执行测试单元前执行
     * @author sqTan
     * @date 2023/04/09
     */
    @Before
    public void init() {
        //创建一个SqlSessionFactoryBuilder对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        InputStream resourceAsStream = null;
        try {
            //通过Resources类获取指定配置文件的InputStream流
            resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //通过SqlSessionFactoryBuilder对象使用配置文件的InputStream流构建一个SqlSessionFactory对象
        SqlSessionFactory build = sqlSessionFactoryBuilder.build(resourceAsStream);
        //使用SqlSessionFactory对象打开数据库链接
        //sqlSession = build.openSession();//默认开启的是手动提交
        sqlSession = build.openSession(true);//开启自动提交
    }

    @Test
    public void testInsert(){
        Emp emp = new Emp(8899,"张三","SALESMAN",7839,new Date(),3100.0, 200.0,10 );
        sqlSession.insert("insertEmp", emp);
        //try {
        //    int insertEmp = sqlSession.insert("insertEmp", emp);
        //    sqlSession.commit();
        //} catch (Exception e) {
        //    sqlSession.rollback();
        //}
    }


    @Test
    public void testUpdate(){
        Emp emp = new Emp();
        emp.setEmpno(8899);
        emp.setEname("李四");
        sqlSession.insert("updateEmp", emp);
        //try {
        //    int insertEmp = sqlSession.insert("insertEmp", emp);
        //    sqlSession.commit();
        //} catch (Exception e) {
        //    sqlSession.rollback();
        //}
    }

    @Test
    public void testDelete(){
        sqlSession.delete("deleteEmp", 8899);
    }

    /**
     * 释放
     * After注解会使方法在执行测试单元后执行
     * @author sqTan
     * @date 2023/04/09
     */
    @After
    public void release(){
        //关闭链接
        sqlSession.close();
    }
}
