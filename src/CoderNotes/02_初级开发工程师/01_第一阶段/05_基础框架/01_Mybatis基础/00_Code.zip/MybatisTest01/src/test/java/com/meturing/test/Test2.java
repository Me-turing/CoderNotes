package com.meturing.test;

import com.meturing.pojo.Emp;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class Test2 {

    private static SqlSession sqlSession = null;

    /**
     * 初始化
     *  Before注解会使方法在执行测试单元前执行
     * @author sqTan
     * @date 2023/04/09
     */
    @Before
    public void init() {
        //创建一个SqlSessionFactoryBuilder对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        InputStream resourceAsStream = null;
        try {
            //通过Resources类获取指定配置文件的InputStream流
            resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //通过SqlSessionFactoryBuilder对象使用配置文件的InputStream流构建一个SqlSessionFactory对象
        SqlSessionFactory build = sqlSessionFactoryBuilder.build(resourceAsStream);
        //使用SqlSessionFactory对象打开数据库链接
        sqlSession = build.openSession();
    }

    @Test
    public void test1(){
        //执行查询方法
        List<Emp> deptList = sqlSession.selectList("empMapper.findAll");
        deptList.stream().forEach(System.out::println);
    }

    @Test
    public void test2(){
        //执行查询方法
        Emp emp = sqlSession.selectOne("findOne");
        System.out.println(emp);
    }

    @Test
    public void test3(){
        //执行查询方法
        Map<Object, Object> objectObjectMap = sqlSession.selectMap("findMap", "EMPNO");
        for (Map.Entry<Object, Object> objectObjectEntry : objectObjectMap.entrySet()) {
            System.out.println(objectObjectEntry.getKey()+":"+objectObjectEntry.getValue());
        }
    }

    /**
     * 释放
     * After注解会使方法在执行测试单元后执行
     * @author sqTan
     * @date 2023/04/09
     */
    @After
    public void release(){
        //关闭链接
        sqlSession.close();
    }
}
