package com.meturing.test;

import com.meturing.mapper.DeptMapper;
import com.meturing.mapper.EmpMapper;
import com.meturing.mapper.ProjectsMapper;
import com.meturing.pojo.Dept;
import com.meturing.pojo.Dept1;
import com.meturing.pojo.Emp;
import com.meturing.pojo.Projects;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class Test1 {

    private static SqlSession sqlSession = null;

    /**
     * 初始化
     *  Before注解会使方法在执行测试单元前执行
     * @author sqTan
     * @date 2023/04/09
     */
    @Before
    public void init() {
        //创建一个SqlSessionFactoryBuilder对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        InputStream resourceAsStream = null;
        try {
            //通过Resources类获取指定配置文件的InputStream流
            resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //通过SqlSessionFactoryBuilder对象使用配置文件的InputStream流构建一个SqlSessionFactory对象
        SqlSessionFactory build = sqlSessionFactoryBuilder.build(resourceAsStream);
        //使用SqlSessionFactory对象打开数据库链接
        sqlSession = build.openSession();
    }


    /**
     * 测试RequestMap手动映射
     *
     * @author sqTan
     * @date 2023/04/16
     */
    @Test
    public void findDepts(){
        DeptMapper deptMapper = sqlSession.getMapper(DeptMapper.class);
        List<Dept> deptList = deptMapper.findDepts();
        deptList.stream().forEach(System.out::println);
    }

    /**
     * 测试一对一关系
     *
     * @author sqTan
     * @date 2023/04/16
     */
    @Test
    public void  findEmpJoinDeptByEmpno(){
        EmpMapper empMapper = sqlSession.getMapper(EmpMapper.class);
        List<Emp> empList = empMapper.findEmpJoinDeptByEmpno("7499");
        empList.stream().forEach(System.out::println);
    }

    /**
     * 测试一对多关系
     *
     * @author sqTan
     * @date 2023/04/16
     */
    @Test
    public void  findDeptLeftEmp(){
        DeptMapper mapper = sqlSession.getMapper(DeptMapper.class);
        List<Dept1> dept1s = mapper.findDeptLeftEmp(20);
        dept1s.stream().forEach(System.out::println);
    }

    /**
     * 测试一对多关系
     *
     * @author sqTan
     * @date 2023/04/16
     */
    @Test
    public void  findProjectsInfo(){
        ProjectsMapper mapper = sqlSession.getMapper(ProjectsMapper.class);
        List<Projects> dept1s = mapper.findProjectsInfo(2);
        dept1s.stream().forEach(System.out::println);
    }

    /**
     * 释放
     * After注解会使方法在执行测试单元后执行
     * @author sqTan
     * @date 2023/04/09
     */
    @After
    public void release(){
        //关闭链接
        sqlSession.close();
    }
}
