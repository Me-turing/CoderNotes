package com.meturing.mapper;

import com.meturing.pojo.Projects;

import java.util.List;

public interface ProjectsMapper {

    List<Projects> findProjectsInfo(Integer pid);
}
