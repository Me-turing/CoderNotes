package com.meturing.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 登录
 * @author sqTan
 * @description servlet7
 * @date 2023/03/20
 */
public class Servlet7 extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userName = req.getParameter("userName");
        String userPwd = req.getParameter("userPwd");

        if ("admin".equals(userName)&&"root".equals(userPwd)){
            //创建用户对象
            User user = new User(userName, userPwd);
            HttpSession session = req.getSession();
            //存储到Session
            session.setAttribute("user",user);
            //跳转到成功页面
            resp.sendRedirect(req.getContextPath() + "/MainServlet.do");
        }else {
            resp.sendRedirect(req.getContextPath() + "/login.html");
        }
    }
}
