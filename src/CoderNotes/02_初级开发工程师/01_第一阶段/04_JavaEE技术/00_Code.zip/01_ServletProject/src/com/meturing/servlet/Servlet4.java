package com.meturing.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;

/**
 * 当客户端浏览器第一次访问Servlet时返回“您好，欢迎您第一次访问！”
 * 第二次访问时返回“欢迎您回来！”
 */
public class Servlet4 extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String strMessage = "";
        //尝试获取Cookie中的计数器
        Cookie[] cookies = req.getCookies();
        Cookie count = null;
        //如果Cookie不为空切计数器不为0 表示重复访问 计数器++
        if (cookies!=null){
            Integer integerCount = 0;
            for (Cookie cookie : cookies) {
               if ("count".equals(cookie.getName())){
                   integerCount = Integer.valueOf(cookie.getValue());
                   integerCount++;
                   cookie.setValue(integerCount.toString());
                   count = cookie;
                   strMessage = "欢迎您回来！这是您第"+integerCount+"次访问！";
               }
            }
            //如果For循环走还没有取到计数器
            if (integerCount==0){
                count = new Cookie("count", "1");
                strMessage = "您好，欢迎您第1次访问！";
            }
        }else{
            //如果计数器为0或者Cookie为空则表明初次访问 需要颁发Cookie 计数器++
            count = new Cookie("count", "1");
            strMessage = "您好，欢迎您第1次访问！";
        }
        //设置响应头,以便浏览器知道以何种编码解析数据
        resp.setContentType("text/html;charset=UTF-8");
        if (count!=null){
            resp.addCookie(count);
        }
        resp.getWriter().write(strMessage);
    }
}
