package com.meturing.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 向Session中写入
 * @author sqTan
 * @description servlet5
 * @date 2023/03/20
 */
public class Servlet5 extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取当前的Session对象
        HttpSession session = req.getSession();
        //向Session中写入数据
        session.setAttribute("userName","admin");
        session.setAttribute("passWord","1234");
        session.setAttribute("level","A");

        //session.invalidate(); //手动使Session失效
    }
}
