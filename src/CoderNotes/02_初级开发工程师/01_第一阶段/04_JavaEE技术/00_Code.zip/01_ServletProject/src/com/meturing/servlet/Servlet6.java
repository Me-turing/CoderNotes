package com.meturing.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 获取Session中的数据
 * @author sqTan
 * @description servlet6
 * @date 2023/03/20
 */
public class Servlet6 extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        //获取Session
        String userName = (String) session.getAttribute("userName");
        String passWord = (String) session.getAttribute("passWord");
        String level = (String) session.getAttribute("level");
        System.out.println(userName);
        System.out.println(passWord);
        System.out.println(level);

        //获取Session对象的其他属性
        System.out.println("创建时间: "+session.getCreationTime());
        System.out.println("最后一次访问时间: "+session.getLastAccessedTime());
        System.out.println("最大不活动时间: "+session.getMaxInactiveInterval());
    }
}
