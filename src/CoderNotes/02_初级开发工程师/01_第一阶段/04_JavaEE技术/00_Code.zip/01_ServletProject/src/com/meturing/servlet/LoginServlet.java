package com.meturing.servlet;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        String sUsername = req.getParameter("username");
        String sPwd = req.getParameter("pwd");
        String message = null;
        if ("admin".equals(sUsername)&&"admin".equals(sPwd)){
            message="Success";
        }else {
            message="Fail";
        }
        res.getWriter().write(message);
    }
}
