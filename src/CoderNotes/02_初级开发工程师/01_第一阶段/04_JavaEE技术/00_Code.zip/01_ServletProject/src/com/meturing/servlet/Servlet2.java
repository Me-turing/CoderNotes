package com.meturing.servlet;



import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.StyledEditorKit;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;

public class Servlet2 extends HttpServlet {
    @Override
    public void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Cookie age = new Cookie("age", "10");
        Cookie sex = new Cookie("sex", "男");
        String encodeName = URLEncoder.encode("张三", "UTF-8");//对中文进行编码
        Cookie name = new Cookie("name", encodeName);
        name.setMaxAge(60);//秒钟    持久化Cookie 让浏览器保留1分钟
        resp.addCookie(name);
        resp.addCookie(sex);
        resp.addCookie(age);
    }
}
