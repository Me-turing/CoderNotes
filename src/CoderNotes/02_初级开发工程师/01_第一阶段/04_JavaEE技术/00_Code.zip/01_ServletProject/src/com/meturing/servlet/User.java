package com.meturing.servlet;

public class User {
    private String sName;
    private String sPassword;

    public User() {
    }

    public User(String sName, String sPassword) {
        this.sName = sName;
        this.sPassword = sPassword;
    }

    public String getsName() {
        return sName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public String getsPassword() {
        return sPassword;
    }

    public void setsPassword(String sPassword) {
        this.sPassword = sPassword;
    }

    @Override
    public String toString() {
        return "User{" +
                "sName='" + sName + '\'' +
                ", sPassword='" + sPassword + '\'' +
                '}';
    }
}
