package com.meturing.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class MyServlet extends HttpServlet {
    /**
     * 重写service
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 动态生成数据
        int num = new Random().nextInt();
        String message  =  num%2==0?"happy birthday":"happy new year";
        // 对浏览器作出响应
        PrintWriter writer = resp.getWriter();
        writer.write(message);
    }
}
