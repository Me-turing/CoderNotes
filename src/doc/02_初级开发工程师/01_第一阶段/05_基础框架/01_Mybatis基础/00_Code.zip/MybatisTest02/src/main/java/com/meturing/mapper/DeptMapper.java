package com.meturing.mapper;


import com.meturing.pojo.Dept;

/**
 * @author meturing
 * @description emp映射器
 * @date 2023/04/13
 */
public interface DeptMapper {


    /**
     * 新增数据
     *
     * @param dept 部门
     * @return int
     * @author sqTan
     * @date 2023/04/14
     */
    int insterDept(Dept dept);

    /**
     * 删除部门
     *
     * @param deptNo 部门没有
     * @return int
     * @author sqTan
     * @date 2023/04/14
     */
    int deleteDept(int deptNo);

    /**
     * 更新部门
     *
     * @param dept 部门
     * @return int
     * @author sqTan
     * @date 2023/04/14
     */
    int updateDept(Dept dept);

    /**
     * 发现部门通过id
     *
     * @param deptId 部门id
     * @return {@link Dept }
     * @author sqTan
     * @date 2023/04/14
     */
    Dept findDeptById(int deptId);
}
