package com.meturing.mapper;

import com.meturing.pojo.Emp;

import java.util.ArrayList;
import java.util.List;

/**
 * @author meturing
 * @description emp映射器
 * @date 2023/04/13
 */
public interface EmpMapper2 {

    /**
     * 找到条件
     *
     * @param emp 电磁脉冲
     * @return {@link List }<{@link Emp }>
     * @author sqTan
     * @date 2023/04/14
     */
    List<Emp> findByCondition1(Emp emp);

    List<Emp> findByCondition2(Emp emp);

    List<Emp> findByCondition3(Emp emp);

    int updateEmpByCondtion(Emp emp);

    int updateEmpByCondtion1(Emp emp);

    List<Emp> findObjectByName(String ename);

    List<Emp> findObject();

    List<Emp> findObjectsByEmpNo1(int[] empno);

    List<Emp> findObjectsByEmpNo2(List<Integer> empno);
}
