package com.meturing.mapper;

import com.meturing.pojo.Dept;

public interface DeptMapper {
    Dept findeDept(Integer deptno);
}
