package com.meturing.test;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.meturing.mapper.StudentMapper;
import com.meturing.pojo.Student;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class Test01 {

    private static SqlSession sqlSession = null;

    /**
     * 初始化
     *  Before注解会使方法在执行测试单元前执行
     * @author sqTan
     * @date 2023/04/09
     */
    @Before
    public void init() {
        //创建一个SqlSessionFactoryBuilder对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        InputStream resourceAsStream = null;
        try {
            //通过Resources类获取指定配置文件的InputStream流
            resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //通过SqlSessionFactoryBuilder对象使用配置文件的InputStream流构建一个SqlSessionFactory对象
        SqlSessionFactory build = sqlSessionFactoryBuilder.build(resourceAsStream);
        //使用SqlSessionFactory对象打开数据库链接
        sqlSession = build.openSession();
    }

    @Test
    public void Testcache1(){
        StudentMapper mapper = sqlSession.getMapper(StudentMapper.class);
        List<Student> emp = mapper.findeAllStudent();
        sqlSession.commit();
        for (int i = 0; i < emp.size(); i++) {
            System.out.println("第["+(i+1)+"]个学生:"+emp.get(i));
        }
    }

    @Test
    public void Testcache2(){
        StudentMapper mapper = sqlSession.getMapper(StudentMapper.class);
        Page<Student> studentPage = PageHelper.startPage(1, 5);
        List<Student> emp = mapper.findeAllStudent();
        sqlSession.commit();
        System.out.println(studentPage.getResult());//获取执行结果
        System.out.println("当前页码:"+studentPage.getPageNum());//获取当前页码
        System.out.println("每页数据的数量:"+studentPage.getPageSize());//获取当前页码
        System.out.println("始页首行行号:"+studentPage.getStartRow());//始页首行行号
        System.out.println("尾页尾行行号:"+studentPage.getEndRow());//尾页尾行行号
        System.out.println("总记录数:"+studentPage.getTotal());//总记录数
        System.out.println("总页数:"+studentPage.getPages());//总页数

        for (int i = 0; i < studentPage.getResult().size(); i++) {
            System.out.println("第["+(i+1)+"]个学生:"+studentPage.getResult().get(i));
        }
    }

    @Test
    public void Testcache3(){
        StudentMapper mapper = sqlSession.getMapper(StudentMapper.class);
        PageHelper.startPage(1, 5);
        List<Student> emp = mapper.findeAllStudent();
        sqlSession.commit();
        PageInfo<Student> studentPageInfo = new PageInfo<>(emp);
        System.out.println("当前页"+studentPageInfo.getPageNum());       //当前页
        System.out.println("每页显示数据条数"+studentPageInfo.getPageSize());      //每页显示数据条数
        System.out.println("当前页的数量"+studentPageInfo.getSize());          //当前页的数量
        System.out.println("始页首行行号"+studentPageInfo.getStartRow());      //始页首行行号
        System.out.println("尾页尾行行号"+studentPageInfo.getEndRow());        //尾页尾行行号
        System.out.println("总记录数"+studentPageInfo.getTotal());         //总记录数
        System.out.println("总页数"+studentPageInfo.getPages());         //总页数
        System.out.println("查询结果的数据"+studentPageInfo.getList());			//查询结果的数据
        System.out.println("首页"+studentPageInfo.getFirstPage());     //首页
        System.out.println("上一页"+studentPageInfo.getPrePage());       //上一页
        System.out.println("下一页"+studentPageInfo.getNextPage());      // 下一页

        for (int i = 0; i < studentPageInfo.getList().size(); i++) {
            System.out.println("第["+(i+1)+"]个学生:"+studentPageInfo.getList().get(i));
        }
    }

    /**
     * 释放
     * After注解会使方法在执行测试单元后执行
     * @author sqTan
     * @date 2023/04/09
     */
    @After
    public void release(){
        //关闭链接
        sqlSession.close();
    }
}
