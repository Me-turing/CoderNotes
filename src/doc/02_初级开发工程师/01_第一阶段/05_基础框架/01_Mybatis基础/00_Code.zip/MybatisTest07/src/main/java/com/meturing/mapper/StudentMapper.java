package com.meturing.mapper;

import com.meturing.pojo.Student;

import java.util.List;

public interface StudentMapper {
    List<Student> findeAllStudent();
}
