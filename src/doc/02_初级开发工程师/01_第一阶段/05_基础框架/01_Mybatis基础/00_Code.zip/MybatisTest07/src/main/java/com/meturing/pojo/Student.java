package com.meturing.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data //所有参数构造Get/Set方法
@AllArgsConstructor //导入全参构造函数
@NoArgsConstructor //导入无参构造函数
public class Student implements Serializable {
    private Integer stuId;
    private String stuName;
    private Integer stuAge;
    private String stuGender;
    private String fileName;
    private String fileType;
}
