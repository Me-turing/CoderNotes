package com.meturing.mapper;


import com.meturing.pojo.Dept;
import com.meturing.pojo.Dept1;

import java.util.List;

/**
 * @author meturing
 * @description emp映射器
 * @date 2023/04/13
 */
public interface DeptMapper {

    List<Dept> findDepts();

    List<Dept1> findDeptLeftEmp(Integer deptno);
}
