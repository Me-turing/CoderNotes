package com.meturing.mapper;

import com.meturing.pojo.Emp;

import java.util.List;

/**
 * @author meturing
 * @description emp映射器
 * @date 2023/04/13
 */
public interface EmpMapper {

    List<Emp> findEmpJoinDeptByEmpno(String empno);
}
