package com.meturing.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Projectrecord implements Serializable {
 private Integer empno;
 private Integer pid;
 private Emp emp;
}
