package com.meturing.test;

import com.meturing.mapper.DeptMapper;
import com.meturing.pojo.Dept;
import com.meturing.pojo.DeptExample;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class Test01 {
    private static SqlSession sqlSession = null;

    /**
     * 初始化
     *  Before注解会使方法在执行测试单元前执行
     * @author sqTan
     * @date 2023/04/09
     */
    @Before
    public void init() {
        //创建一个SqlSessionFactoryBuilder对象
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        InputStream resourceAsStream = null;
        try {
            //通过Resources类获取指定配置文件的InputStream流
            resourceAsStream = Resources.getResourceAsStream("sqlMapConfig.xml");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //通过SqlSessionFactoryBuilder对象使用配置文件的InputStream流构建一个SqlSessionFactory对象
        SqlSessionFactory build = sqlSessionFactoryBuilder.build(resourceAsStream);
        //使用SqlSessionFactory对象打开数据库链接
        sqlSession = build.openSession();
    }
    @Test
    public void tetsQBC(){
        //目标:组装查询条件 where (xxx) or (xxx)
        //1. 创建Example对象
        DeptExample example = new DeptExample();

        //2. Example对象创建Criteria对象
        DeptExample.Criteria criteria01 = example.createCriteria();
        DeptExample.Criteria criteria02 = example.or();

        //3. 在Criteria对象添加查询条件
        // 封装的第一个 dname like '%S%'
        criteria01.andDnameLike("%S%");

        // 封装的第二个 Deptno >= 20
        criteria02.andDeptnoGreaterThan(20);

        //4.根据 Example对象执行查询
        // select * from Dept WHERE
        // ( dname like '%S%' ) or ( Deptno >= 20)
        DeptMapper mapper = sqlSession.getMapper(DeptMapper.class);
        List<Dept> deptList = mapper.selectByExample(example);
        deptList.stream().forEach(System.out::println);
    }

    /**
     * 释放
     * After注解会使方法在执行测试单元后执行
     * @author sqTan
     * @date 2023/04/09
     */
    @After
    public void release(){
        //关闭链接
        //sqlSession.close();
    }
}
