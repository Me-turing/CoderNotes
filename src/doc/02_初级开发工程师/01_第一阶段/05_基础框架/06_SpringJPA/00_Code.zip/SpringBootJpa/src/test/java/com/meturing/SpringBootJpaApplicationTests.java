package com.meturing;

import com.meturing.dao.StudentDao;
import com.meturing.pojo.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class SpringBootJpaApplicationTests {
	@Autowired
	private StudentDao studentDao;

	@Test
	void contextLoads() {
		List<Student> studentList = studentDao.findAll();
		studentList.forEach(System.out::println);
	}
}
