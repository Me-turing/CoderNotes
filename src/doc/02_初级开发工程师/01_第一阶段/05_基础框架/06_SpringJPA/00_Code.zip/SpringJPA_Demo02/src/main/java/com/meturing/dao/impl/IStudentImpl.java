package com.meturing.dao.impl;

import com.meturing.dao.IStudent;
import com.meturing.pojo.Student;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class IStudentImpl implements IStudent {

    @PersistenceContext(name = "entityManagerFactory")
    private EntityManager manager;

    @Override
    public void insertStudent(Student student) {
        manager.persist(student);
    }

    @Override
    public void updateStudent(Student student) {
        manager.merge(student);
    }

    @Override
    public void deleteStudent(Student student) {
        manager.remove(student);
    }

    @Override
    public Student selectStudentById(Integer studentId) {
        return manager.find(Student.class,studentId);
    }

    @Override
    public List<Student> selectStudentByName(String studentName) {
        List studentList = manager.createQuery(" from Student where stuName = :stuName")
                .setParameter("stuName", studentName)
                .getResultList();
        return studentList;
    }

    @Override
    public List<Student> selectStudentByNameUseSQL(String studentName) {
        List studentList = manager.createNativeQuery("select * from student where stuname = ?", Student.class)
                .setParameter(1, studentName)
                .getResultList();
        return studentList;
    }

    @Override
    public List<Student> selectStudentByNameUseCriteria(String studentName) {
        //获取条件构造器
        CriteriaBuilder criteriaBuilder = manager.getCriteriaBuilder();
        CriteriaQuery<Student> query = criteriaBuilder.createQuery(Student.class);
        Root<Student> from = query.from(Student.class);
        Predicate stuName = criteriaBuilder.equal(from.get("stuName"), studentName);
        query.where(stuName);

        //根据条件构造器查询
        List<Student> studentList = manager.createQuery(query).getResultList();
        return studentList;
    }
}
