package com.meturing.text;

import com.meturing.dao.IStudent;
import com.meturing.pojo.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class TestDemo01 {
    @Autowired
    private IStudent iStudent;

    @Test
    @Transactional
    @Rollback(false)
    public void testInsertStudent(){
        Student zhaoliu = new Student(null, "zhaoliu", 18, 10, "", "");
        iStudent.insertStudent(zhaoliu);
    }

    @Test
    @Transactional
    @Rollback(false)
    public void testUpdateStudent(){
        Student zhaoliu = new Student(37, "zhaoliu", 20, 10, "11", "22");
        iStudent.updateStudent(zhaoliu);
    }

    @Test
    @Transactional
    @Rollback(false)
    public void testDeleteStudent(){
        Student zhaoliu = new Student(37, "zhaoliu", 20, 10, "11", "22");
        iStudent.deleteStudent(zhaoliu);
    }

    @Test
    @Transactional
    public void testSelectStudentById(){
        Student student = iStudent.selectStudentById(1);
        System.out.println(student);
    }

    @Test
    @Transactional
    public void testSelectStudentByName(){
        List<Student> studentList = iStudent.selectStudentByName("name1");
        for (Student student : studentList) {
            System.out.println(student);
        }
    }

    @Test
    @Transactional
    public void testSelectStudentByNameUseSQL(){
        List<Student> studentList = iStudent.selectStudentByNameUseSQL("name1");
        for (Student student : studentList) {
            System.out.println(student);
        }
    }

    @Test
    @Transactional
    public void testSelectStudentByNameUseCriteria(){
        List<Student> studentList = iStudent.selectStudentByNameUseCriteria("name1");
        for (Student student : studentList) {
            System.out.println(student);
        }
    }

}
