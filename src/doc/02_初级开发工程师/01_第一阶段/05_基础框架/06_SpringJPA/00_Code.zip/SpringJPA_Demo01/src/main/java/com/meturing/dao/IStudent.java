package com.meturing.dao;

import com.meturing.pojo.Student;

import java.util.List;

public interface IStudent {

    void insertStudent(Student student);

    void updateStudent(Student student);

    void deleteStudent(Student student);

    Student selectStudentById(Integer studentId);

    List<Student> selectStudentByName(String studentName);

    List<Student> selectStudentByNameUseSQL(String studentName);

    List<Student> selectStudentByNameUseCriteria(String studentName);
}
