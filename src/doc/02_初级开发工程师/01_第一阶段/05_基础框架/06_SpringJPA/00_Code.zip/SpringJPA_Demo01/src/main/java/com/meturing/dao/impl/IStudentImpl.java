package com.meturing.dao.impl;

import com.meturing.dao.IStudent;
import com.meturing.pojo.Student;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class IStudentImpl implements IStudent {
    @Autowired
    private HibernateTemplate hibernateTemplate;

    /*插入数据*/
    @Override
    public void insertStudent(Student student) {
        hibernateTemplate.save(student);
    }

    /*更新数据*/
    @Override
    public void updateStudent(Student student) {
        hibernateTemplate.update(student);
    }

    /*删除数据*/
    @Override
    public void deleteStudent(Student student) {
        hibernateTemplate.delete(student);
    }

    /*根据主键查询数据*/
    @Override
    public Student selectStudentById(Integer studentId) {
        return hibernateTemplate.get(Student.class,studentId);
    }

    /*根据用户姓名获取数据*/
    @Override
    public List<Student> selectStudentByName(String studentName) {
        Session currentSession = hibernateTemplate.getSessionFactory().getCurrentSession();
        Query studentQuery = currentSession.createQuery(" from Student where stuname = :stuName").setString("stuName", studentName);
        return studentQuery.list();
    }

    /*手动执行SQL查询*/
    @Override
    public List<Student> selectStudentByNameUseSQL(String studentName) {
        Session currentSession = hibernateTemplate.getSessionFactory().getCurrentSession();
        Query studentQuery = currentSession.createSQLQuery("select * from student where stuname = ?")
                .addEntity(Student.class)
                .setString(0, studentName);
        return studentQuery.list();
    }

    /*使用条件比较器查询*/
    @Override
    public List<Student> selectStudentByNameUseCriteria(String studentName) {
        Session currentSession = hibernateTemplate.getSessionFactory().getCurrentSession();
        Criteria studenCriteria = currentSession.createCriteria(Student.class)
                .add(Restrictions.eq("stuName", studentName));
        return studenCriteria.list();
    }
}
