package com.meturing.test;

import com.meturing.dao.StudentDao;
import com.meturing.pojo.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class TestDemo01 {
    @Autowired
    private StudentDao studentDao;

    @Test
    @Transactional
    @Rollback(false)
    public void query1(){
        Student student = new Student(null, "王五", 18, 11, "", "");
        studentDao.save(student);
    }

}
