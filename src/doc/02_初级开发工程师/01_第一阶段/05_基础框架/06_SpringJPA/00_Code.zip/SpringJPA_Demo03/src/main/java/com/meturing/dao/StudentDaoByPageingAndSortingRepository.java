package com.meturing.dao;

import com.meturing.pojo.Student;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface StudentDaoByPageingAndSortingRepository extends PagingAndSortingRepository<Student,Integer> {
}
