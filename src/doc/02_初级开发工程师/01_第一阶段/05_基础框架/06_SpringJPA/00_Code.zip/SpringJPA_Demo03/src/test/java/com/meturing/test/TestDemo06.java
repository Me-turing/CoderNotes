package com.meturing.test;

import com.meturing.dao.StudentDaoByCrudRepository;
import com.meturing.pojo.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class TestDemo06 {
    @Autowired
    private StudentDaoByCrudRepository studentDaoByCrudRepository;

    /**
     * 添加数据
     */
    @Test
    public void test1(){
        Student student = new Student();
        student.setStuName("成龙");
        student.setStuAge(18);
        studentDaoByCrudRepository.save(student);
    }

    /**
     * 批量添加数据
     */
    @Test
    public void test2(){
        List<Student> list = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Student student = new Student();
            student.setStuName("成龙"+i);
            student.setStuAge(18);
            list.add(student);
        }
        studentDaoByCrudRepository.save(list);
    }

    /**
     * 查询单条数据
     */
    @Test
    public void test3(){
        Student student = studentDaoByCrudRepository.findOne(1);
        System.out.println(student);
    }

    /**
     * 查询所有的数据
     */
    @Test
    public void test4(){
        Iterable<Student> studentList = studentDaoByCrudRepository.findAll();
        studentList.forEach(System.out::println);
    }

    /**
     * 删除数据
     */
    @Test
    public void delete1(){
        studentDaoByCrudRepository.delete(32);
    }

    /**
     * 更新数据
     */
    @Test
    public void update1(){
        // 根据save方法来实现 如果Users对象的userId属性不为空则update
        Student student = studentDaoByCrudRepository.findOne(34);
        student.setStuName("成龙666");
        studentDaoByCrudRepository.save(student);
    }

    /**
     * 更新数据 方式二
     */
    @Test
    @Transactional
    @Rollback(false)
    public void update2(){
        Student student = studentDaoByCrudRepository.findOne(38);
        student.setStuName("成龙666");
    }
}
