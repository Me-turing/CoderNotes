package com.meturing.test;

import com.meturing.dao.StudentDaoByPageingAndSortingRepository;
import com.meturing.pojo.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class TestDemo07 {

    @Autowired
    private StudentDaoByPageingAndSortingRepository peopleDaoByPageingAndSortingRepository;

    @Test
    public void testDemo01(){
        int page = 1; // page:当前分页的索引  从0开始
        int size = 3; // size:每页显示的条数
        PageRequest pageRequest = new PageRequest(page, size);
        Page<Student> pageObject = peopleDaoByPageingAndSortingRepository.findAll(pageRequest);
        System.out.println("总的条数:" + pageObject.getTotalElements());
        System.out.println("总的页数:" + pageObject.getTotalPages());
        List<Student> studentList = pageObject.getContent();
        studentList.forEach(System.out::println);
    }

    @Test
    public void testDemo02(){
        Sort sortById = new Sort(Sort.Direction.DESC, "stuId");
        Iterable<Student> studentList = peopleDaoByPageingAndSortingRepository.findAll(sortById);
        studentList.forEach(System.out::println);
    }
}
