package com.meturing.dao;

import com.meturing.pojo.Student;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import java.util.List;

public interface StudentDaoByRepository01 extends Repository<Student, Integer> {
    @Query("from Student where stuName = ?")
    Student selectByStuName(String name);
    @Query("from Student where stuName like ?")
    List<Student> selectByStuNameLike(String name);

    @Query("from Student where  stuAge > ?")
    List<Student> selectByStuAge(Integer stuAge);

    @Query("from Student where  stuName like ? and stuAge > ?")
    List<Student> findByStuNameAndStuAge(String name,Integer stuAge);
}
