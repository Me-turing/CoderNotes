package com.meturing.test;

import com.meturing.dao.StudentDaoJpaSpecificationExecutor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class TestDemo08 {

    @Autowired
    private StudentDaoJpaSpecificationExecutor studentDaoJpaSpecificationExecutor;

    /**
     * 单一结果查询
     */
    @Test
    public void testDemo01(){
        Specification specification = new Specification() {
            /**
             * 定义查询条件
             * @param root 根对象  封装查询条件的对象
             * @param criteriaQuery 基本的查询
             * @param criteriaBuilder 创建查询条件
             * @return
             */
            @Override
            public Predicate toPredicate(Root root, CriteriaQuery criteriaQuery, CriteriaBuilder criteriaBuilder) {
                Predicate equal = criteriaBuilder.equal(root.get("stuName"), "张三");
                return equal;
            }
        };
        List studentsList = studentDaoJpaSpecificationExecutor.findAll(specification);
        studentsList.forEach(System.out::println);
    }

    @Test
    public void testDemo02(){
        Specification specification = new Specification() {
            /**
             * 定义查询条件
             * @param root 根对象  封装查询条件的对象
             * @param criteriaQuery 基本的查询
             * @param criteriaBuilder 创建查询条件
             * @return
             */
            @Override
            public Predicate toPredicate(Root root, CriteriaQuery criteriaQuery, CriteriaBuilder criteriaBuilder) {
                ArrayList<Predicate> predicates = new ArrayList<>();
                predicates.add(criteriaBuilder.equal(root.get("stuName"),"张三"));
                predicates.add(criteriaBuilder.equal(root.get("stuAge"),18));
                Predicate[] predicate = new Predicate[predicates.size()];
                return criteriaBuilder.and(predicates.toArray(predicate));
            }
        };
        List studentsList = studentDaoJpaSpecificationExecutor.findAll(specification);
        studentsList.forEach(System.out::println);
    }


    @Test
    public void testDemo03(){
        Specification specification = new Specification() {
            /**
             * 定义查询条件
             * @param root 根对象  封装查询条件的对象
             * @param criteriaQuery 基本的查询
             * @param criteriaBuilder 创建查询条件
             * @return
             */
            @Override
            public Predicate toPredicate(Root root, CriteriaQuery criteriaQuery, CriteriaBuilder criteriaBuilder) {
                return criteriaBuilder.equal(root.get("stuName"),"zhangsan");
            }
        };
        PageRequest pageRequest = new PageRequest(0, 3);
        Page pageInfo = studentDaoJpaSpecificationExecutor.findAll(specification, pageRequest);
        System.out.println(pageInfo.getTotalElements());
        System.out.println(pageInfo.getTotalPages());
        List content = pageInfo.getContent();
        System.out.println(content);
    }

    @Test
    public void testDemo04(){
        Specification specification = new Specification() {
            /**
             * 定义查询条件
             * @param root 根对象  封装查询条件的对象
             * @param criteriaQuery 基本的查询
             * @param criteriaBuilder 创建查询条件
             * @return
             */
            @Override
            public Predicate toPredicate(Root root, CriteriaQuery criteriaQuery, CriteriaBuilder criteriaBuilder) {
                return criteriaBuilder.equal(root.get("stuName"),"zhangsan");
            }
        };
        Sort sortInfo = new Sort(Sort.Direction.DESC, "stuName");
        List stuList = studentDaoJpaSpecificationExecutor.findAll(specification, sortInfo);
        stuList.forEach(System.out::println);
    }

    @Test
    public void testDemo05(){
        Specification specification = new Specification() {
            /**
             * 定义查询条件
             * @param root 根对象  封装查询条件的对象
             * @param criteriaQuery 基本的查询
             * @param criteriaBuilder 创建查询条件
             * @return
             */
            @Override
            public Predicate toPredicate(Root root, CriteriaQuery criteriaQuery, CriteriaBuilder criteriaBuilder) {
                return criteriaBuilder.equal(root.get("stuName"),"zhangsan");
            }
        };
        Sort sortInfo = new Sort(Sort.Direction.DESC, "stuName");
        PageRequest pageRequest = new PageRequest(0, 3, sortInfo);
        Page pageInfo = studentDaoJpaSpecificationExecutor.findAll(specification, pageRequest);
        pageInfo.getContent().forEach(System.out::println);
    }
}
