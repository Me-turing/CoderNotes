package com.meturing.dao;

import com.meturing.pojo.Student;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

public interface StudentDaoByRepository03 extends Repository<Student, Integer> {

    @Query(value = "update Student set stuName = ? where stuId = ? ")
    @Modifying// 被@Modifying修饰的方法是一个更新操作
    void updateStudentInfo(String stuName,Integer stuId);

}
