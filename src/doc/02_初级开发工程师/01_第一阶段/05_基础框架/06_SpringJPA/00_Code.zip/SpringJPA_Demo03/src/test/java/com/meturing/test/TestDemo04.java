package com.meturing.test;

import com.meturing.dao.StudentDaoByRepository02;
import com.meturing.pojo.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class TestDemo04 {
    @Autowired
    private StudentDaoByRepository02 studentDaoByRepository02;

    @Test
    @Transactional
    public void query1(){
        Student student = studentDaoByRepository02.selectByStuName("王五");
        System.out.println(student);
    }

    @Test
    @Transactional
    public void query2(){
        List<Student> students = studentDaoByRepository02.selectByStuNameLike("%name%");
        students.forEach(System.out::println);
    }

    @Test
    @Transactional
    public void query3(){
        List<Student> students = studentDaoByRepository02.selectByStuAge(18);
        students.forEach(System.out::println);
    }

    @Test
    @Transactional
    public void query4(){
        List<Student> students = studentDaoByRepository02.findByStuNameAndStuAge("%name%",18);
        students.forEach(System.out::println);
    }
}
