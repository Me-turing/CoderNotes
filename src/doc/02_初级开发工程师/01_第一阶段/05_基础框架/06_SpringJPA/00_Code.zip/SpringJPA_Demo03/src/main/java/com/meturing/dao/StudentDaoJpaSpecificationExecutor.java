package com.meturing.dao;

import com.meturing.pojo.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface StudentDaoJpaSpecificationExecutor extends JpaRepository<Student,Integer>, JpaSpecificationExecutor {
}
