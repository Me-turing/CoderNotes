package com.meturing.dao;

import com.meturing.pojo.Student;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import java.util.List;

public interface StudentDaoByRepository02 extends Repository<Student, Integer> {

    @Query(value = "select * from Student where stuName = ?",nativeQuery = true)
    Student selectByStuName(String name);
    @Query(value = "select * from Student where stuName like ?",nativeQuery = true)
    List<Student> selectByStuNameLike(String name);

    @Query(value = "select * from Student where  stuAge > ?",nativeQuery = true)
    List<Student> selectByStuAge(Integer stuAge);

    @Query(value = "select * from Student where  stuName like ? and stuAge > ?",nativeQuery = true)
    List<Student> findByStuNameAndStuAge(String name,Integer stuAge);

}
