package com.meturing.dao;

import com.meturing.pojo.Student;
import org.springframework.data.repository.CrudRepository;

public interface StudentDaoByCrudRepository extends CrudRepository<Student, Integer> {

}
