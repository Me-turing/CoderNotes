package com.meturing.dao;

import com.meturing.pojo.Student;
import org.springframework.data.repository.Repository;

import java.util.List;

public interface StudentDaoByName extends Repository<Student, Integer> {

    //from student where stuName = ?
    Student findByStuName(String name);
    //from student where stuName like %?%
    List<Student> findByStuNameContaining(String name);

    // from student where stuAge > ?
    List<Student> findByStuAgeAfter(Integer stuAge);

    // from student where stuName like %?% and stuAge > ?
    List<Student> findByStuNameContainingAndStuAgeAfter(String name,Integer stuAge);

}
