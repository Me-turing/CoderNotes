package com.meturing.controller;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.Map;

@Controller
public class FreeMarkerDemo02 {

    @Autowired
    private Configuration configuration;

    @RequestMapping(value = "/news/statization")
    public ModelAndView statization(HttpServletRequest request) throws IOException, TemplateException {

        //构建ModelAndView对象
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("statizationPage");
        Map<String, Object> model = modelAndView.getModel();
        model.put("title", "特别就业季：稳就业情况如何? 哪些问题待解?");
        model.put("source", "人民日报");
        model.put("pubTime", new Date());
        model.put("content", "中共中央政治局常务委员会近日召开会议强调，" +
                "要有针对性地开展援企、稳岗、扩就业工作，" +
                "做好高校毕业生、农民工等重点群体就业工作，" +
                "积极帮助个体工商户纾困。疫情期间，稳就业情况如何？还有哪些问题待解？" +
                "记者采访了不同群体，记录这个特别的就业季。");
        //获取配置对象
        Template template = configuration.getTemplate("statizationPage.ftlh");

        //创建html文件（文件名，文件存放目录）
        String basePath = request.getServletContext().getRealPath("/");//获取当前的文件路径
        File filePath = new File(basePath + "/html");//创建html文件存放的目录
        if (!filePath.exists())filePath.mkdirs();//如果html路径不存在则创建

        String fileName = "statizationPage.html";//创建文件名
        File file = new File(filePath, fileName); //获取文件的完整路径，生成file对象
        FileWriter fileWriter = new FileWriter(file);//获取目标文件的文件流

        template.process(model,fileWriter);//将模板静态化

        return modelAndView;
    }
}
