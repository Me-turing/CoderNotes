package com.meturing.controller;

import com.meturing.pojo.Emp;
import com.meturing.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class showEmpList {
    @Autowired
    private EmpService empServiceImpl;

    @RequestMapping(value = "/emp/getAllEmp")
    public ModelAndView getAllEmp() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("EmpList");
        List<Emp> empList = empServiceImpl.getAllEmp();
        modelAndView.getModel().put("empList",empList);
        return modelAndView;
    }
}
