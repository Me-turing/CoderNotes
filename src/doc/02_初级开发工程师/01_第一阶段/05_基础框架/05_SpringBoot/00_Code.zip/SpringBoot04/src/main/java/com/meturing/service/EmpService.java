package com.meturing.service;

import com.meturing.pojo.Emp;

import java.util.List;

public interface EmpService {

    List<Emp> getAllEmp();
}
