package com.meturing.controller;

import com.meturing.pojo.People;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;

@Controller
public class FreeMarkerDemo01 {

    @RequestMapping(value = "/{pageName}")
    public ModelAndView showPage(@PathVariable("pageName") String pageName){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(pageName);
        Map<String, Object> model = modelAndView.getModel();
        model.put("name", "zhangsan");
        return modelAndView;
    }

    //测试FreeMarker中的数据类型
    @RequestMapping(value = "/testDataType")
    public ModelAndView testDataType(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("testDataType");
        //布尔类型
        Map<String, Object> model = modelAndView.getModel();
        model.put("vip",true);
        model.put("birthday",new Date());
        model.put("age",50);
        model.put("money",10086.543);
        model.put("degree",0.543);
        model.put("name","zhangsan");
        model.put("alias",null);

        People lisi = new People("lisi", 11);
        People zhangSan = new People("zhangSan", 12);
        People wangWu = new People("wangWu", 18);
        People zhaoLiu = new People("zhaoLiu", 20);
        List<People> peopleList = new ArrayList<>();
        peopleList.add(lisi);
        peopleList.add(zhangSan);
        peopleList.add(wangWu);
        peopleList.add(zhaoLiu);
        model.put("peopleList",peopleList);

        HashMap<String, People> peopleMap = new HashMap<>();
        peopleMap.put(lisi.getName(), lisi);
        peopleMap.put(zhangSan.getName(), zhangSan);
        peopleMap.put(wangWu.getName(), wangWu);
        peopleMap.put(zhaoLiu.getName(), zhaoLiu);
        model.put("peopleMap",peopleMap);

        return modelAndView;
    }

    @RequestMapping(value = "/instructions")
    public ModelAndView instructions(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("instructions");
        return modelAndView;
    }

    @RequestMapping(value = "/operator")
    public ModelAndView operator(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("operator");
        return modelAndView;
    }
}
