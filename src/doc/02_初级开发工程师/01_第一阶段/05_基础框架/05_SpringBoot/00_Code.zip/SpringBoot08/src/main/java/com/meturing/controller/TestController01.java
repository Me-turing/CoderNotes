package com.meturing.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class TestController01 {

    @RequestMapping("/login")
    public String login(String userName, String password, HttpServletRequest request){
        if (userName.equals("root")&&password.equals("123456")) {
            request.getSession().setAttribute("userName", userName);
            return "success";
        }
        return "redirect:index.html";
    }


    //@RequestMapping("/img/logo.png")
    //@ResponseBody
    //public String getLogo(){
    //    return "logo";
    //}
    //
    //@RequestMapping(path = {"/","/index"})
    //public String index(){
    //    return "index";
    //}
}
