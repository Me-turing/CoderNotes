package com.meturing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot03ApplicationTests {

    @Test
    void contextLoads() {
    }

}
