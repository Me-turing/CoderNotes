package com.meturing.controller;

import com.github.pagehelper.PageInfo;
import com.meturing.pojo.UserInfo;
import com.meturing.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserInfoController {
    @Autowired
    private UserInfoService userInfoService;

    @RequestMapping("/getAllUsersList")
    public List<UserInfo> getAllUsersList(){
        return userInfoService.getAllUsersList();
    }

    @RequestMapping("/getAllUsersByPage/{page}/{size}")
    public PageInfo<UserInfo> getAllUsersByPage(@PathVariable("page") Integer page, @PathVariable("size") Integer size){
        return userInfoService.getAllUsersByPage(page,size);
    }
}