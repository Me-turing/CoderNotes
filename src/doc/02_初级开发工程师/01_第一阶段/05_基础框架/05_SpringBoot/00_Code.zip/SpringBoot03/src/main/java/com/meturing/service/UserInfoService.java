package com.meturing.service;

import com.github.pagehelper.PageInfo;
import com.meturing.pojo.UserInfo;

import java.util.List;

public interface UserInfoService {

    List<UserInfo> getAllUsersList();

    PageInfo<UserInfo> getAllUsersByPage(Integer page, Integer size);
}
