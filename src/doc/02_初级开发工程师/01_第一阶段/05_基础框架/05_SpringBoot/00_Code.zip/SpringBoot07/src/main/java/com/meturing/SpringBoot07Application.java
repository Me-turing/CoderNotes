package com.meturing;

import com.meturing.pojo.User;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringBoot07Application {
    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(SpringBoot07Application.class, args);
        User user = context.getBean("user", User.class);
        //User user = context.getBean("user-com.meturing.pojo.User", User.class);
        System.out.println(user);


        //String[] beanDefinitionNames = context.getBeanDefinitionNames();
        //for (String beanDefinitionName : beanDefinitionNames) {
        //    System.out.println(beanDefinitionName);
        //}



        //System.out.println(context.containsBean("user"));

        /* 测试二
        User user1 = context.getBean(User.class);//通过字节码匹配Bean
        User user2 = context.getBean("com.meturing.pojo.User",User.class);//通过BeanName匹配
        System.out.println(user1);
        System.out.println(user2);*/

        /* 测试一
        String simpleName = context.getBean(TestSpringConfig.class).getClass().getSimpleName();
        System.out.println(simpleName);

        User user1 = context.getBean(TestSpringConfig.class).user();
        User user2 = context.getBean(TestSpringConfig.class).user();
        System.out.println(user1==user2);*/
    }
}
