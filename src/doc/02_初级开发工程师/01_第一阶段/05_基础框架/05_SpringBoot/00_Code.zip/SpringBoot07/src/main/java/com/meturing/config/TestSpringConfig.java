package com.meturing.config;

import com.meturing.pojo.User;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration()
//@Import({User.class})
//@ImportResource("classpath:SpringBean.xml")
@EnableConfigurationProperties(User.class)
public class TestSpringConfig {
    //@ConditionalOnProperty(name="Demo.DemoAttributes",havingValue = "true")
    //@Bean
    //public User user(){
    //    return new User("张三",18);
    //}
}
