package com.meturing.controller;

import com.meturing.pojo.Teacher;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Map;

@Controller
public class Namespace01Controller {

    @RequestMapping("/testNamespace01")
    public ModelAndView testNamespace01(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("Namespace01");
        Map<String, Object> model = modelAndView.getModel();
        model.put("sText", "这是新文本");
        model.put("userName", "这是新用户名");
        return modelAndView;
    }

    @RequestMapping("/testNamespace02")
    public ModelAndView testNamespace02(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("Namespace02");
        Map<String, Object> model = modelAndView.getModel();
        model.put("teacherList", "zhangsan");
        return modelAndView;
    }

    @RequestMapping("/testNamespace03")
    public ModelAndView testNamespace03(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("Namespace02");
        Map<String, Object> model = modelAndView.getModel();
        model.put("sex", "man");
        return modelAndView;
    }

    @RequestMapping("/testNamespace04")
    public ModelAndView testNamespace04(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("Namespace03");
        Map<String, Object> model = modelAndView.getModel();

        ArrayList<Teacher> teaschers = new ArrayList<>();
        Teacher teacher1 = new Teacher("zhangsan", "男", 35);
        Teacher teacher2 = new Teacher("lisi", "男", 44);
        Teacher teacher3 = new Teacher("wanger", "男", 32);
        Teacher teacher4 = new Teacher("mazi", "男", 58);
        teaschers.add(teacher1);
        teaschers.add(teacher2);
        teaschers.add(teacher3);
        teaschers.add(teacher4);
        model.put("teaschers",teaschers);
        return modelAndView;
    }


}
