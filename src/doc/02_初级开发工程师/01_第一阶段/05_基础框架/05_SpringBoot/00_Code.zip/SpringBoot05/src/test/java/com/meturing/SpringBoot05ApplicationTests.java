package com.meturing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot05ApplicationTests {

    @Test
    void contextLoads() {
    }

}
