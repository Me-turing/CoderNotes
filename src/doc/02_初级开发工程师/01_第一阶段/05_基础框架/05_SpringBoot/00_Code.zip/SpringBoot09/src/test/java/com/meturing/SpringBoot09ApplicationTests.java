package com.meturing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot09ApplicationTests {

    @Test
    void contextLoads() {
    }

}
