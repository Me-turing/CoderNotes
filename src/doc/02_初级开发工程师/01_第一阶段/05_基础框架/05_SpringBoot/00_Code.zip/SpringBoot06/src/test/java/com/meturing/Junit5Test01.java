package com.meturing;

import org.junit.jupiter.api.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.concurrent.TimeUnit;

@SpringBootTest
@DisplayName("Junit5测试类")
class Junit5Test01 {

    @BeforeAll
    public static void testBeforeAll(){
        System.out.println("testBeforeAll");
    }

    @AfterAll
    public static void testAfterAll(){
        System.out.println("testAfterAll");
    }

    @BeforeEach
    public void testBeforeEach(){
        System.out.println("testBeforeEach");
    }

    @AfterEach
    public void testAfterEach() {
        System.out.println("testAfterEach");
    }

    @RepeatedTest(3)//重复测试3次
    @Timeout(value = 1000,unit = TimeUnit.SECONDS)//超时时间
    @DisplayName("当前是测试类")//当前测试的描述信息
    @Test
    void contextLoads() {
        System.out.println("contextLoads");
    }
}
