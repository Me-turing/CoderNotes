package com.meturing;

import com.meturing.pojo.People;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.stream.Stream;

@SpringBootTest
@DisplayName("参数化测试")
public class Junit5Test05 {
    @ParameterizedTest
    @ValueSource(ints = { 1, 2, 3, 4, 5, 6})
    void parametricTestMethods01 (int age) {
        Assertions.assertTrue(age>2&&age<5,"年龄不符");
    }

    @ParameterizedTest
    @MethodSource("testPeopleList")
    void parametricTestMethods02 (People people) {
        Assertions.assertAll(
                ()->{Assertions.assertNotNull(people,"参数不能是NULL");},
                ()->{Assertions.assertTrue(people.getAge()<19,"年龄不能小于19");}
        );
    }
    public static Stream<People> testPeopleList() {
        ArrayList<People> people = new ArrayList<>();
        people.add(new People("zhangsan",18));
        people.add(new People("lisi",21));
        people.add(null);
        return people.stream();
    }

    @Test
    void testProxyBeanMethods () {

    }
}
