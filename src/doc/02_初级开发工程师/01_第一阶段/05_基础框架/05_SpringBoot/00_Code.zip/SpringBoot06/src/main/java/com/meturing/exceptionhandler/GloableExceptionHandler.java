package com.meturing.exceptionhandler;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class GloableExceptionHandler {
    //@ExceptionHandler(value = {ArithmeticException.class,NullPointerException.class})
    //public String GloableExceptionMethod(){
    //    return "errorPage";
    //}
}
