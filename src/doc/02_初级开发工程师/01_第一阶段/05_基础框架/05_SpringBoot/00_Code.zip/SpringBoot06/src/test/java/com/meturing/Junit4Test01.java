package com.meturing;


import jdk.nashorn.internal.ir.annotations.Ignore;
import org.junit.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTestContextBootstrapper;
import org.springframework.test.context.BootstrapWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@BootstrapWith(SpringBootTestContextBootstrapper.class)
@ExtendWith({SpringExtension.class})
public class Junit4Test01 {

    @BeforeClass
    public static void testBeforeClass() {
        System.out.println("testBeforeClass");
    }

    @AfterClass
    public static void testAfterClass() {
        System.out.println("testAfterClass");
    }

    @Before
    public void testBefore() {
        System.out.println("testBefore");
    }

    @After
    public void testAfter() {
        System.out.println("testAfter");
    }

    @Test
    public void testMethod(){
        System.out.println("testMethod");
    }

    @Test
    @Ignore
    public void testMethod02(){
        System.out.println("testMethod");
    }
}
