package com.meturing.config;

//@Configuration
//public class MyHandlerExceptionResolver implements HandlerExceptionResolver {
//    @Override
//    public ModelAndView resolveException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
//        ModelAndView modelAndView = new ModelAndView();
//        if (e instanceof ArithmeticException){
//            modelAndView.setViewName("errorPage");
//        }
//        return modelAndView;
//    }
//}

//@Configuration
public class MyHandlerExceptionResolver {

}
