package com.meturing;


import com.meturing.pojo.People;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.Duration;


@SpringBootTest
@DisplayName("测试断言")
class Junit5Test02 {
    @DisplayName("测试断言1")
    @Test
    public void testMethod01(){
        int age = 18;
        Assertions.assertEquals(10, age,"age参数与期望值10不一致");
    }

    @DisplayName("测试断言2")
    @Test
    public void testMethod02(){
        int age = 10;
        Assertions.assertNotEquals(10, age,"age参数与期望值10一致");
    }

    @DisplayName("测试断言3")
    @Test
    public void testMethod03(){
        String str1 = new String("123");
        String str2 = new String("123");
        Assertions.assertSame(str1, str2,"两个对象引用不同");
    }

    @DisplayName("测试断言4")
    @Test
    public void testMethod04(){
        String str1 = new String("123");
        String str2 = str1;
        Assertions.assertNotSame(str1, str2,"两个对象为相同引用");
    }

    @DisplayName("测试断言5")
    @Test
    public void testMethod05(){
        Boolean flag = false;
        Assertions.assertTrue(flag,"结果不是True");
    }

    @DisplayName("测试断言6")
    @Test
    public void testMethod06(){
        Boolean flag = true;
        Assertions.assertFalse(flag,"结果不是Fasle");
    }

    @DisplayName("测试断言7")
    @Test
    public void testMethod07(){
        People people = new People();
        Assertions.assertNull(people,"结果不为空");
    }

    @DisplayName("测试断言8")
    @Test
    public void testMethod08(){
        People people = null;
        Assertions.assertNotNull(people,"结果为空");
    }

    @DisplayName("测试断言9")
    @Test
    public void testMethod09(){
        People people = new People("zhangsan",17);
        Assertions.assertAll("assertAll",
                ()-> Assertions.assertNotNull(people,"当前对象为空"),
                ()-> Assertions.assertTrue(18 < people.getAge(),"用户的年龄小于18")
        );
    }

    @DisplayName("测试断言10")
    @Test
    public void testMethod10()  {
       Assertions.assertThrows(Exception.class,()->{int age = 1/1;},"没有抛出异常");
    }

    @DisplayName("测试断言11")
    @Test
    public void testMethod11() {
        Assertions.assertTimeout(Duration.ofMillis(3000), () -> {
            Thread.sleep(5000);
        }, "执行时间超过设定值3000毫秒");
    }

    @DisplayName("测试断言12")
    @Test
    public void testMethod12() {
       boolean flag = false;
        if (!flag) {
            Assertions.fail("结果为fasle");
        }
    }
}
