package com.meturing.config;

import com.meturing.pojo.Car;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = true)
public class InjectBeanConfig {
    //@Bean("people1")
    //protected People getPeople1() {
    //    People people1 = new People("zhangsan", 18);
    //    return people1;
    //}
    //
    //@Bean("people2")
    //protected People getPeople2() {
    //    People people2 = new People("zhangsan", 18);
    //    return people2;
    //}

    //@Bean("people3")
    //protected People getPeople3(Car car) {
    //    People people2 = new People("zhangsan", 18,car);
    //    return people2;
    //}

    @Bean
    public Car getCar(){
        return new Car("wlhg","red");
    }
}
