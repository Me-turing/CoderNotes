package com.meturing;

import org.junit.jupiter.api.*;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@DisplayName("测试嵌套")
public class Junit5Test04 {
    @BeforeAll
    public static void externalBeforeAll(){System.out.println("ExternalBeforeAll");}
    @AfterAll
    public static void externalAfterAll(){System.out.println("ExternalAfterAll");}
    @BeforeEach
    public void externalBeforeEach(){System.out.println("ExternalBeforeEach");}
    @AfterEach
    public void externalAfterEach(){System.out.println("ExternalAfterEach");}
    @Test
    void isInstantiatedWithNew() {System.out.println("External Test Methods");}

    @Nested
    class InternalTestClass{
        @BeforeEach
        public void interiorBeforeEach(){System.out.println("InteriorBeforeEach");}
        @AfterEach
        public void interiorAfterEach(){System.out.println("InteriorAfterEach");}
        @Test
        void isInstantiatedWithNew() {System.out.println("Interior Test Methods");}
    }
}
