package com.meturing;


import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
@DisplayName("测试断言")
class Junit5Test03 {
    @DisplayName("测试断言1")
    @Test
    public void testMethod01(){
        int age = 18;
        Assumptions.assumeTrue(age>18,"age小于等于18");
        System.out.println("后面的代码片段");
    }
}
