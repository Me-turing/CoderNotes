package com.meturing.controller;

import com.meturing.pojo.People;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloThymeleafController {
    //@RequestMapping("/HelloThymeleaf")
    //public String helloThymeleaf(){
    //    int i = 1/0;
    //    return "HelloThymeleaf";
    //}
    //
    //@Autowired
    //@Qualifier("people3")
    //private People people1;
    //
    //@RequestMapping("/getPeople")
    //public People getPeople(){
    //    return people1;
    //}
    //
    //@RequestMapping("/getPeople2")
    //public People getPeople2(){
    //    return people;
    //}


    //@ExceptionHandler(value = {ArithmeticException.class,NullPointerException.class})
    //public String errorController(){
    //    return "errorPage";
    //}
}
