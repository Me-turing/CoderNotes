package com.meturing.config;

//@Configuration
//public class SpringBootConfig {
//    //@Bean
//    //public SimpleMappingExceptionResolver SimpleMappingExceptionResolver(){
//    //    SimpleMappingExceptionResolver simpleMappingExceptionResolver = new SimpleMappingExceptionResolver();
//    //    Properties properties = new Properties();
//    //    properties.put("java.lang.ArithmeticException", "errorPage");
//    //    simpleMappingExceptionResolver.setExceptionMappings(properties);
//    //    return simpleMappingExceptionResolver;
//    //}
//}

//@Configuration
public class SpringBootConfig {
    //@Bean
    //public SimpleMappingExceptionResolver SimpleMappingExceptionResolver(){
    //    SimpleMappingExceptionResolver simpleMappingExceptionResolver = new SimpleMappingExceptionResolver();
    //    Properties properties = new Properties();
    //    properties.put("java.lang.ArithmeticException", "errorPage");
    //    simpleMappingExceptionResolver.setExceptionMappings(properties);
    //    return simpleMappingExceptionResolver;
    //}
}
