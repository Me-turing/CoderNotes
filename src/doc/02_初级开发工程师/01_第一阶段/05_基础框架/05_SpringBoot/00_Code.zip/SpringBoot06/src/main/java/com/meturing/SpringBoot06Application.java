package com.meturing;

import com.meturing.pojo.Car;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.meturing.*")
public class SpringBoot06Application {
    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(SpringBoot06Application.class, args);
        Car car1 = (Car) context.getBean("car");
        Car car2 = (Car) context.getBean("car");
        System.out.println(car1==car2);
    }
}
