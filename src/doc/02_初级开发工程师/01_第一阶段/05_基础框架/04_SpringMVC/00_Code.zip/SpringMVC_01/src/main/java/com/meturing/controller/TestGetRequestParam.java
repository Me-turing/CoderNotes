package com.meturing.controller;

import com.meturing.pojo.Person;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

@RestController
public class TestGetRequestParam {
    //紧耦合方式参数注入
    @RequestMapping("/getParamByRequest")
    public String getParamByRequest(HttpServletRequest req, HttpServletResponse resp) {
        String username = req.getParameter("username1");
        String password = req.getParameter("password");
        System.out.println("username:"+username+" / password:"+password);
        return "success";
    }

    //解耦合方式参数注入
    @RequestMapping("/getParamByArgName")
    public String getParamByArgName(@RequestParam String username, @RequestParam("password") String pwd) {
        System.out.println("username:"+username+" / password:"+pwd);
        return "success";
    }

    @RequestMapping("/getDataByPojo")
    public String getDataByPojo(Person person){
        System.out.println(person);
        return "success";
    }

    @RequestMapping("/getDateFormat")
    public String getDateFormat( Date birthdate){
        System.out.println(birthdate);
        return "success";
    }

    @RequestMapping("/getDataByList")
    public String getDataByList(Person person){
        System.out.println(person.getPetsList());
        return "success";
    }

    @RequestMapping("/getDataByMap")
    public String getDataByMap(Person person){
        System.out.println(person.getPetsMap());
        return "success";
    }
}
