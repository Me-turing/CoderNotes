package com.meturing.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestRestful {
    @RequestMapping("/getRestful/{pageName}/{str}")
    public String getRestful(@PathVariable("pageName") String pageName1,@PathVariable("str") String str1){
        return pageName1+"/"+str1;
    }

    @RequestMapping(value = "/testRestful/{userId}",method = RequestMethod.GET)
    public String getRestful(@PathVariable String userId){
        return "GET :"+userId;
    }

    @RequestMapping(value = "/testRestful/{userId}",method = RequestMethod.POST)
    public String postRestful(@PathVariable String userId){
        return "POST :"+userId;
    }

    @RequestMapping(value = "/testRestful/{userId}",method = RequestMethod.PUT)
    public String putRestful(@PathVariable String userId){
        return "PUT :"+userId;
    }

    @RequestMapping(value = "/testRestful/{userId}",method = RequestMethod.DELETE)
    public String deleteRestful(@PathVariable String userId){
        return "DELETE :"+userId;
    }
}
