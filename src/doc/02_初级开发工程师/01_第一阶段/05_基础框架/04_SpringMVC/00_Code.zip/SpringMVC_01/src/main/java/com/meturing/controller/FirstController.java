package com.meturing.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/meturing")
public class FirstController {
    @RequestMapping("/firstController")
    public String getFirstView() {
        System.out.println("firstController");
        //相当于请求转发
        return "first";
    }

}
