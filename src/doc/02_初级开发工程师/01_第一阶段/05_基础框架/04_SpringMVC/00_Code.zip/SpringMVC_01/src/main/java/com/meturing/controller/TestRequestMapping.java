package com.meturing.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class TestRequestMapping {
    @RequestMapping(value = "/testPostRequest", method= RequestMethod.POST)
    public String testPostRequest() {
        System.out.println("testPostRequest");
        return "first";
    }

    @RequestMapping(value = "/testRequestParams", params={"userName!=root","password","!sex"})
    public String testRequestParams() {
        System.out.println("testRequestParams");
        return "first";
    }

    @RequestMapping(value = "/testRequestHeaders", headers={"Referer=http://localhost:8080/SpringMVC_01/testRequestMapping.jsp"})
    public String testRequestHeaders() {
        System.out.println("testRequestParams");
        return "first";
    }
}
