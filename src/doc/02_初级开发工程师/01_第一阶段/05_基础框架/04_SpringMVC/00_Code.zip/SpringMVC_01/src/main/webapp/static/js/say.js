function say() {
    alert("123");
}