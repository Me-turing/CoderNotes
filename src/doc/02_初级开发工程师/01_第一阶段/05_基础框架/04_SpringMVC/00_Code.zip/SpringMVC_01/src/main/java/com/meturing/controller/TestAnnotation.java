package com.meturing.controller;

import org.springframework.web.bind.annotation.*;

@RestController()
@RequestMapping(value = "/TestAnnotation")
public class TestAnnotation {
    @RequestMapping(value = "/{testRequestMapping}",method = RequestMethod.POST,params={"name!=root"},headers = {"Host=localhost:8080"})
    public String testRequestMapping(@RequestParam(value = "name",required = false) String uname,
                                     @PathVariable(value = "testRequestMapping",required = false) String path,
                                     @RequestHeader(value = "Accept-Language",required = false) String sLanguage,
                                     @CookieValue(value = "JSESSIONID",required = false) String sCookie){
        System.out.println(uname+"/"+path+"/"+sLanguage+"/"+sCookie);
        return "success";
    }
}
