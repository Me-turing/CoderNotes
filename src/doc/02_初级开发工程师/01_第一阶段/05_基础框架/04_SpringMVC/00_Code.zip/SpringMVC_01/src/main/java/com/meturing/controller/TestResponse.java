package com.meturing.controller;

import com.meturing.pojo.Person;
import com.meturing.pojo.Pets;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.InternalResourceView;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
public class TestResponse {
    @RequestMapping("/testReturnVoid")
    public void testReturnVoid() throws Exception{
        System.out.println("AccountController 的 testForward 方法执行了。。。。");
    }

    @RequestMapping("/testForwardByServletAPI")
    public void testForwardByServletAPI(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/forward.jsp").forward(request,response);
    }

    @RequestMapping("/testRedirectByServletAPI")
    public void testRedirectByServletAPI(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect(request.getContextPath()+"/redirect.jsp");
    }

    /*
     * 返回字符串告诉DispatcherServlet跳转的路径
     * 在路径之前放上一个forward: 关键字,就是请求转发
     * 如果路径前的关键字是forward,那么可以省略不写
     * */
    @RequestMapping("/testKeywordsByForward")
    public String testKeywordsByForward()  {
        return "/forward.jsp";
        //return "forward:/forward.jsp";
    }

    @RequestMapping("/testKeywordsByRedirect")
    public String testKeywordsByRedirect()  {
        return "redirect:/redirect.jsp";
    }

    @RequestMapping("/testViewByForward")
    public View testViewByForward()  {
        return new InternalResourceView("/forward.jsp");
    }

    @RequestMapping("/testViewByRedirect")
    public View testViewByRedirect(HttpServletRequest request)  {
        return new RedirectView(request.getContextPath()+"/redirect.jsp");
    }

    @RequestMapping("/testModelAndViewByForward")
    public ModelAndView testModelAndViewByForward()  {
        ModelAndView modelAndView = new ModelAndView();
        //modelAndView.setViewName("forward:/forward.jsp");
        modelAndView.setView(new InternalResourceView("/forward.jsp"));
        return modelAndView;
    }

    @RequestMapping("/testModelAndViewByRedirect")
    public ModelAndView testModelAndViewByRedirect(HttpServletRequest request)  {
        ModelAndView modelAndView = new ModelAndView();
        //modelAndView.setViewName("redirect:/redirect.jsp");
        modelAndView.setView(new RedirectView(request.getContextPath()+"/redirect.jsp"));
        return modelAndView;
    }

    /*
     * @ResponseBody
     * 1方法的返回值不在作为界面跳转依据,而已直接作为返回的数据
     * 2将方法的返回的数据自动使用ObjectMapper转换为JSON
     */
    @ResponseBody
    @RequestMapping("/testAjax")
    public Pets testAjax(Person p) {
        System.out.println(p);
        Pets pet =new Pets("Tom","cat");
        return pet;
    }
}
