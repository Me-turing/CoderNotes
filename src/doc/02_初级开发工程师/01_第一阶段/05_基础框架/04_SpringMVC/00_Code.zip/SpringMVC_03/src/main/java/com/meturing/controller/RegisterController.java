package com.meturing.controller;

import com.meturing.pojo.UploadInfo;
import com.meturing.pojo.dto.UploadInfoDto;
import com.meturing.service.UserRegister;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

@Controller
public class RegisterController {

    @Autowired
    private UserRegister userRegisterImpl;
    // 文件存储位置
    private final static String FILESERVER="http://127.0.0.1:8090/upload/";

    @RequestMapping("/fileUpload")
    @ResponseBody
    public HashMap<String, String> register(MultipartFile headPhoto, @RequestParam String ipAddress, HttpServletRequest request) throws IOException {
        HashMap<String, String> responseMap = new HashMap<>();
        //获取文件的大小
        if (headPhoto.getSize()>=1024*1024*5){
            responseMap.put("message", "文件大小不能超过5M");
            return responseMap;
        }
        String realPath = request.getServletContext().getRealPath("static/upload");//获取当前static/update目录地址
        File dir = new File(realPath);
        if (!dir.exists()) dir.mkdirs();//如果文件夹不存在则创建
        String filename = headPhoto.getOriginalFilename();//获取上传文件的名字
        //使用UUID处理文件名字避免重复
        String substring = filename.substring(filename.lastIndexOf("."));
        //校验文件是否是.jpg类型
        if (substring.equals(".jpg")){
            responseMap.put("message", "文件类型必须是.jpg");
            return responseMap;
        }
        String uuidStr = UUID.randomUUID().toString();
        filename = uuidStr.concat(substring);
        //File file = new File(dir, filename);//根据保存路径和保存文件名称获取对应的File对象
        //headPhoto.transferTo(file);//将收到的文件传输到给定的目标文件

        //创建 sun公司提供的jersey包中的client对象
        Client client = Client.create();
        WebResource resource = client.resource(FILESERVER + filename);
        //将文件提交到指定路径上
        resource.put(String.class,headPhoto.getBytes());

        String contentType = headPhoto.getContentType();//获取当前上传的类型
        Date date = Date.from(Instant.now());//当前的时间
        UploadInfo uploadInfo = new UploadInfo(null, ipAddress, realPath+File.separatorChar+filename, contentType, date);
        userRegisterImpl.saveInfo(uploadInfo);
        responseMap.put("message","上传成功！");
        responseMap.put("fileName",filename);
        responseMap.put("fileType",contentType);
        return responseMap;
    }

    @RequestMapping("/getAllFile")
    @ResponseBody
    public List<UploadInfoDto> getAllFile() {
        return userRegisterImpl.getAllFile();
    }

    @RequestMapping("/fileDownLoad")
    public void fileDownLoad(String fileName, String fileType, HttpServletResponse response) throws IOException {
        // 设置响应头
        // 告诉浏览器要将数据保存到磁盘上,不在浏览器上直接解析
        response.setHeader("Content-Disposition", "attachment;filename="+fileName);
        // 告诉浏览下载的文件类型
        response.setContentType(fileType);
        // 获取一个服务器上文件的输入流
        InputStream inputStream = new URL(FILESERVER + fileName).openStream();
        // 获取一个指向浏览器的输出流
        ServletOutputStream outputStream = response.getOutputStream();
        // 向浏览器响应文件即可
        IOUtils.copy(inputStream, outputStream);
    }
}
