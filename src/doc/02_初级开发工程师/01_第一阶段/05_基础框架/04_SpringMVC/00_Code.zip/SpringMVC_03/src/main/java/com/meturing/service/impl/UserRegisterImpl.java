package com.meturing.service.impl;

import com.meturing.mapper.UserRegisterMapper;
import com.meturing.pojo.UploadInfo;
import com.meturing.pojo.dto.UploadInfoDto;
import com.meturing.service.UserRegister;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class UserRegisterImpl implements UserRegister {
    @Autowired
    private UserRegisterMapper userRegisterMapper ;
    @Override
    public void saveInfo(UploadInfo uploadInfo) {
        userRegisterMapper.saveInfo(uploadInfo);
    }

    @Override
    public List<UploadInfoDto> getAllFile() {
        List<UploadInfo> uploadInfoList = userRegisterMapper.getAllFile();
        List<UploadInfoDto> uploadInfoDtoList = new ArrayList<>();
        for (UploadInfo uploadInfo : uploadInfoList) {
            UploadInfoDto uploadInfoDto = new UploadInfoDto();
            uploadInfoDto.setSerialNo(uploadInfo.getSerialNo());
            uploadInfoDto.setUploadIp(uploadInfo.getUploadIp());
            uploadInfoDto.setUploadName(uploadInfo.getUploadPath().substring(uploadInfo.getUploadPath().lastIndexOf(File.separatorChar)+1));
            uploadInfoDto.setUploadType(uploadInfo.getUploadType());
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:MM:SS");
            uploadInfoDto.setUploadTime(dateFormat.format(uploadInfo.getUploadTime()));
            uploadInfoDtoList.add(uploadInfoDto);
        }
        return uploadInfoDtoList;
    }
}
