package com.meturing.service;

import com.meturing.pojo.UploadInfo;
import com.meturing.pojo.dto.UploadInfoDto;

import java.util.List;

public interface UserRegister {

    void saveInfo(UploadInfo uploadInfo);

    List<UploadInfoDto> getAllFile();
}
