package com.meturing.mapper;


import com.meturing.pojo.UploadInfo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserRegisterMapper {

    void saveInfo(UploadInfo uploadInfo);

    List<UploadInfo> getAllFile();
}
