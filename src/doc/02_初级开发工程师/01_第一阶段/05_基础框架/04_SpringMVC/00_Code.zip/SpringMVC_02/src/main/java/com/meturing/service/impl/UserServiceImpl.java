package com.meturing.service.impl;

import com.meturing.mapper.UserMapper;
import com.meturing.pojo.User;
import com.meturing.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    public User getLogin(String username, String password) {
        return userMapper.getLogin(username,password);
    }

    public List<User> getAllUser() {
        return userMapper.getAllUser();
    }
}
