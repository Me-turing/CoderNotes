package com.meturing.controller;

import com.meturing.pojo.User;
import com.meturing.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("/login")
    public String getLogin(String username,String password) {
        User user = userService.getLogin(username,password);
        if (user==null){
            return "/fail";
        }else {
            return "/success";
        }
    }

    @RequestMapping("/getAllUser")
    @ResponseBody
    public List<User> getAllUser(){
        return  userService.getAllUser();
    }
}
