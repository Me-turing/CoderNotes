package com.meturing.controller;

import com.meturing.pojo.User;
import com.meturing.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@Controller
public class ScopeController {
    @Autowired
    UserService userService;

    @RequestMapping("/setScopeByServlet")
    public String setScopeByServlet(HttpServletRequest request, HttpSession session) {

        List<User> allUser = userService.getAllUser();

        //存储到request域中:本次请求期间有效
        request.setAttribute("message", "reqMessage");
        request.setAttribute("users", allUser);

        //存储到session域中:本次会话期间有效
        session.setAttribute("message", "sessionMessage");
        session.setAttribute("users", allUser);

        //存储到application域中:本次服务运行期间都有效
        ServletContext application = request.getServletContext();
        application.setAttribute("message", "applicationMessage");
        application.setAttribute("users", allUser);

        return "/showDataPage";
    }

    @RequestMapping("/setScopeByModel")
    public String setScopeByModel(Model model) {
        List<User> allUser = userService.getAllUser();
        //存储到model中:本次请求期间有效
        model.addAttribute("message", "reqMessage");
        model.addAttribute("users", allUser);
        return "/showDataPage";
        //return "redirect:/showDataPage.jsp";
    }


    @RequestMapping("/setScopeByModelAndView")
    public ModelAndView setScopeByModelAndView() {
        List<User> allUser = userService.getAllUser();

        ModelAndView modelAndView = new ModelAndView();
        //设置Model
        Map<String, Object> model = modelAndView.getModel();
        model.put("message", "reqMessage");
        model.put("users", allUser);
        //设置视图
        modelAndView.setViewName("redirect:/showDataPage.jsp");
        return modelAndView;
    }
}
