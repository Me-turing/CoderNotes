package com.meturing.controller;

import com.meturing.pojo.UserInfo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
public class AnnotationController {
    @GetMapping("/getUserInfo")
    public UserInfo getUserInfo(){
        return new UserInfo(1,"aaa","aaa",new Date());
    }

    @GetMapping("/getDateTime")
    public UserInfo getDateTime(){
        UserInfo userInfo = new UserInfo(1, "aaa", "aaa", new Date());
        System.out.println(userInfo);
        return userInfo;
    }

    @PostMapping("/jsonSend")
    public UserInfo jsonSend(UserInfo userInfo){
        System.out.println(userInfo);
        return userInfo;
    }
}
