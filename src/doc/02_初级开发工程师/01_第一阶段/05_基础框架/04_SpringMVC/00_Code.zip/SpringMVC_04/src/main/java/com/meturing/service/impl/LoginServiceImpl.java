package com.meturing.service.impl;

import com.meturing.mapper.LoginMapper;
import com.meturing.pojo.UserInfo;
import com.meturing.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class LoginServiceImpl implements LoginService {
    @Autowired
    private LoginMapper loginMapper;

    @Override
    public UserInfo login(String userName, String passWord) {
        return loginMapper.login(userName,passWord);
    }

    @Override
    public void updateAll() {
        loginMapper.updateAll();
        while (true){}
    }

    @Override
    public void update() {
        loginMapper.update();
    }
}
