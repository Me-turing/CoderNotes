package com.meturing.mapper;

import com.meturing.pojo.UserInfo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LoginMapper {

    UserInfo login(String userName, String passWord);

    void updateAll();

    void update();
}
