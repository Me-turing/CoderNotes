package com.meturing.service;

import com.meturing.pojo.UserInfo;

public interface LoginService {
    UserInfo login(String userName, String passWord);

    void updateAll();

    void update();

}
