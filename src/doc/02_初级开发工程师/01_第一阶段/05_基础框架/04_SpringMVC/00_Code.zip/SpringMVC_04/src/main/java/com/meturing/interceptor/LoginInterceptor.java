package com.meturing.interceptor;

import com.meturing.pojo.UserInfo;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Optional;

public class LoginInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        /*在请求到达我们定义的handler之前工作的*/
        System.out.println("preHandle run~");
        UserInfo userInfo = (UserInfo) request.getSession().getAttribute("userInfo");
        Optional<UserInfo> optionalUserInfo = Optional.ofNullable(userInfo);
        if (optionalUserInfo.isPresent()){
            return true;
        }else{
            response.sendRedirect(request.getContextPath());
            return false;
        }
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        /*handler 处理单元返回ModelAndView 时候进行 拦截*/
        System.out.println("postHandle run~");
        Optional<ModelAndView> optionalModelAndView = Optional.ofNullable(modelAndView);
        optionalModelAndView.ifPresent(andView -> {
            ModelMap modelMap = andView.getModelMap();
            String message = modelMap.get("message").toString().replaceAll("智障", "**");
            modelMap.put("message",message);
        });
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
         /*页面渲染完毕,但是还没有给浏览器响应数据的时候*/
        System.out.println("afterCompletion run~");
        Optional<Exception> optionalException = Optional.ofNullable(ex);
        UserInfo userInfo = (UserInfo) request.getSession().getAttribute("userInfo");
        if (optionalException.isPresent()){
            //输出日志
            System.out.println(userInfo.getName()+"用户操作发生异常:"+ex);
        }
    }
}
