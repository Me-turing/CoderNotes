package com.meturing.controller;

import com.meturing.pojo.UserInfo;
import com.meturing.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.Optional;

@Controller
public class LoginController {

    @Autowired
    private LoginService loginServiceImpl;

    @RequestMapping("/login")
    public String login(String userName, String passWord, HttpSession session){
        UserInfo userInfo = loginServiceImpl.login(userName, passWord);
        Optional<UserInfo> optionalUserInfo = Optional.ofNullable(userInfo);
        if (optionalUserInfo.isPresent()){
            session.setAttribute("userInfo",userInfo);
            return "success";
        }
        return "fail";
    }

    @RequestMapping("/updateAll")
    public void  updateAll(){
        loginServiceImpl.updateAll();

    }

    @RequestMapping("/update")
    public void  update(){
        loginServiceImpl.update();
    }

    @RequestMapping("/success")
    public ModelAndView success(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("success");
        ModelMap modelMap = modelAndView.getModelMap();
        int i = 1/0;
        System.out.println("Controller run~");
        modelMap.put("message","你是智障!");
        return modelAndView;
    }

    @RequestMapping("/testException")
    public ModelAndView testException(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index");
        int i = 1/0;
        return modelAndView;
    }

    //@ExceptionHandler(value = {ArithmeticException.class,NullPointerException.class})
    //public ModelAndView handelException(){
    //    ModelAndView modelAndView = new ModelAndView();
    //    modelAndView.setViewName("fail");
    //    return modelAndView;
    //}
}
