package com.meturing.test;

import com.meturing.pojo.Emp;
import com.meturing.service.DeptService;
import com.meturing.service.EmpService;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.List;

public class Test01 {
    @Test
    public void test01(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContex.xml");
        EmpService empService = applicationContext.getBean( EmpService.class);

        int empCount = empService.findEmpCount();//获取员工的总数
        System.out.println(empCount);

        Emp byEmpno = empService.findByEmpno(8899);
        System.out.println(byEmpno);

        List<Emp> byDeptno = empService.findByDeptno(30);
        System.out.println(byDeptno);

        //Emp emp = new Emp(null, "test", "test", 1888, new Date(), 1888.00, null, 10);
        //empService.addEmp(emp);

        //Emp emp = new Emp(8900, "111", "test", 1888, new Date(), 1888.00, 0.0, 10);
        //empService.updateEmp(emp);

        empService.deleteEmp(8900);

    }

    @Test
    public void test02(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContex.xml");
        DeptService deptService = applicationContext.getBean( DeptService.class);
        //List<Dept> depts = new ArrayList<>();
        // depts.add(new Dept(50, "11","11"));
        // depts.add(new Dept(60, "22","22"));
        // depts.add(new Dept(70, "33","33"));
        //deptService.deptBatchAdd(depts);

        //depts.add(new Dept(44, "11","11"));
        //depts.add(new Dept(45, "22","22"));
        //depts.add(new Dept(46, "33","33"));
        //deptService.deptBatchUpdate(depts);

        List<Integer> deptnos =new ArrayList<>();
        deptnos.add(44);
        deptnos.add(45);
        deptnos.add(46);
        deptService.deptBatchDelete(deptnos);
    }
}
