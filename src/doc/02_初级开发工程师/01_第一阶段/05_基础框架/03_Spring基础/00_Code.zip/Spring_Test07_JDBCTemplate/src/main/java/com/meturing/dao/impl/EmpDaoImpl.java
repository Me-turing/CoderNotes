package com.meturing.dao.impl;

import com.meturing.dao.EmpDao;
import com.meturing.pojo.Emp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmpDaoImpl implements EmpDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 获取Emp总数
     * jdbcTemplate.queryForObject可以执行指定的查询SQL,并设置指定的返回值类型
     *
     * @return int
     * @author sqTan
     * @date 2023/05/15
     */
    @Override
    public int findEmpCount() {
        return jdbcTemplate.queryForObject("select count(1) from emp", Integer.class);
    }

    /**
     * 查找单个员工信息
     * jdbcTemplate.queryForObject
     * @param empno empno
     * @return {@link Emp }
     * @author sqTan
     * @date 2023/05/15
     */
    @Override
    public Emp findByEmpno(int empno) {
        BeanPropertyRowMapper<Emp> empBeanPropertyRowMapper = new BeanPropertyRowMapper<>(Emp.class);
        return jdbcTemplate.queryForObject("select * from  emp where empno =?", empBeanPropertyRowMapper, empno);
    }

    /**
     * 查找多个参数
     * jdbcTemplate.query
     * @param deptno deptno
     * @return {@link List }<{@link Emp }>
     * @author sqTan
     * @date 2023/05/15
     */
    @Override
    public List<Emp> findByDeptno(int deptno) {
        String sql = "select * from emp where deptno =?";
        BeanPropertyRowMapper<Emp> empBeanPropertyRowMapper = new BeanPropertyRowMapper<>(Emp.class);
        return jdbcTemplate.query(sql, empBeanPropertyRowMapper, deptno);
    }

    @Override
    public int addEmp(Emp emp) {
        String sql = "insert into emp values(DEFAULT ,?,?,?,?,?,?,?)";
        Object[] args = {emp.getEname(),emp.getJob(),emp.getMgr(),emp.getHiredate(),emp.getSal(),emp.getComm(),emp.getDeptno()};
        return jdbcTemplate.update(sql, args);
    }

    @Override
    public int updateEmp(Emp emp) {
        String sql = "update emp set ename =? , job =?, mgr=? , hiredate =?, sal=?, comm=?, deptno =? where empno =?";
        Object[] args = {emp.getEname(),emp.getJob(),emp.getMgr(),emp.getHiredate(),emp.getSal(),emp.getComm(),emp.getDeptno(),emp.getEmpno()};
        return jdbcTemplate.update(sql, args);
    }

    @Override
    public int deleteEmp(int empno) {
        String sql ="delete  from emp where empno =?";
        return jdbcTemplate.update(sql, empno);
    }
}
