package com.meturing.test;

import com.meturing.dao.DeptDao;
import com.meturing.dao.impl.DeptDaoImpl;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test01 {

    /**
     * 手动获取对象
     *
     * @author sqTan
     * @date 2023/04/22
     */
    @Test
    public void test01(){
        DeptDao deptDao = new DeptDaoImpl();
        deptDao.sayHello();
    }

    /**
     * 通过Spring中的IOC容器获取对象(底层运用的反射动态代理)
     *
     * @author sqTan
     * @date 2023/04/22
     */
    @Test
    public void test02(){
        //通过ClassPathXmlApplicationContext获取Spring.xml注册文件中的内容(底层Spring会自动根据我们的标签,为我们创建指定的对象)
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        //通过ApplicationContext对象获取容器中已经注册的Bean对象,并指定他的类型
        DeptDao deptDao = applicationContext.getBean("deptDao", DeptDao.class);
        //调用获取到的对象中的方法
        deptDao.sayHello();
    }
}
