package com.meturing.dao.impl;

import com.meturing.dao.DeptDao;

public class DeptDaoImpl implements DeptDao {

    public void sayHello() {
        System.out.println("Hello Spring");
    }
}
