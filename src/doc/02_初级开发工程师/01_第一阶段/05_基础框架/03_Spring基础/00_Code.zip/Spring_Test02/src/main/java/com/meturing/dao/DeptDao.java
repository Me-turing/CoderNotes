package com.meturing.dao;

public interface DeptDao {
    void sayHello();
}
