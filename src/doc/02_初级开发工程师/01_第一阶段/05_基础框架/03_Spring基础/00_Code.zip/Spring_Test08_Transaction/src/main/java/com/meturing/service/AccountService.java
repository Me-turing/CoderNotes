package com.meturing.service;

public interface AccountService {
    int transMoney(int from ,int to,int money);

    //测试编程式事务管理
    //int transMoneyCode(int from ,int to,int money);
    //使用注解
    int transMoneyAnnotations(int from ,int to,int money);

    int transMoneyXml(int from ,int to,int money);
}
