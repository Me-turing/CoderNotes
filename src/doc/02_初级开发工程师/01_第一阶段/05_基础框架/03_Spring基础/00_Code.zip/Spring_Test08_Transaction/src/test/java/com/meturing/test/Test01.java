package com.meturing.test;

import com.meturing.service.AccountService;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test01 {
    //测试普通无事务处理
    @Test
    public void test01(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContex.xml");
        AccountService accountService = applicationContext.getBean(AccountService.class);
        accountService.transMoney(1,2,500);
    }

    //测试手动代码事务处理
    //@Test
    //public void test02(){
    //    ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContex_1.xml");
    //    AccountService accountService = applicationContext.getBean(AccountService.class);
    //    int rows = accountService.transMoneyCode(1, 2, 500);
    //    System.out.println(rows);
    //}

    //测试声明式事务处理: 注解
    @Test
    public void test03(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContex_2.xml");
        AccountService accountService = applicationContext.getBean(AccountService.class);
        int rows = accountService.transMoneyAnnotations(1, 2, 500);
        System.out.println(rows);
    }

    //测试声明式事务处理: XML
    @Test
    public void test04(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContex_3.xml");
        AccountService accountService = applicationContext.getBean(AccountService.class);
        int rows = accountService.transMoneyXml(1, 2, 500);
        System.out.println(rows);
    }

}
