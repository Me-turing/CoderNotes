package com.meturing.service.impl;

import com.meturing.dao.AccountDao;
import com.meturing.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccountServiceImpl implements AccountService {
    @Autowired
    private AccountDao accountDao;
    //@Autowired
    //private TransactionTemplate transactionTemplate;
    @Override
    public int transMoney(int from, int to, int money) {
        int rows=0;
        rows+=accountDao.transMoney(from, 0 - money);
        //rows = 1/0;//制造异常
        rows+=accountDao.transMoney(to, money);
        return rows;
    }

    //@Override
    //public int transMoneyCode(int from, int to, int money) {
    //    Object execute = transactionTemplate.execute(new TransactionCallback<Object>() {
    //        @Override
    //        public Object doInTransaction(TransactionStatus transactionStatus) {
    //            //创建还原点
    //            Object savepoint = transactionStatus.createSavepoint();
    //            //*********执行主要业务,过程中出现错误则回滚,并返回错误日志*************
    //            int rows=0;
    //            try {
    //                rows+=accountDao.transMoney(from, 0 - money);
    //                rows = 1/0;//制造异常
    //                rows+=accountDao.transMoney(to, money);
    //            } catch (Exception e) {
    //                //回滚至还原点
    //                transactionStatus.rollbackToSavepoint(savepoint);
    //                return 0;
    //            }
    //            return rows;
    //        }
    //    });
    //    return  execute instanceof Integer?(Integer)execute:0;
    //}

    @Override
    @Transactional
    public int transMoneyAnnotations(int from, int to, int money) {
        int rows=0;
        rows+=accountDao.transMoney(from, 0 - money);
        rows = 1/0;//制造异常
        rows+=accountDao.transMoney(to, money);
        return rows;
    }

    @Override
    public int transMoneyXml(int from, int to, int money) {
        int rows=0;
        rows+=accountDao.transMoney(from, 0 - money);
        rows = 1/0;//制造异常
        rows+=accountDao.transMoney(to, money);
        return rows;
    }
}
