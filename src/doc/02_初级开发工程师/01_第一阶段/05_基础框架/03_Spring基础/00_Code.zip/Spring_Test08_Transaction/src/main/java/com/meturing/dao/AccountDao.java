package com.meturing.dao;

public interface AccountDao {
    int transMoney(int id,int money);
}
