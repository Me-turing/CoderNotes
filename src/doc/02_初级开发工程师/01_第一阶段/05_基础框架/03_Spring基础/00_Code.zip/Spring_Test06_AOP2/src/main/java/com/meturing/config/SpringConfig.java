package com.meturing.config;


import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.meturing")
public class SpringConfig {
}
