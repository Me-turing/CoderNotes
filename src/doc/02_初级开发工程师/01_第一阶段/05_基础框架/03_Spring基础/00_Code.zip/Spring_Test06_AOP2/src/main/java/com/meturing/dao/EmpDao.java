package com.meturing.dao;

public interface EmpDao {
    int addEmp(Integer empno,String ename,String job);
}
