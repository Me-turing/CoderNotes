package com.meturing.dao;

public interface UserDao {
    int addUser(Integer userid,String username);
}
