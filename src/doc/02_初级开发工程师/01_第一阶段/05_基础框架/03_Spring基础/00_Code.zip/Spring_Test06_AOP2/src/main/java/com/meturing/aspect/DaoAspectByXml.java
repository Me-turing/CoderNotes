package com.meturing.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class DaoAspectByXml {

    public void methodBefore(JoinPoint joinPoint){
        System.out.println("Before invoked");
    }


    public void methodAfter(JoinPoint joinPoint){
        System.out.println("After invoked");
    }


    public void methodAfterReturning(JoinPoint joinPoint,Object res){
        System.out.println("AfterReturning invoked");
    }


    public void methodAfterThrowing(Exception ex){
        System.out.println("AfterThrowing invoked");
        System.out.println(ex.getMessage());
    }


    public Object methodAround(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        System.out.println("Before invoked");
        Object proceed = proceedingJoinPoint.proceed();//执行切点方法
        System.out.println("After invoked");
        if (proceed instanceof Integer){
            System.out.println((Integer)proceed);
        }
        return  proceed;
    }
}
