package com.meturing.dao.impl;

import com.meturing.dao.EmpDao;
import org.springframework.stereotype.Repository;

@Repository
public class EmpDaoImpl implements EmpDao {
    @Override
    public int addEmp(Integer empno, String ename, String job) {
        System.out.println("empDao add ... ...");
        //int i = 1/0;
        return 1;
    }
}
