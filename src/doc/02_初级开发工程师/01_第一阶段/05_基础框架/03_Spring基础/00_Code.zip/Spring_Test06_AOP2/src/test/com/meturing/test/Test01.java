package com.meturing.test;


import com.meturing.dao.EmpDao;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test01 {
    @Test
    public void test01(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        EmpDao bean = applicationContext.getBean(EmpDao.class);
        bean.addEmp(1,"zz","zz");
    }

    @Test
    public void test02(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext1.xml");
        EmpDao bean = applicationContext.getBean(EmpDao.class);
        bean.addEmp(1,"zz","zz");
    }
}
