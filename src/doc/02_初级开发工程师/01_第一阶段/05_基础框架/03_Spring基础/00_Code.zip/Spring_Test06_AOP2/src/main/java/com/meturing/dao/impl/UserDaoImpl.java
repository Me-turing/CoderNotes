package com.meturing.dao.impl;

import com.meturing.dao.UserDao;
import org.springframework.stereotype.Repository;


@Repository
public class UserDaoImpl implements UserDao {
    @Override
    public int addUser(Integer userid, String username) {
        System.out.println("userdao add ... ...");
        //int i =1/0;
        return 1;
    }
}
