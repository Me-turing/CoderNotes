package com.meturing.test;

import com.alibaba.druid.pool.DruidDataSource;
import com.meturing.pojo.Emp;
import com.meturing.pojo.User;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test01 {
    /**
     * 第一步:User构造
     * 第二步:User属性赋值
     * 第三步:User初始化
     * 使用User,第四步:
     * User(userid=null, username=xiaoqiang, password=null)
     * 第五步:User销毁
     *
     * @author sqTan
     * @date 2023/04/28
     */
    @Test
    public void test01(){
        ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("applicationContext1_1.xml");
        User user = classPathXmlApplicationContext.getBean("user", User.class);
        System.out.println("使用User,第四步:" );
        System.out.println(user);
        classPathXmlApplicationContext.close();//手动关闭容器,触发销毁方法
    }

    /**
     * 第一步:User构造
     * 第二步:User属性赋值
     * id为:[user]的Bean初始化之前!
     * 第三步:User初始化
     * id为:[user]的Bean初始化之后!
     * 使用User,第四步:
     * User(userid=null, username=xiaoqiang, password=null)
     * 第五步:User销毁
     *
     * @author sqTan
     * @date 2023/04/28
     */
    @Test
    public void test02(){
        ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("applicationContext1_2.xml");
        User user = classPathXmlApplicationContext.getBean("user", User.class);
        System.out.println("使用User,第四步:" );
        System.out.println(user);
        classPathXmlApplicationContext.close();//手动关闭容器,触发销毁方法
    }

    /**
     * 测试手动注入
     * Emp(dept=Dept())
     *
     * @author sqTan
     * @date 2023/04/28
     */
    @Test
    public void test03(){
        ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("applicationContext2.xml");
        Emp emp =  classPathXmlApplicationContext.getBean("emp1", Emp.class);
        System.out.println(emp);
    }

    /**
     * 测试自动注入
     * Emp(dept=Dept())
     *
     * @author sqTan
     * @date 2023/04/28
     */
    @Test
    public void test04(){
        ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("applicationContext2.xml");
        Emp emp =  classPathXmlApplicationContext.getBean("emp2", Emp.class);
        System.out.println(emp);
    }

    @Test
    public void test05(){
        ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("applicationContext3.xml");
        DruidDataSource druidDataSource =  classPathXmlApplicationContext.getBean("dataSource", DruidDataSource.class);
        System.out.println(druidDataSource);
    }

}
