package com.meturing.pojo;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class User {
    private Integer userid;
    private String username;
    private String password;

    public User() {
        System.out.println("第一步:User构造");
    }

    public void setUsername(String username) {
        System.out.println("第二步:User属性赋值");
        this.username = username;
    }

    public void initUser(){
        System.out.println("第三步:User初始化");
    }

    public void destoryUser(){
        System.out.println("第五步:User销毁");
    }


    public User(Integer userid, String username, String password) {
        this.userid = userid;
        this.username = username;
        this.password = password;
    }
}
