package com.meturing.beanProcesser;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class MyBeanProcesser implements BeanPostProcessor {
    /**
     * 在初始化过程
     *
     * @param bean     实例化的Bean
     * @param beanName bean的ID
     * @return {@link Object }
     * @author sqTan
     * @date 2023/04/28
     */
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        System.out.println("id为:["+beanName+"]的Bean初始化之前!");
        return bean;//必须给传进来的bean进行返回
    }

    /**
     * 发布过程初始化后
     *
     * @param bean     实例化的Bean
     * @param beanName bean的ID
     * @return {@link Object }
     * @author sqTan
     * @date 2023/04/28
     */
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        System.out.println("id为:["+beanName+"]的Bean初始化之后!");
        return bean;//必须给传进来的bean进行返回
    }
}
