package com.meturing.dao.impl;

import com.meturing.dao.UserDao;
import org.springframework.stereotype.Repository;

@Repository("userDaoImplB")
public class UserDaoImplB implements UserDao {
    @Override
    public void sayHello() {
        System.out.println("UserDaoImplB say :hello");
    }
}
