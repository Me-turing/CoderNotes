package com.meturing.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;



@ComponentScan(basePackages = "com.meturing")//包扫描
@PropertySource("classpath:user.properties")//配置类
public class SpringConfig {
}
