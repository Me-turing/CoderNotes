package com.meturing.dao.impl;

import com.meturing.dao.UserDao;
import org.springframework.stereotype.Repository;

@Repository("userDaoImplA")
public class UserDaoImplA implements UserDao {
    @Override
    public void sayHello() {
        System.out.println("UserDaoImplA say :hello");
    }
}
