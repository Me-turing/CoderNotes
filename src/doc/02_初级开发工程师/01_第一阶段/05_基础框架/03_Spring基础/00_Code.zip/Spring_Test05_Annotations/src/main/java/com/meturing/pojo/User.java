package com.meturing.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.stereotype.Component;

@Component

@Data
@ToString
@NoArgsConstructor
public class User {
}
