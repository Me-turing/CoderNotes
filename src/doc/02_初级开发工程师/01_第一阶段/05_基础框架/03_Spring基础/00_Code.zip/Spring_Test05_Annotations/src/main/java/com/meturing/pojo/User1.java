package com.meturing.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.stereotype.Component;

@Data
@ToString
@NoArgsConstructor
//@Component(value = "user1")
@Component("user1")
public class User1 {
}
