package com.meturing.service;

public interface UserService {
    void sayHello();
}
