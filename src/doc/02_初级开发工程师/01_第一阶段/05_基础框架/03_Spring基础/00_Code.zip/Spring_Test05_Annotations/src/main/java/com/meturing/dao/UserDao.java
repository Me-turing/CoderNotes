package com.meturing.dao;

public interface UserDao {
    void sayHello();
}
