package com.meturing.dao.impl;

import com.meturing.dao.EmpDao;

public class EmpDaoImpl implements EmpDao {
    public void say() {
        System.out.println("Hello World!");
    }
}
