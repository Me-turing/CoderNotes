package com.meturing.dao;

public interface EmpDao {
    public void say();
}
