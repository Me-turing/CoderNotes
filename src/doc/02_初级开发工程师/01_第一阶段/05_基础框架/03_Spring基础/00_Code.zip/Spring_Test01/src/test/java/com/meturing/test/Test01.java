package com.meturing.test;


import com.meturing.dao.EmpDao;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test01 {
    @Test
    public void test01(){
        //EmpDao empDao = new EmpDaoImpl();
        //empDao.say();
        ApplicationContext applicationContext =  new ClassPathXmlApplicationContext("spring.xml");
        EmpDao bean = applicationContext.getBean("empDao", EmpDao.class);
        bean.say();
    }
}
