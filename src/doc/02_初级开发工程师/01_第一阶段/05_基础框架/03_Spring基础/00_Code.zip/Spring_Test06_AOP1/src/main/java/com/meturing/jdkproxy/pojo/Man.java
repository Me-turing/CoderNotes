package com.meturing.jdkproxy.pojo;

import com.meturing.jdkproxy.inter.Dinner;

public class Man implements Dinner {
    private String name;

    public Man(String name) {
        this.name = name;
    }

    @Override
    public void eat(String foodName) {
        System.out.println(name+"正在吃"+foodName);
    }

    @Override
    public void drink() {
        System.out.println(name+"正在喝茶");
    }
}
