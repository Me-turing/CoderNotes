package com.meturing.staticproxy.main;

import com.meturing.staticproxy.pojo.Lawyer;
import com.meturing.staticproxy.pojo.Person;

public class TestDemo {
    public static void main(String[] args) {
        Person person = new Person("张三");
        person.doCourt();

        System.out.println("-----增强代码----");
        Lawyer lawyer = new Lawyer(person);
        lawyer.doCourt();
    }
}
