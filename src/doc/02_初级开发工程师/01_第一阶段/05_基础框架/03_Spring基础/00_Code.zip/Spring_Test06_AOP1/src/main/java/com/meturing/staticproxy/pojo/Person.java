package com.meturing.staticproxy.pojo;

import com.meturing.staticproxy.inter.Court;

public class Person  implements Court {
    private String name;

    public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void doCourt() {
        System.out.println(name + "说:我没有杀人!");
    }
}
