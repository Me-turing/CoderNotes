package com.meturing.jdkproxy.inter;

public interface Dinner {
    void eat(String foodName);
    void drink();
}
