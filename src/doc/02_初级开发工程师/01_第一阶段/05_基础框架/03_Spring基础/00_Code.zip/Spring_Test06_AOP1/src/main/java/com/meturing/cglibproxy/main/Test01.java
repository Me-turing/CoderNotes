package com.meturing.cglibproxy.main;

import com.meturing.cglibproxy.pojo.Person;
import com.meturing.cglibproxy.pojo.ZhangSan;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

public class Test01 {
    public static void main(String[] args) {
        System.out.println("--- 使用子类继承父类增强 ---");
        ZhangSan zhangSan = new ZhangSan("张三");
        zhangSan.eat("三明治");

        System.out.println("--- 尝试使用CGlib动态代理增强 ---");
        // 1 获得一个Enhancer对象
        Enhancer enhancer = new Enhancer();
        // 2 设置父类字节码
        enhancer.setSuperclass(Person.class);
        // 3 获取MethodInterceptor对象 用于定义增强规则
        MethodInterceptor interceptor = new MethodInterceptor() {
            /**
             * 拦截
             *
             * @param o           生成之后的代理对象 personProxy
             * @param method      父类中原本要执行的方法  Person>>> eat()
             * @param objects     方法在调用时传入的实参数组
             * @param methodProxy 子类中重写父类的方法 personProxy >>> eat()
             * @return {@link Object }
             * @author sqTan
             * @date 2023/05/05
             */
            @Override
            public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
                Object result = null;
                if (method.getName().equals("eat")) {
                    System.out.println("饭前洗手");
                    methodProxy.invokeSuper(o,objects);
                    System.out.println("饭后洗碗");
                }else {
                    methodProxy.invokeSuper(o, objects);
                }
                return result;
            }
        };
        // 4 设置methodInterceptor
        enhancer.setCallback(interceptor);
        // 5 获得代理对象 Class[] argumentTypes, Object[] arguments
        //Person person = (Person) enhancer.create();
        Person person = (Person) enhancer.create(new Class[]{String.class},new Object[]{"张三"});
        // 6 使用代理对象完成功能
        person.eat("三明治");
    }
}
