package com.meturing.jdkproxy.main;

import com.meturing.jdkproxy.inter.Dinner;
import com.meturing.jdkproxy.pojo.Man;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * 测试JDK代理模式,面向接口的代理
 * @author sqTan
 * @description test1
 * @date 2023/05/05
 */
public class Test1 {
    public static void main(String[] args) {
        Dinner dinner = new Man("张三");
        //ClassLoader loader,
        ClassLoader classLoader = dinner.getClass().getClassLoader();
        //Class<?>[] interfaces,
        Class<?>[] interfaces = dinner.getClass().getInterfaces();
        //InvocationHandler h
        InvocationHandler invocationHandler = new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                Object results = null;
                if (method.getName().equals("eat")) {
                    System.out.println("餐前洗手~");
                    //Object obj, Object... args   obj被代理的对象  args表示参数
                    results = method.invoke(dinner,args);
                    System.out.println("餐后洗碗~");
                }else {
                    results = method.invoke(dinner,args);
                }
                return results;
            }
        };
        Dinner dinnerProxy = (Dinner) Proxy.newProxyInstance(classLoader, interfaces, invocationHandler);
        dinnerProxy.eat("三明治");
        dinnerProxy.drink();
    }
}
