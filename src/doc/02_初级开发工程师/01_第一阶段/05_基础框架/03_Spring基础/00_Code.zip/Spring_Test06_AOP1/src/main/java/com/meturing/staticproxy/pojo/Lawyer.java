package com.meturing.staticproxy.pojo;

import com.meturing.staticproxy.inter.Court;

public class Lawyer implements Court {
    private Person person;

    public Lawyer(Person person) {
        this.person = person;
    }

    public void doCourt() {
        //增强代码
        System.out.println("开始取证~");
        System.out.println("为"+person.getName()+"辩解");
        //执行代码
        person.doCourt();
        //增强代码
        System.out.println("陈诉总结");
    }
}
