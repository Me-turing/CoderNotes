package com.meturing.staticproxy.inter;

public interface Court {
    void doCourt();
}
