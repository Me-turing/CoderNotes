package com.meturing.jdkproxy.pojo;

import com.meturing.jdkproxy.inter.Dinner;

public class Student implements Dinner {
    private String name;

    public Student(String name) {
        this.name = name;
    }


    @Override
    public void eat(String foodName) {
        System.out.println(name+"正在食堂吃"+foodName);
    }

    @Override
    public void drink() {
        System.out.println(name+"正在喝可乐");
    }
}
