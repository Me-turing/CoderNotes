package com.meturing.cglibproxy.pojo;



public class ZhangSan extends Person {
    public ZhangSan(String name) {
        super(name);
    }

    @Override
    public void eat(String foodName) {
        System.out.println("餐前洗手");
        super.eat(foodName);
        System.out.println("餐后洗碗");
    }
}
