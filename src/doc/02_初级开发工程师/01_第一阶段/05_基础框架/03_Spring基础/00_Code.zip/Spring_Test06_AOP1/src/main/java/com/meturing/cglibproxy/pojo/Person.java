package com.meturing.cglibproxy.pojo;


public class Person  {
    private String name;

    public Person(String name) {
        this.name = name;
    }
    public Person() {
    }
    public void eat(String foodName) {
        System.out.println(name+"正在食堂吃"+foodName);
    }
}
