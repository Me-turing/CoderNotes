package com.meturing.pojo.test03;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;
import java.util.Map;
import java.util.Set;
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Student {
    private String[] books;
    private Set<String> bookSet;
    private List<String> bookList;
    private Map<String,String> bookMap;
    private List<Book> bookList2;
}
