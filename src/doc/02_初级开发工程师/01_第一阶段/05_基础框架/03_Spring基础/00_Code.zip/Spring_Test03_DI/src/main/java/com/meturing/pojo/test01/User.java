package com.meturing.pojo.test01;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class User {
    private Integer userid;
    private String username;
    private String password;

    public User(Integer userid, String username, String password) {
        System.out.println("全参构造");
        this.userid = userid;
        this.username = username;
        this.password = password;
    }

    public User() {
        System.out.println("无参构造");
    }
}
