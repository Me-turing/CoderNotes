package com.meturing.test;

import com.meturing.pojo.test01.User;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
* 测试属性的赋值
* */
public class Test02 {
    //无参构造初始化,使用set注入
    @Test
    public void test01(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext2_1.xml");
        User user = applicationContext.getBean("user01", User.class);
        System.out.println(user);//User(userid=1, username=admin, password=admin)
    }

    //全参构造初始化,带参注入
    @Test
    public void test02(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext2_1.xml");
        User user = applicationContext.getBean("user02", User.class);
        System.out.println(user);//User(userid=2, username=张三, password=zhangSan)
    }

    //全参构造初始化,带参注入
    @Test
    public void test03(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext2_1.xml");
        User user = applicationContext.getBean("user03", User.class);
        System.out.println(user);//User(userid=3, username=李四, password=liSi)
    }

    //p标签注入,相当于: property 无参构造初始化,使用set注入
    @Test
    public void test04(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext2_2.xml");
        User user = applicationContext.getBean("user04", User.class);
        System.out.println(user);//User(userid=4, username=王五, password=wangWu)
    }

    //c标签注入,相当于: constructor-arg 全参构造初始化注入
    @Test
    public void test05(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext2_2.xml");
        User user = applicationContext.getBean("user05", User.class);
        System.out.println(user);//User(userid=5, username=赵六, password=zhaoLiu)
    }

    //c标签注入,相当于: constructor-arg 全参构造初始化注入
    @Test
    public void test06(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext2_2.xml");
        User user = applicationContext.getBean("user06", User.class);
        System.out.println(user);//User(userid=6, username=高七, password=gaoQi)
    }

    //特殊值注入
    @Test
    public void test07(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext2_3.xml");
        User user = applicationContext.getBean("user01", User.class);
        System.out.println(user);//User(userid=null, username=<张三>, password=!@#%^^&&^%$$#&**)
    }

}
