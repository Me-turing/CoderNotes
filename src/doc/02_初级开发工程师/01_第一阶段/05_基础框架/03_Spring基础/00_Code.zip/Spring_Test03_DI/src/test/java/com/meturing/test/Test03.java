package com.meturing.test;

import com.meturing.pojo.test02.Cat;
import com.meturing.pojo.test02.Mouse;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
* 测试属性的赋值
* */
public class Test03 {

    //外部Bean
    @Test
    public void test01(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext3.xml");
        Mouse mouse = applicationContext.getBean("mouse01", Mouse.class);
        System.out.println(mouse);//Mouse(name=Jerry, birthdate=Mon Apr 24 10:57:20 CST 2023)
    }

    //内部Bean
    @Test
    public void test02(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext3.xml");
        Cat cat = applicationContext.getBean("cat01", Cat.class);
        System.out.println(cat);//Cat(name=Tom, mouse1=Mouse(name=Jerry2, birthdate=Mon Apr 24 10:59:29 CST 2023))
    }

    //级联Bean
    @Test
    public void test03(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext3.xml");
        Cat cat = applicationContext.getBean("cat02", Cat.class);
        System.out.println(cat);//Cat(name=Tom01, mouse1=Mouse(name=Jarry3, birthdate=Mon Apr 24 11:00:01 CST 2023))
    }


}
