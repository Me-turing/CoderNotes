package com.meturing.test;

import com.meturing.pojo.test03.Student;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Arrays;

/*
* 测试属性的赋值
* */
public class Test04 {

    //基本集合使用
    @Test
    public void test01(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext4_1.xml");
        Student student = applicationContext.getBean("student1", Student.class);
        System.out.println(Arrays.toString(student.getBooks()));//[Java, MySql, PHP]
        System.out.println(student.getBookList());//[Java, MySql, PHP]
        System.out.println(student.getBookSet());//[Java, MySql, PHP]
        System.out.println(student.getBookMap());//{Java=Java, MySql=MySql, PHP=PHP}
        System.out.println(student.getBookList2());//[Book(bname=Java, author=Java), Book(bname=MySql, author=MySql), Book(bname=PHP, author=PHP)]
    }

    //util标签使用
    @Test
    public void test02(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext4_2.xml");
        Student student = applicationContext.getBean("student1", Student.class);
        System.out.println(student.getBookList2());//[Book(bname=Java, author=Java), Book(bname=MySql, author=MySql), Book(bname=PHP, author=PHP)]
    }
}
