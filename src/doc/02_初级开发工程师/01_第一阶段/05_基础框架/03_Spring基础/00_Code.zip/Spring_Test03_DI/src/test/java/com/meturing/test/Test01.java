package com.meturing.test;

import com.meturing.pojo.test01.User;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
/*
* 测试Bean标签的默认属性
* */
public class Test01 {
    //常规使用
    @Test
    public void test01(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext1.xml");
        User user = applicationContext.getBean("user", User.class);
        System.out.println(user);
    }

    //测试name
    @Test
    public void test02(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext1.xml");
        User user = applicationContext.getBean("user01", User.class);
        System.out.println(user);
    }

    //测试scope
    @Test
    public void test03(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext1.xml");
        User user01 = applicationContext.getBean("user02", User.class);
        User user02 = applicationContext.getBean("user02", User.class);
        System.out.println(user01==user02);//false

        User user03 = applicationContext.getBean("user03", User.class);
        User user04 = applicationContext.getBean("user03", User.class);
        System.out.println(user03==user04);//true
    }

    //测试lazy-init
    @Test
    public void test04(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext1.xml");
        //User user01 = applicationContext.getBean("user04", User.class);
        //User user02 = applicationContext.getBean("user05", User.class);
        //User user03 = applicationContext.getBean("user06", User.class);
    }


}
